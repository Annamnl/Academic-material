//Μανωλτσίδου Άννα 321/2016103

//import java.util.*;
public class Team {

    //όνομα, τη βαθμολογία, καθώς και την χώρα που εκπροσωπεί καθεμιά από τις 50 ομάδες.
    private String name;
    private int score;
    private String country;

    public Team(String name, int score, String country) {
        this.name = name;
        if (score >= 1 && score <= 100) {
            this.score = score;
            System.out.print(score + "\n");
        }else{
            System.out.print("Wrong! Score must be [1,100]\n");
        }
        this.country = country;
    }
    
    public int getScore(){
        return score;
    }

    public String getName(){
        return name;
    }
    
    @Override
    public String toString() {
        return "Team{" + "name=" + name + ", score=" + score + ", country=" + country + '}';
    }

    
}
