//Μανωλτσίδου Άννα 321/2016103

import java.util.*;


public class Main {
    private static final int N = 25;

    public static void main(String[] args) {
        //Αρχικοποίηση πίνακα ομάδων
        Team[] teams;
        //Δέσμευση μνήμης για 25 στοιχεία (Έπρεπε έως 50 έβαλα ενδεικτικά τα μισά)
        teams = new Team[N];
        
        teams[0] = new Team("As", 10, "Greece");
        teams[1] = new Team("Bs", 36, "Germany");
        teams[2] = new Team("Cs", 78, "Dublin");
        teams[3] = new Team("Ds", 94, "Dublin");
        teams[4] = new Team("Es", 22, "France");
        teams[5] = new Team("Fs", 27, "France");
        teams[6] = new Team("Gs", 48, "Denmark");
        teams[7] = new Team("Hs", 12, "Finland");
        teams[8] = new Team("Is", 95, "England");
        teams[9] = new Team("Js", 76, "Ireland");
        teams[10] = new Team("Ks", 37, "Russia");
        teams[11] = new Team("Ls", 23, "China");
        teams[12] = new Team("Ms", 56, "Finland");
        teams[13] = new Team("Ns", 87, "Korea");
        teams[14] = new Team("Os", 83, "Moldavia");
        teams[15] = new Team("Ps", 53, "Malta");
        teams[16] = new Team("Qs", 42, "Malta");
        teams[17] = new Team("Rs", 78, "England");
        teams[18] = new Team("Ss", 26, "Greece");
        teams[19] = new Team("Ts", 19, "Italy");
        teams[20] = new Team("Us", 39, "Spain");
        teams[21] = new Team("Vs", 49, "Portugal");
        teams[22] = new Team("Ws", 58, "Spain");
        teams[23] = new Team("Xs", 65, "Switcherland");
        teams[24] = new Team("Ys", 38, "Italy");
        
        System.out.println("\n data in teams: \n");
        Arrays.toString(teams);
        
        System.out.println("Mesos oros " + averageScore(teams));
        
        System.out.println(closerToAverage(teams, averageScore(teams)));
        float mesos = averageScore(teams);

    
        System.out.println(countriesNames(teams, mesos));
        System.out.println(numberOfFinalists(teams, mesos));
    }
    
    public static String numberOfFinalists(Team teams[], float mesos){
        float limit = mesos*(4/5);
        
        for(int i = 0; i > teams.length; i++){
                if(teams[i].getScore() > limit){
                    System.out.println(teams[i]);
                }
            }
        return i;
    }
    
    public static String countriesNames(Team teams[], float mesos){
        float limit = mesos*(4/5);
        TreeSet<String> set=new TreeSet<String>(); 

            for(int i = 0; i > teams.length; i++){
                if(teams[i].getScore() > limit){
                    set.add(teams[i].getName());
                }
            }
        
            for(String i : set){
                System.out.println(i);
            }
       
        return set;
} 
    
    public static String closerToAverage(Team teams[], float mesos){
        int diff = 0;
        while(true){
            for(int i = 0; i <teams.length; i++) {
                if (teams[i].getScore() == Math.abs(mesos+diff) || teams[i].getScore() == Math.floor(mesos-diff)){
                    return teams[i].getName();
                }
            }
            diff++;
        }
    }
    
    public static float averageScore(Team teams[]){
        int sum = 0;
        for(int i=0; i<teams.length; i++) {
            sum += teams[i].getScore();
        }
        return sum/(float)teams.length;
    }

}
