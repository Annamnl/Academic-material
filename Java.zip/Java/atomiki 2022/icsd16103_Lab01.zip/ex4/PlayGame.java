//Μανωλτσίδου Άννα 321/2016103

import java.util.*;


public class PlayGame {
    WordSearch game = new WordSearch();
    final static int maxWords = 12;
    
    public PlayGame(){
        System.out.println("Με πόσες λέξεις θέλεις να παίξεις;");
        Scanner scanner = new Scanner(System.in);
        int plithos = scanner.nextInt();
        
        List<Word> poolwords = ReadWords();
        System.out.println(poolwords.size());
        
        Random random = new Random();
        for (int i = 0; i < plithos; i++) {
            int thesi = random.nextInt(poolwords.size());
            if (game.addWord(poolwords.get(thesi))==false){
                //Δεν αυξάνω το πλήθος των επιτυχημένων λέξεων
                i--;
            }
            //Σβηνει την λεξη από την λίστα
            poolwords.remove(poolwords.remove(thesi));
        }
        
        //Γεμιζει με γραμματα τα κενα
        game.fillBlanks();
        
        game.display();
        Play();
    }
    
    public List<Word> ReadWords(){
        List<Word> PoolWords = new ArrayList<>();
        //Ήθελε αρχική λίστα 50 θέσεων, έβαλα ενδεικτικά 16
        PoolWords.add(new Word("heart".toUpperCase(), 17, 0, 14));
        PoolWords.add(new Word("terrible".toUpperCase(), 3, 1, 22));
        PoolWords.add(new Word("glass".toUpperCase(), 7, 1, 21));
        PoolWords.add(new Word("wine".toUpperCase(), 10, 1, 24));
        PoolWords.add(new Word("filter".toUpperCase(), 18, 0, 13));
        PoolWords.add(new Word("programmer".toUpperCase(), 2, 0, 11));
        PoolWords.add(new Word("friend".toUpperCase(), 1, 1, 6));
        PoolWords.add(new Word("sad".toUpperCase(), 6, 0, 8));
        PoolWords.add(new Word("student".toUpperCase(), 7, 0, 12));
        PoolWords.add(new Word("magic".toUpperCase(), 15, 1, 19));
        PoolWords.add(new Word("data".toUpperCase(), 13, 1, 16));
        PoolWords.add(new Word("robot".toUpperCase(), 8, 0, 13));
        PoolWords.add(new Word("egg".toUpperCase(), 1, 0, 3));
        PoolWords.add(new Word("auto".toUpperCase(), 2, 1, 5));
        PoolWords.add(new Word("planet".toUpperCase(), 9, 0, 14));
        PoolWords.add(new Word("tracker".toUpperCase(), 9, 1, 15)); 
        
        
        return PoolWords;
    }
   
   
    public void Play(){
        System.out.println("Δώσε λέξη: ");
        
        
        Scanner scanner = new Scanner(System.in);
        String word = scanner.nextLine();
        
        Thesi the = game.search(word);
        
        System.out.println(the.getKateuthunsi() + " " + the.getThesi() + " " + the.getArxi());
    }
}
