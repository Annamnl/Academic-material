//Μανωλτσίδου Άννα 321/2016103

public class Main {

    public static void main(String[] args) {
        PlayGame game = new PlayGame();
    } 
    
    
}
