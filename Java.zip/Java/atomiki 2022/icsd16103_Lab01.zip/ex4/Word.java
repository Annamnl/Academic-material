//Μανωλτσίδου Άννα 321/2016103

public class Word {

    private String word;
    private int arxi; //Αρχή της λέξης
    private int kateuthunsi; //Οριζόντια (0) ή κάθετα (1)
    private int thesi; //Γραμμή ή στήλη

    public Word(String word, int arxi, int kateuthunsi, int thesi) {
        this.word = word;
        this.arxi = arxi;
        this.kateuthunsi = kateuthunsi;
        this.thesi = thesi;
    }

    public String getWord() {
        return word;
    }

    public int getArxi() {
        return arxi;
    }

    public int getKateuthunsi() {
        return kateuthunsi;
    }

    public int getThesi() {
        return thesi;
    }
    
    
    
}
