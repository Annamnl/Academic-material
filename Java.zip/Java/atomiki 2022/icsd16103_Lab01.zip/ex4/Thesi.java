//Μανωλτσίδου Άννα 321/2016103

public class Thesi {
    private int arxi;
    private int kateuthunsi;
    private int thesi;

    public Thesi(int arxi, int kateuthunsi, int thesi) {
        this.arxi = arxi;
        this.kateuthunsi = kateuthunsi;
        this.thesi = thesi;
    }

    public int getArxi() {
        return arxi;
    }

    public int getKateuthunsi() {
        return kateuthunsi;
    }

    public int getThesi() {
        return thesi;
    }
    
    
}
