//Μανωλτσίδου Άννα 321/2016103

import java.util.*;
import java.io.*;

public class WordSearch {

    private static final int nRows = 15;
    private static final int nCols = 25;
    public static final int gridSize = nRows * nCols;
    //Δημιουργία πίνακα 15x25
    private char[][] cells = new char[nRows][nCols];

    public WordSearch() {
        for (char[] row : cells) {
            Arrays.fill(row, ' ');
        }

        Board();
    }

    public void Board() {
        int numAttempts;

        List<String> solutions = new ArrayList<>();
    }

    
    public static final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public boolean addWord(Word word) {
        if (word.getKateuthunsi() == 0) {
            //Έλεγχος εαν ειναι δυνατη η εισαγωγη της λεξης
            for (int j = 0; j < word.getWord().length(); j++) {
                //Αν δεν βρεθουν παντου οι default χαρακτήρες
                if (cells[word.getThesi()][j + word.getArxi()] != ' ') {
                    return false;
                }
            }
        } else {
            //Έλεγχος εαν ειναι δυνατη η εισαγωγη της λεξης
            for (int j = 0; j < word.getWord().length(); j++) {
                //Αν δεν βρεθουν παντου οι default χαρακτήρες
                if (cells[j + word.getArxi()][word.getThesi()] != ' ') {
                    return false;
                }
            }
        }

        //Προσθήκη λέξης στο κρυπτόλεξο
        for (int i = 0; i < word.getWord().length(); i++) {
            if (word.getKateuthunsi() == 0) {
                cells[word.getThesi()][i + word.getArxi()] = word.getWord().charAt(i);
            } else if (word.getKateuthunsi() == 1) {
                cells[i + word.getArxi()][word.getThesi()] = word.getWord().charAt(i);
            }
        }
        return true;

    }

    public void fillBlanks() {
        Random random = new Random();
        //Αφού τοποθετηθούν όλες οι λέξεις, γεμίζει τις υπόλοιπες θέσεις του πίνακα με τυχαία γράμματα
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 25; j++) {
                if (cells[i][j] == ' ') {
                    cells[i][j] = alphabet.charAt(random.nextInt(26));
                }
            }
        }
    }

    public Thesi search(String word) {
        /*αναζητά μια συγκεκριμένη (δοσμένη) λέξη στο κρυπτόλεξο, και αν η αναζήτηση είναι επιτυχής, επιστρέφει τη θέση της. 
        Η θέση της ορίζεται από τρείς τιμές. Αν η λέξη είναι οριζόντια από την «Γραμμή», «Στήλη Αρχής» και «Στήλη Τέλους» 
        ενώ αν είναι κάθετα από την «Στήλη», «Γραμμή Αρχής», «Γραμμή_τέλους». */
        //Έλεγχος οριζοντια
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 25-word.length(); j++) {
                int k;
                for ( k = 0; k < word.length(); k++) {
                    if (cells[i][j+k] != word.charAt(k)){
                        break;
                    }
                }
                if (k==word.length()){
                    return new Thesi(j, 0, i);
                }
            }
        }
        
        return null;
    }

    public void display() {
        //Τυπώνει τον πίνακα του κρυπτόλεξου.
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 25; j++) {
                System.out.print(cells[i][j] + " ");
            }
            System.out.println(""); //Αλλαγή γραμμής για εκτύπωση
        }
    }
}
