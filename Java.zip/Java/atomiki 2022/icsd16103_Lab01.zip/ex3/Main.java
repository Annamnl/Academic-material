//Μανωλτσίδου Άννα 321/2016103

import java.util.*;

public class Main {

    public static void main(String[] args) {
        storeString("HELLO MAMA!");
    }

    public static void storeString(String s) {
        HashMap<Character, ArrayList> map = new HashMap<>();
        
        for (int i = 0; i < s.length(); i++) {
           if(!map.containsKey(s.charAt(i))){
               map.put(s.charAt(i), new ArrayList());
           }
           map.get(s.charAt(i)).add(i);
        }
        
        System.out.println(map);
    }
    
    
    public static void info(String s){
        HashMap<Character, ArrayList> map = new HashMap<>();
        
        for (int i = 0; i < s.length(); i++) {
           if(!map.containsKey(s.charAt(i))){
               map.put(s.charAt(i), new ArrayList());
           }
           map.get(s.charAt(i)).add(i);
        }
        
        for(int i=0;i<s.length();i++){
            if(map.containsValue(s.charAt(i))){
                map.
            }
        }
    }

}
