//Μανωλτσίδου Άννα 321/2016103

//import java.util.*;

public class Main {

  public static void main(String[] args) {
    
    int a[] = new int[10];
    NumbersTable arr = new NumbersTable();

    arr.fillTableRandomly(a);
    System.out.println("\n");
    arr.printTableΗ(a);
    System.out.println("\n");
    arr.printTableV(a);
    System.out.println("\n");
    arr.swapValues(a, 1, 3);
    System.out.println("\n");
    arr.minLocationFrom(a, 0);
    System.out.println("\n");
    arr.maxLocationFrom(a, 0);
    System.out.println("\n");
    int thesi = arr.LocationNumber(a, 43);
    if (thesi == -1) System.out.println("Den uparxei");
    else System.out.println("Uparxei stin thesi "+ thesi);
    System.out.println("\n");
    arr.cloneTable(a);
    System.out.println("\n");
    int merged[] = arr.mergeTables(a, a);
    System.out.println(arr.ConvertToString(merged));
    System.out.println("\n");
    System.out.println(arr.ConvertToString(a));
    System.out.println("\n");
    System.out.println(arr.ConvertToString(a, 1, 4));
    System.out.println("\n");
  }
}
