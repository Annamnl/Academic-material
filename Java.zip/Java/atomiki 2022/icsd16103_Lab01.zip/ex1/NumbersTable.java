//Μανωλτσίδου Άννα 321/2016103

import java.util.*;

public class NumbersTable {

  public int table[];

  public NumbersTable() {}


  public void fillTableRandomly(int a[]) {
    //Γεμίζει τον πίνακα που δέχεται ως παράμετρο με τυχαίους ακέραιους αριθμούς στο διάστημα [1, 50].
    Random random = new Random();

    for (int i = 0; i < a.length; i++) {
      double rNum = random.nextInt(50) + 1;
      a[i] = (int) (rNum);
    }

    System.out.println("Randomly filled array elements are:");
    for (int i = 0; i < a.length; i++) {
      System.out.print(a[i] + " ");
    }
  }

  public void printTableΗ(int a[]) {
    //Τυπώνει όλα τα στοιχεία του πίνακα σε μια γραμμή.
    for (int element : a) {
      System.out.print(element + ", ");
    }
  }

  public void printTableV(int a[]) {
    //Τυπώνει όλα τα στοιχεία του πίνακα σε μια στήλη.
    for (int element : a) {
      System.out.println(element);
    }
  }

  public void swapValues(int a[], int b, int c) {
    //Εναλλάσσει τις τιμές των κελιών του πίνακα που ορίζονται από τις 2 τελευταίες παραμέτρους.
    
    int temp = a[b];
    a[b] = a[c];
    a[c] = temp;

    System.out.println(Arrays.toString(a));
  }

  public void minLocationFrom(int a[], int b) {
    //Επιστρέφει τη θέση του μικρότερου στοιχείου του πίνακα. Η δεύτερη παράμετρος ορίζει την θέση του πίνακα από όπου θα ξεκινήσει η αναζήτηση του μικρότερου αριθμού.
    int element = a[b];
    for (int i = b; i < a.length; i++) {
      element = Math.min(element, a[i]);
    }
    System.out.println("Minimum element of array: " + element);
  }

  public void maxLocationFrom(int a[], int b) {
    //Επιστρέφει τη θέση του μεγαλύτερου στοιχείου του πίνακα. Η δεύτερη παράμετρος ορίζει την θέση του πίνακα από όπου θα ξεκινήσει η αναζήτηση του μεγαλύτερου αριθμού.
    int element = a[b];
    for (int i = b; i < a.length; i++) {
      element = Math.max(element, a[i]);
    }
    System.out.println("Minimum element of array: " + element);
  }

  public int LocationNumber(int a[], int b) {
    //Επιστρέφει την πρώτη εμφάνιση του αριθμού της δεύτερης παραμέτρου στον πίνακα. Αν δεν υπάρχει ο αριθμός επιστρέφει -1.
    //Αν ο πίνακας είναι null
    if (a == null) {
      return -1;
    }

    int i = 0;
    //Διάσχιση πίνακα
    while (i < a.length) {
      //Αν το στοιχείο i είναι b τότε επιστρέφει το index
      if (a[i] == b) {
        return i;
      } else {
        i = i + 1;
      }
    }
    return -1;
  }

  public int[] cloneTable(int a[]) {
    //Δημιουργία ενός νέου πίνακα, αντιγράφου του πίνακα που δέχεται ως παράμετρο.
    //Δημιουργία ενός πίνακα b[] του ίδιου μεγέθους με τον a[]
    int b[] = new int[a.length];

    for (int i = 0; i < a.length; i++) {
        b[i] = a[i];
    }

    System.out.println("Contents of a[] ");
    for (int i = 0; i < a.length; i++) System.out.print(a[i] + " ");

    System.out.println("\n\nContents of b[] ");
    for (int i = 0; i < b.length; i++) System.out.print(b[i] + " ");
    return b;
  }

  public int[] mergeTables(int a[], int b[]) {
    //Δημιουργία ενός νέου πίνακα, που προκύπτει από την συγχώνευση των 2 πινάκων που δέχεται ως παράμετρο.
    //Δημιουργία νέου πίνακα με μέγεθος όσο του α και του β
    int merged[] = new int[a.length + b.length];
    int i;
    for (i = 0; i < a.length; i++) {
        merged[i] = a[i];
    }
    int j = i;
    for (i = 0; i < b.length; i++) {
        merged[j] = b[i];
        j++;
    }
    
    return merged;
  }

  public String ConvertToString(int a[]) {
    //Δημιουργία ενός αλφαριθμητικού με όλους τους αριθμούς του πίνακα.
    String str = Arrays.toString(a);
    
    //Αφαιρώ τις αγκύλες από τον πίνακα
    str = str.replace("[", "");
    str = str.replace("]", "");
    str = str.replaceAll(",", "");
     
    return str;
  }

  public String ConvertToString(int a[], int b, int c) {
    //Δημιουργία ενός αλφαριθμητικού με όλους τους αριθμούς του πίνακα από την θέση που καθορίζεται από την 1η παράμετρο έως την θέση που καθορίζεται στην 2η παράμετρο.
    int neos[] = Arrays.copyOfRange(a, b, c);
    
    //Δημιουργία ενός αλφαριθμητικού με όλους τους αριθμούς του πίνακα.
    String str = Arrays.toString(neos);
    
    //Αφαιρώ τις αγκύλες από τον πίνακα
    str = str.replace("[", "");
    str = str.replace("]", "");
    str = str.replaceAll(",", "");
     
    return str;
  }
}
