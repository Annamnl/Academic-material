
public class Clock {

    private int hour;
    private int min;
    private int sec;

    public Clock() {
        this.hour = 12;
    }

    public Clock(int hour, int min, int sec) {
        this.hour = hour;
        this.min = min;
        this.sec = sec;
    }

    //px estw oti dinei 3670 deuterolepta
    //1 wra kai 70 deuterolepta
    //1 lepto kai 10 deuterolepta
    public Clock(int sec) {
        this.hour = sec / 3600; // 1 wra
        int upoloipo = sec % 3600;
        this.min = upoloipo / 60;
        this.sec = upoloipo % 60;
    }

    public void setClock(int sec) {
        this.hour = sec / 3600; // 1 wra
        int upoloipo = sec % 3600;
        this.min = upoloipo / 60;
        this.sec = upoloipo % 60;
    }

    public void setHour(int hour) {
        if (hour > 0 && hour <= 23) {
            this.hour = hour;
            System.out.print(hour);
        } else {
            System.out.println("False hour");
        }
    }

    public Integer getHour() {
        return hour;
    }

    public void setMin(Integer min) {
        if (min > 0 && min <= 59) {
            this.min = min;
            System.out.print(min);
        } else {
            System.out.println("False minutes");
        }
    }

    public Integer getMin() {
        return min;
    }

    public void setSec(Integer sec) {
        if (sec > 0 && sec <= 59) {
            this.sec = sec;
            System.out.print(sec);
        } else {
            System.out.println("False seconds");
        }
    }

    public int getSec() {
        return sec;
    }

    public void tick() {
//        if (min==59 && sec ==59){
//            hour++;
//            min=0;
//            sec=0;
//        }
//        else if (sec == 59){
//            sec = 0;
//            min ++;
//        }
//        else sec++;
        

        //this.sec = this.sec+1;
        this.sec++;
        
        //omws an i wra itan 11:00:59 -> 11:01:00
        //meta tin auxisi tha einai 11:00:60
        if (this.sec == 60){
            this.sec = 0;
            this.min++;
                    
           if (this.min==60){
               this.min = 0;
               this.hour++;
           }
        }
        
        
    }
    
    public void tickDown(){
        this.sec--;
        
        //omws an i wra itan 11:00:59 -> 11:01:00
        //meta tin auxisi tha einai 11:00:60
        if (this.sec == 60){
            this.sec = 0;
            this.min--;
                    
           if (this.min==60){
               this.min = 0;
               this.hour--;
           }
        }
    }

    //OVERRIDE tin string (allazw dld tin leitourgia tis string
    @Override
    public String toString() {
        return this.hour + ":" + this.min + ":" + this.sec;
    }
    
    //14:24:36
    //13:45:45  = 38:51
    public Clock clockDifference(Clock roloi2){
         int this_clock_secs = hour*3600+min*60+sec;
         int clock2_secs = roloi2.hour*3600 + roloi2.min*60 + roloi2.sec;
         int dif = this_clock_secs - clock2_secs;
         Clock dif_clock = new Clock(dif);
         return dif_clock;
    }

}
