
public class Main {

    
    public static void main(String[] args) {
        
        //oles oi klaseis stin java klirwnomoun PANTA apo mia arxegoni klasi
        //tin OBJECT
        
        //14:24:36
        Clock c = new Clock(51876);
        
        
        //oi parakatw 2 grammes einai oloidies
        //System.out.println(c.toString());
        System.out.println(c);
        
        Clock c2 = new Clock(13, 45, 45);
        Clock c3 = c.clockDifference(c2);
        System.out.println(c3);
    }
    
}
