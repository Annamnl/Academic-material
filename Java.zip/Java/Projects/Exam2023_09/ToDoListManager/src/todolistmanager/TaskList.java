
package todolistmanager;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class TaskList {
    private Map<Integer, RegularTask> tasks;

    public TaskList()
    {
        tasks = new  HashMap<>();
    }

    public void addTask(RegularTask aTask) throws Exception
    {
        if (tasks.containsKey(aTask.getId()))
            throw new Exception("This task id has already been used!");
        tasks.put(aTask.getId(), aTask);
    }

    public void removeTask(int aTaskId) throws Exception
    {
        if (tasks.containsKey(aTaskId))
            tasks.remove(aTaskId);
        throw new Exception("This task id does not exist!");
    }

    public void readFromFile(String aFileName) throws Exception
    {
         try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(aFileName))) {
            tasks = (Map<Integer, RegularTask>) ois.readObject();
        }
    }

    public void saveToFile(String aFileName) throws Exception
    {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(aFileName))) {
            oos.writeObject(tasks);
        }
    }

    
    public List<RegularTask> getTasks(boolean urgent)
    {
        List<RegularTask>result = new LinkedList<>();
        tasks.forEach((k, t) -> {
            if (t.isUrgent() == urgent)
                result.add(t);
        });

        return result;
    }
}
