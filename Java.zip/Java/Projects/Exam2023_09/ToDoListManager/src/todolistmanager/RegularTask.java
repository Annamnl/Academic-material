
package todolistmanager;

import java.io.Serializable;
import java.util.Objects;

public class RegularTask implements Serializable {

    // class fields
    protected final int id;
    protected final String title;
    protected final String comments;

    // constructor for non urgent tasks
    public RegularTask( int anId, String aTitle, String comments)
    {
        this.id = anId;
        this.title = aTitle;
        this.comments = comments;
    }

    public int getId()
    {
        return id;
    }

    public boolean isUrgent()
    {
        return false;
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) 
            return true;
        
        if (obj == null) 
            return false;
        
        if (getClass() != obj.getClass()) 
            return false;
        
        final RegularTask other = (RegularTask) obj;
        return this.id == other.id;
    }

    @Override
    public String toString()
    {
        return String.format("%d: %s -- %s", id, title, comments);
    }
}
