package todolistmanager;

import java.util.Date;
import java.util.Scanner;

public class Program {    
    static final TaskList myTasks = new TaskList();
    static Scanner scanner;
    
    public static void main(String[] args) 
    {
        scanner = new Scanner(System.in);
        
        char currentChoice;
        do {            
            currentChoice = displayMenu();
            execureCommand(currentChoice);
        } while (currentChoice != 'x');
        
        scanner.close();
    }

    public static char displayMenu()
    {       
         while (true) {
            try {
                System.out.println("(L)oad from file, Sa(v)e to file, Add (r)egular task, Add (u)rgent task");
                System.out.println("(S)how regular tasks, Show urgent (t)asks, e(x)it");
                System.out.print("Select option :");
                String currentLine = scanner.nextLine();
                return currentLine.charAt(0);
            } catch (Exception ex) {
                System.err.println("please enter a valid choice!");
            }
         }
    }

    private static void execureCommand(char command) 
    {
        switch (command) {
            case 'l' -> loadFromFile();            
            case 'v' -> saveToFile();
            case 'r' -> addTask(false);
            case 'u' -> addTask(true);
            case 's' -> showTasks(false);
            case 't' -> showTasks(true);
            case 'x' -> {
                System.out.println("Goodbye!");
            }
            default -> {
                System.out.println("Invalid command specified!");
            }
        }
    }
    
    private static void loadFromFile()
    {
        System.out.print("Enter file to read from:");
        String fileName = scanner.nextLine();
        try {            
            myTasks.readFromFile(fileName);
        } catch (Exception e) {
            System.err.printf("Cannot load data from file %s. Error is %s\n", fileName, e.getMessage());
        }
    }
    
    private static void saveToFile()
    {
        System.out.print("Enter file to save to:");
        String fileName = scanner.nextLine();
        try {            
            myTasks.saveToFile(fileName);
        } catch (Exception e) {
            System.err.printf("Cannot save data from file %s. Error is %s\n", fileName, e.getMessage());
        }
    }
    
    private static void addTask(boolean isUrgent)
    {
        String taskType = isUrgent ? "urgent" : "regular";
        System.out.printf("Adding %s task\n", taskType);
        RegularTask entry = readTask(isUrgent);
        try {
            myTasks.addTask(entry);
            System.out.println("Task added!");
        } catch (Exception e) {
            System.err.printf("Error adding %s task. Message is %s\n", 
                    taskType, 
                    e.getMessage());
        }
    }
    
    private static RegularTask readTask(boolean isUrgent)
    {
        int id;
        String idLine, dateLine;
        String title, comments;                
        Date expiresOn;
        
        while (true) {
            try {
                System.out.print("Enter task id:");
                idLine = scanner.nextLine();
                id = Integer.parseInt(idLine);
                
                System.out.print("Enter task title:");
                title = scanner.nextLine();
                System.out.print("Enter task comments:");
                comments = scanner.nextLine();
                if (isUrgent) {
                    System.out.print("Enter expire date time:");
                    dateLine = scanner.nextLine().trim();
                    expiresOn = UrgentTaskEntry.DEFAULT_DATE_FORMAT.parse( dateLine);
                    return new UrgentTaskEntry(id, title, comments, expiresOn);
                }
                return new RegularTask(id, title, comments);
            } catch (Exception e) {
                System.err.printf("Cannot parse input error is : %s\n", e.getMessage());
            }
        }
    }
    
    private static void showTasks(boolean isUrgent)
    {
        String taskType = isUrgent ? "urgent" : "regular";
        System.out.printf("Displaying %s tasks\n", taskType);
        
        myTasks.getTasks(isUrgent).forEach((t) -> {
            System.out.printf("\t%s\n", t);
        });        
    }
}
