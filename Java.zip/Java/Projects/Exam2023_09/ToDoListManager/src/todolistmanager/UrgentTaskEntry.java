
package todolistmanager;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Am urgent task is a task with an expiry date
 *
 */
public class UrgentTaskEntry extends RegularTask {
    public static final SimpleDateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd H:m:s");

    protected final Date expiresOn;

    public UrgentTaskEntry( int anId, String aTitle, String comments, Date expirationDate)
    {
        super(anId, aTitle, comments);
        this.expiresOn = expirationDate;
    }

    @Override
    public boolean isUrgent()
    {
        return true;
    }

    @Override
    public String toString()
    {
        return String.format("%d: (%s) %s -- %s", id,
                        DEFAULT_DATE_FORMAT.format(expiresOn),
                        title, comments);
    }
}
