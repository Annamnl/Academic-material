/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class GroceryStore {
    private final List<String> fruit;
    private final List<String> vegetables;
    private final List<String> groceries;
    
    private final List<String> purchaisedItems;
    
    private int totalFruit;
    private int totalVegetables;
    private int totalGroceries;
    
    public GroceryStore()
    {
        String[] fruitArray = {
            "ananas", "banana", "apple"
        };
        fruit = new ArrayList<>(Arrays.asList(fruitArray));
        
        String[] veregatblesArray = {
            "carrot", "cabbage", "tomato", "onion"
        };
        vegetables = new ArrayList<>(Arrays.asList(veregatblesArray));
        
        String[] groceriesArray = {
            "coffee", "sugar", "milk", "butter"
        };
        groceries = new ArrayList<>(Arrays.asList(groceriesArray));
        purchaisedItems = new LinkedList<>();
    }
    
    public void run()
    {
        totalFruit = totalGroceries = totalVegetables = 0;
        Scanner s = new Scanner(System.in);
        String currentItem;
        boolean isValidItem;
        
        while (true) {
            System.out.print("What did you buy? (Type exit) to quit: ");
            currentItem = s.nextLine().trim().toLowerCase();
            if (currentItem.equals("exit"))
                break;                      
            
            isValidItem = true;
            if (fruit.contains(currentItem)) {
                totalFruit++;
                System.out.println("You brought a fruit");                
            } else if (vegetables.contains(currentItem)) {
                totalVegetables++;
                System.out.println("You brought a vegetable");                
            } else if (groceries.contains(currentItem)) {
                totalGroceries++;
                System.out.println("You brought a grocery");                
            } else {
                System.out.printf("Our store does not habe this item! (%s)\n", currentItem);            
                isValidItem = false;
            }

            if (isValidItem)
                purchaisedItems.add(currentItem);

        }
        
        System.out.printf("Total fruit %d, vegetables %d grocessies %d\n", totalFruit, totalVegetables, totalGroceries);
        
        System.out.println("Purchaised Items:");
        for (String item : purchaisedItems){
            System.out.println(item);
        }
    }
}
