/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev9;

/**
 * Provides type and price (without VAT) for a product
 * 
 */
public class ProductInfo {
    private ProductType type = null;
    private Double price = null;

    public ProductInfo(ProductType type, Double price)
    {
        this.type = type;
        this.price = price;
    }

    public ProductType getType()
    {
        return type;
    }

    public void setType(ProductType type)
    {
        this.type = type;
    }

    public Double getPrice()
    {
        return price;
    }

    public void setPrice(Double price)
    {
        this.price = price;
    }

}
