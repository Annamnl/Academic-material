/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev9;

import java.util.HashMap;
import java.util.Map;

public class ShoppingBasket {
     private final Map<String, ShoppingBasketEntry> items;

     public ShoppingBasket()
     {
         items = new HashMap<>();
     }

    public double getTotalPrice()
    {
        double result = 0;
        for (ShoppingBasketEntry e : items.values()) {
            result += e.getTotalPriceWithVAT();
        }
        return result;
    }

    public void print()
    {
        items.forEach( (key,value) -> {
            System.out.printf("%10s:%s\n", key, value.toString());
        });
    }

    public boolean add(String anItem, double price)
    {
        if (items.containsKey(anItem)) {
            ShoppingBasketEntry curEntry = items.get(anItem);
            curEntry.addQuantity(1);
            return false;
        }

        items.put(anItem, new ShoppingBasketEntry(price));
        return true;
    }
}
