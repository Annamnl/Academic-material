/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev9;

import java.util.HashMap;
import java.util.Map;

public class PriceList {
    private final Map<ProductType, Map<String, Double>> items;

    public PriceList()
    {
        items = new HashMap<>();
        for (ProductType type : ProductType.values())
            items.put(type, new HashMap<>());
    }

    /**
     * Add an entry to the price list
     *
     * @param aType
     * @param aProduct
     * @param aPrice
     */
    public void add(ProductType aType, String aProduct, double aPrice)
    {
        items.get(aType).put(aProduct, aPrice);
    }

    /**
     * return information about a product
     *
     * @param aProduct what we are searching for
     * @return related info or null if not found
     */
    public ProductInfo getInfo(String aProduct)
    {
        for (ProductType type : items.keySet()) {
            Map<String, Double> relatedProducts = items.get(type);
            for (String relatedProduct: relatedProducts.keySet()) {
                if (relatedProduct.equals(aProduct))
                    return new ProductInfo(type, relatedProducts.get(relatedProduct));
            }
        }
        return null;
    }
}
