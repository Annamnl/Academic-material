/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package grocerystorev9;

/**
 * The various types of our grocery store products
 */
public enum ProductType {
    GROCERY, FRUIT, VEGETABLE, OTHER;

    @Override
    public String toString()
    {
        return switch(this) {
            case GROCERY -> "Grocery";
            case FRUIT -> "Fruit";
            case VEGETABLE -> "Vegetable";
            case OTHER -> "Other";
            default -> "I don't know what this is";
        };
    }
}
