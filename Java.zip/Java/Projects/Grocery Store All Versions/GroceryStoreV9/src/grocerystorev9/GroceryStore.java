/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev9;

import java.util.Scanner;

public class GroceryStore {
    private final PriceList priceList;
    private final ShoppingBasket shoppingBasket;

    private int totalFruit;
    private int totalVegetables;
    private int totalGroceries;
    private int totalOthers;

    public GroceryStore()
    {
        priceList = new PriceList();
        priceList.add(ProductType.FRUIT, "ananas", 2.22);
        priceList.add(ProductType.FRUIT,"banana", 2.01);
        priceList.add(ProductType.FRUIT,"apple", 0.55);

        priceList.add(ProductType.VEGETABLE, "carrot", 0.22);
        priceList.add(ProductType.VEGETABLE, "cabbage", 0.21);
        priceList.add(ProductType.VEGETABLE, "potato", 0.14);
        priceList.add(ProductType.VEGETABLE, "tomato", 0.62);
        priceList.add(ProductType.VEGETABLE, "onion", 0.12);

        priceList.add(ProductType.GROCERY, "coffee", 7.45);
        priceList.add(ProductType.GROCERY, "sugar", 0.82);
        priceList.add(ProductType.GROCERY, "milk", 1.10);
        priceList.add(ProductType.GROCERY, "butter", 10.45);

        priceList.add(ProductType.OTHER, "razor", 40.11);

        shoppingBasket = new ShoppingBasket();
    }

    public void run()
    {
        totalFruit = totalGroceries = totalVegetables = totalOthers = 0;
        Scanner s = new Scanner(System.in);
        String currentItem;

        while (true) {
            System.out.print("What did you buy? (Type exit) to quit: ");
            currentItem = s.nextLine().trim().toLowerCase();
            if (currentItem.equals("exit"))
                break;

            ProductInfo pi = priceList.getInfo(currentItem);
            if (pi == null) {
                System.out.printf("Our store does not habe this item! (%s)\n", currentItem);
                continue;
            }

            switch (pi.getType()) {
                case ProductType.FRUIT -> {
                    totalFruit++;
                }
                case ProductType.VEGETABLE -> {
                    totalVegetables++;
                }
                case ProductType.GROCERY -> {
                    totalGroceries++;
                }
                case ProductType.OTHER -> {
                    totalOthers++;
                }
            }

            System.out.printf("You brought a product of type: %s!\n", pi.getType());
            if (shoppingBasket.add(currentItem, pi.getPrice()) == false)
                System.out.printf("One more %s added to cart!\n", currentItem);
        }

        System.out.printf("Total fruit %d, vegetables %d grocessies %d, others %d.\n",
                totalFruit, totalVegetables, totalGroceries, totalOthers);

        System.out.println("Purchaised Items:");
        shoppingBasket.print();

        System.out.printf("Total amount: %.2f euros\n", shoppingBasket.getTotalPrice());
        s.close();
    }
}
