/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev5;

public class ShoppingBasketEntry {
    private final int quantity;
    private final double price;
    
    public ShoppingBasketEntry(int aQuantity, double aPrice)
    {
        quantity = aQuantity;
        price = aPrice;
    }
    
    public ShoppingBasketEntry(double aPrice)
    {
        quantity = 1;
        price = aPrice;
    }

    public int getQuantity() 
    {
        return quantity;
    }

    public double getPrice() 
    {
        return price;
    }
    
    
    @Override
    public String toString()
    {
        return String.format("%d: %.2f euro", quantity, price);
    }
}
