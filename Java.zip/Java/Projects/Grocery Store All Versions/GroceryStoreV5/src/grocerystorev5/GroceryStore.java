/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev5;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class GroceryStore {
    private final Map<String, Double> fruit;
    private final Map<String, Double> vegetables;
    private final Map<String, Double> groceries;
    
    private final Map<String, ShoppingBasketEntry> shoppingBasket;
    
    private int totalFruit;
    private int totalVegetables;
    private int totalGroceries;
    
    private double totalPrice;
    
    public GroceryStore()
    {
        fruit = new HashMap<>();
        fruit.put("ananas", 2.22);
        fruit.put("banana", 2.01);
        fruit.put("apple", 0.55);
                               
        vegetables = new HashMap<>();
        vegetables.put("carrot", 0.22);
        vegetables.put("cabbage", 0.21);
        vegetables.put("tomato", 0.62);
        vegetables.put("onion", 0.12);
                
        groceries = new HashMap<>();
        groceries.put("coffee", 7.45);
        groceries.put("sugar", 0.82);
        groceries.put("milk", 1.10);
        groceries.put("butter", 10.45);
        
        shoppingBasket = new HashMap<>();
    }
    
    public void run()
    {
        totalFruit = totalGroceries = totalVegetables = 0;
        totalPrice = 0;
        Scanner s = new Scanner(System.in);
        String currentItem;
        boolean isValidItem;
        double currentPrice = 0; 
        
        while (true) {
            System.out.print("What did you buy? (Type exit) to quit: ");
            currentItem = s.nextLine().trim().toLowerCase();
            if (currentItem.equals("exit"))
                break;
            
            if (shoppingBasket.containsKey(currentItem)) {
                System.out.println("You have already bought this item.");
                continue;
            }
            
            isValidItem = true;
            if (fruit.containsKey(currentItem)) {
                totalFruit++;
                currentPrice = fruit.get(currentItem);
                System.out.println("You brought a fruit");                
            } else if (vegetables.containsKey(currentItem)) {
                totalVegetables++;
                System.out.println("You brought a vegetable");                
                currentPrice = vegetables.get(currentItem);
            } else if (groceries.containsKey(currentItem)) {
                totalGroceries++;
                System.out.println("You brought a grocery");                
                currentPrice = groceries.get(currentItem);
            } else {
                System.out.printf("Our store does not habe this item! (%s)\n", currentItem);            
                isValidItem = false;
            }

            if (isValidItem) {
                shoppingBasket.put(currentItem, new ShoppingBasketEntry(currentPrice));
                totalPrice += currentPrice;
            }
        }
        
        System.out.printf("Total fruit %d, vegetables %d grocessies %d\n", totalFruit, totalVegetables, totalGroceries);
        
        System.out.println("Purchaised Items:");
        for (String item : shoppingBasket.keySet()) 
            System.out.printf("\t%s: %s\n", item, shoppingBasket.get(item));
        
        System.out.printf("Total amount: %.2f euros\n", totalPrice);
    }
}
