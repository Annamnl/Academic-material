/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev6;

import java.util.HashMap;
import java.util.Map;

public class ShoppingBasket {
     private final Map<String, ShoppingBasketEntry> items;
     
     public ShoppingBasket()
     {
         items = new HashMap<>();
     }

    public boolean containsItem(String anItem) 
    {
        return items.containsKey(anItem);
    }

    public ShoppingBasketEntry getItem(String anItem) 
    {
        return items.get(anItem);
    }

    public void putItem(String anItem, ShoppingBasketEntry anEntry) 
    {
        items.put(anItem, anEntry);
    }

    public Iterable<String> itemsSet() 
    {
        return items.keySet();
    }

    public double getTotalPrice() 
    {
        double result = 0;
        for (ShoppingBasketEntry e : items.values()) {
            result += e.getTotalPriceWithVAT();
        }
        return result;
    }
     
}
