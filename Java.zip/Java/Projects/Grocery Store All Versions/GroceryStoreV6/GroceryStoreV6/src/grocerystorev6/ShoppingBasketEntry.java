/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystorev6;

public class ShoppingBasketEntry {
    public static final double VAT_PERCENTAGE = 0.24;
    
    private int quantity;
    private final double unitPrice;
    
    public ShoppingBasketEntry(int aQuantity, double aPrice)
    {
        quantity = aQuantity;
        unitPrice = aPrice;
    }
    
    public ShoppingBasketEntry(double aPrice)
    {
        quantity = 1;
        unitPrice = aPrice;
    }

    public int getQuantity() 
    {
        return quantity;
    }

    void addQuantity(int i) 
    {
        quantity += i;
    }
    
    public double getUnitPrice() 
    {
        return unitPrice;
    }
    
    public double getTotalPrice()
    {
        return quantity * unitPrice;
    }
    
    public double getUnitPriceVAT()
    {
        return unitPrice * VAT_PERCENTAGE;
    }
    
    public double getTotalVAT()
    {
        return quantity * getUnitPriceVAT();
    }
    
    public double getTotalPriceWithVAT()
    {
        return getTotalPrice() + getUnitPriceVAT();
    }
    
    @Override
    public String toString()
    {
        return String.format("%3d: %.2f€ VAT %.2f€ Total: %.2f€", 
                quantity, 
                unitPrice, 
                getTotalPrice(), 
                getTotalPriceWithVAT());
    }    
}
