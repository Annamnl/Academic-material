/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package guessgame;

public class GuessGame {
    private Player p1, p2, p3;
    
    public void startGame()
    {
        p1 = new Player();
        p2 = new Player();
        p3 = new Player();
                
        boolean p1IsRight = false, p2IsRight = false, p3IsRight = false;
        
        System.out.println("I am thinking of a number ...");        
        int targetNumer = (int )(Math.random() * 10);
        while (true) {
            p1.guess();
            p2.guess();
            p3.guess();
            
            System.out.printf("Players guessed P1 %s, P2: %s P3: %s\n", p1, p2, p3);
            if (Integer.parseInt(p1.toString()) == targetNumer)
                p1IsRight = true;
            if (Integer.parseInt(p2.toString()) == targetNumer)
                p2IsRight = true;
            if (Integer.parseInt(p3.toString()) == targetNumer)
                p3IsRight = true;
            if (p1IsRight || p2IsRight || p3IsRight) {                
                System.out.printf("P1: %B, P2: %B, P3: %B\n", p1IsRight, p2IsRight, p3IsRight);
                System.out.println("Game over!");
                return;
            } else 
                System.out.println("Players will have to guess again!");
        }
    }       
    
}
