package subject_03;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MainForm extends JFrame {

    private final JTextArea textArea;
    private final JButton buttonSearch;
    private final JButton buttonSetFile;
    private final JButton buttonClose;

    private FileScanner scanner = null;

    public MainForm() 
    {
        setTitle("Search in a File");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Create text area
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Create buttons
        buttonSetFile = new JButton("Set File");
        buttonSearch = new JButton("Search");
        buttonSearch.setEnabled(false);
        buttonClose = new JButton("Close");

        // Add action listeners to buttons
        buttonSetFile.addActionListener((ActionEvent e) -> {
            selectFileButtonClicked();
        });

        // Add action listeners to buttons
        buttonSearch.addActionListener((ActionEvent e) -> {
            addButtonClicked();
        });

        buttonClose.addActionListener((ActionEvent e) -> {
            closeButtonCLicked();
        });

        // Create bottom panel and add buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        bottomPanel.add(buttonSetFile);
        bottomPanel.add(buttonSearch);
        bottomPanel.add(buttonClose);

        // Create main panel and add components
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        // Add main panel to the frame
        add(mainPanel);

        setVisible(true);
    }

    private void closeButtonCLicked() 
    {
        dispose();
    }    

    private void addButtonClicked() 
    {
        String searchWord = JOptionPane.showInputDialog(this, "Enter word to search for");
        // if user pressed cancel
        if (searchWord == null) {
            return;
        }
        try {
            if (scanner.scanForWord(searchWord)) {
                var list = scanner.getLines();
                textArea.append(String.format(
                        "Word %s has benn found in the following lines %s\n",
                        searchWord,
                        list.toString()
                ));
            } else {
                textArea.append(String.format(
                        "Word %s has not benn found in the search file\n",
                        searchWord
                ));
            }
        } catch (Exception ex) {
            textArea.append(String.format(("Error search: \n"), ex.getMessage()));
        }
    }

    private void selectFileButtonClicked() 
    {
        String filename = JOptionPane.showInputDialog(this, "Enter file to scan");
        if (filename == null) 
            return;       
        try {
            scanner = new FileScanner(filename);
            textArea.append(String.format("File %s selected for searching\n", filename));
            buttonSearch.setEnabled(true);
        } catch (Exception ex) {
            textArea.append(String.format("File %s not found!\n", filename));
            buttonSearch.setEnabled(false);
        }
    }
    
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(() -> {
            MainForm myForm = new MainForm();
        });
    }
}
