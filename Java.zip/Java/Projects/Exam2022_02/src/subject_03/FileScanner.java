/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package subject_03;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.LinkedList;

public class FileScanner {
    private final String fileName;
    private final List<Integer> lines = new LinkedList<>();
    
    public FileScanner(String aFileName)
        throws Exception
    {
        fileName = aFileName;
        File file = new File(aFileName);
        if (!file.exists()) 
            throw new Exception("File not found");                
    }

    public List<Integer> getLines()
    {
        List<Integer> result = new LinkedList<>();
        for (var line : lines)
            result.add(line);
        return result;
    }

    public boolean scanForWord(String aWord)
            throws IOException
    {
        lines.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(this.fileName))) {
            String line;
            int currentLine = 0;
            // Read lines until the end of the file
            while ((line = br.readLine()) != null) {
                currentLine++;
                if (line.toUpperCase().contains(aWord.toUpperCase()))
                    lines.add(currentLine);
            }
            return !lines.isEmpty();
        }
    }
}
