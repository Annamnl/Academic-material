/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2022_02;

interface inter1 {

    default int method1()
    {
        return -1;
    }
}

interface inter2 {

    default int method1()
    {
        return 0;
    }
}

class Subject_02 implements inter1, inter2 {

    // this method is not compartible with the inter1 and inter2 method1()
    public int method1(int[] x)
    {
        return x.length;
    }

    @Override
    public int method1()
    {
        return 100;
    }


    public static void main(String[] args)
    {
        System.out.println(new Subject_02().method1());
    }
}
