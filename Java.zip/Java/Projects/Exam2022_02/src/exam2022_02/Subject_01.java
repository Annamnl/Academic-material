/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exam2022_02;

/**
 * RuntimeException is a subclass of Exc exception. So if the
 * the code here throws an Exception it will never catch a
 * RuntimeException
 */
public class Subject_01 {

    public static void testException(int x, int y) throws Exception
    {
        try {
            if (x <= y) {
                throw new Exception();
            } else {
                System.out.println("No problem!!!");
            }
            System.out.println("Tried it all!");
        } catch (RuntimeException e) {
            System.out.println("Run time exception ");
        } finally {
            System.out.println("Finally ");
        }
    }

    public static void main(String args[])
    {
        int x = 9, y = 9;

        try {
            System.out.println("Main 1");
            testException(x, y);
            System.out.println("Main 2");
        } catch (Exception e) {
            System.out.println("Exception ");
        }
        System.out.println("End of program");
    }

}
