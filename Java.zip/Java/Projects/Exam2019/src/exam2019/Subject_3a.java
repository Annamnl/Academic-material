/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019;

public class Subject_3a {    
    
    // A static nested class does not have access to the instance variables and methods of the outer class
    // unless they are static.
    public static class Car {  // line 1
        private String kind;

        public Car(String aKind)
        {
            this.kind = aKind;
        }
    }

    public static void setKind(Car aCar)
    {
        aCar.kind = "Coupe";
        System.out.println("Kind of Car (method-1): " + aCar.kind);
    }

    public static void main(String args[])
    {
        Subject_3a.Car car = new Car("SUV");
        
        System.out.println("Kind of Car (main-1): " + car.kind);
        setKind(car);
        System.out.println("Kind of Car (main-2): " + car.kind);                
        
    }
}
