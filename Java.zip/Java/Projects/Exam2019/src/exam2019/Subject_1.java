/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exam2019;

public class Subject_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        String s1 = new String("Good luck!!!");
        String s2 = new String("Good luck!!!");
        String s3 = "Good luck!!!";
        String s4 = s1;

        System.out.println(s1 == s2);                   // false: different objects
        System.out.println(s1.equals(s2));     // true : same letters
        System.out.println(s1 == s3);                   // false: different objects
        System.out.println(s1 == s4);                   // true : s4 => s1 hence s1 == s4
        System.out.println(s2.equals(s4));     // true : same letters
        System.out.println(s3 == "Good" + " luck!!!");  // true : we already have a "Good luck!!!" string so the runtime uses it
        System.out.println(s3.hashCode() == "Good luck!!!".hashCode()); // s2.queals("Good luck!!!") == true hemce hashcodes are the same

        System.out.println(s1.intern() == s3.intern()); //
    }

}
