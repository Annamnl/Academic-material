/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019;

public class Subject_3b {
    // A static nested class does not have access to the instance variables and methods of the outer class
    // unless they are static.
    public class Car {  // line 1
        private String kind;

        public Car(String aKind)
        {
            kind = aKind;
        }
    }

    public static void setKind(Car car)
    {
        car.kind = "Coupe";
        System.out.println("Kind of Car (method-1): " + car.kind);
    }

    public static void main(String args[])
    {
        Subject_3b obj = new Subject_3b();
        // We create instances of innewr NON static classes thriugh objects of
        // the container class
        Subject_3b.Car car = obj.new Car("SUV");

        System.out.println("Kind of Car (main-1): " + car.kind);
        setKind(car);
        System.out.println("Kind of Car (main-2): " + car.kind);
    }
}
