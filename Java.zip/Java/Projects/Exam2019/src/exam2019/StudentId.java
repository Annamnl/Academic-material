package exam2019;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class StudentId {

    Integer id;

    StudentId(Integer id)
    {
        this.id = id;
    }

    @Override
    public boolean equals(Object o)
    {
        //return ((StudentId) o).id.equals(id);
        return ((StudentId) o).id == id;
    }

    @Override
    public int hashCode()
    {
        return this.id.hashCode();
    }
    
    public static void main(String args[])
    {
        Map m = new HashMap();
        Integer i1 = 1; // ==> new Integer(1);
        Integer i2 = 2; // ==> new Integer(2);
        Integer i3 = i1; // ==> new Integer(1);
        Integer i4 = new Integer(2); // ==> new Integer(1);
        
        StudentId m1 = new StudentId(i1);
        StudentId m2 = new StudentId(i2);
        StudentId m3 = new StudentId(i3);
        StudentId m4 = new StudentId(i4);

        m.put(m1, "student 1");
        m.put(m2, "student 2");
        m.put(m3, "student 3");
        m.put(m4, "student 4");
        System.out.println(m.size());
        Iterator<Integer> it = m.keySet().iterator();
        while (it.hasNext()) {
            System.out.println(m.get(it.next()));
        }
    }

}
