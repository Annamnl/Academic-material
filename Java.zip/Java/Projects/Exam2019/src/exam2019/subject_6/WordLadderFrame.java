/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019.subject_6;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class WordLadderFrame extends JFrame {
    public static final String OUTPUT_FILENAME = "words.txt";
    private static WordLadderFrame mainFrame = null;

    private final JTextField textField;
    private final JTextArea textArea;
    private final WordLadder engine = new WordLadder();

    public WordLadderFrame() {
        setTitle("Word Ladder Frame");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create TextField
        textField = new JTextField();
        add(textField, BorderLayout.NORTH);

        // Create TextArea
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Using FlowLayout with spacing

        // Create Close Button
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener((ActionEvent e) -> {
            closeButtonClicked();
        });
        buttonPanel.add(closeButton);

        // Create Action Button
        JButton checkButton = new JButton("Check and Add");
        checkButton.addActionListener((ActionEvent e) -> {
            addWordButtonClicked();
        });
        buttonPanel.add(checkButton, BorderLayout.EAST);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void closeButtonClicked()
    {
        try {
            engine.saveToFile(OUTPUT_FILENAME);
            dispose(); // Close the frame
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(mainFrame, ex.getMessage(), "Cannot save file", JOptionPane.OK_OPTION);
        }
    }
    
    private void addWordButtonClicked()
    {
        // Perform additional action (for example, append text to the TextArea)
        String newText = textField.getText().toUpperCase();
        try {
            if (newText.equals("")) {
                closeButtonClicked();
                return;
            }
            engine.addWord(newText);
            textArea.append(newText + "\n");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(mainFrame, ex.getMessage(), "Cannot add word", JOptionPane.OK_OPTION);
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            mainFrame = new WordLadderFrame();
        });
    }
}
