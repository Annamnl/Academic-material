/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019.subject_6;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class WordLadder {

    private final List<String> words;
    private String lastWord;

    public WordLadder()
    {
         words = new LinkedList<>();
         lastWord = null;
    }
    
    public void addWord(String aWord)
            throws Exception
    {
        if (lastWord != null) {
            if (aWord.length() != lastWord.length())
                throw new Exception("Word length incorrect!");
            if (!canBeNext(lastWord, aWord))
                throw new Exception("Words differ to more than one letter!");
        }

        lastWord = aWord;
        words.add(aWord);
    }

    private boolean canBeNext(String prevWord, String curWord)
    {
        int timesDiffer = 0;
        for (int i = 0; i < prevWord.length(); i++)
            if (prevWord.charAt(i) != curWord.charAt(i))
                timesDiffer++;
        return timesDiffer == 1;
    }

    public void saveToFile(String filename)
            throws IOException
    {
         try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            // Writing set elements to the file
            for (String element : words) {
                writer.write(element);
                writer.newLine(); // Add a new line for each element
            }            
        }
    }
}
