/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019;

/**
 * When you perform arithmetic operations on byte, short, or char types in Java, they undergo implicit type
 * promotion to int before the operation is executed. This is because Java performs most arithmetic
 * calculations using at least int precision by default.
 */
public class Subject_2 {

    public static void main(String[] args)
    {
        byte b=7;
        b += 5;                 // <=>  b = (byte)(b + 5);
        System.out.println(b);
        b = (byte) (b + 10);    // b+ 10 is int
        System.out.println(b);
    }
}
