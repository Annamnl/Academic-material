/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019.subject_5;

class Employer {
    private String name;
    private int workYears;

    public Employer(String name, int workYears) throws Exception {
        if (workYears < 0)
            throw new Exception("Illegal Negative Valuel");
        else {
            this.name = name;
            this.workYears = workYears;
        }
    }
}

public final class SalariedEmployer extends Employer {
    private float salary;

    public SalariedEmployer(String name, int workYears, float salary) throws Exception {
        super(name, workYears);
        this.salary=salary;
    }

    public static void main(String args[]) {
        try {
            SalariedEmployer emp1=new SalariedEmployer("Nikos Pappas", 13, 1299);
        } catch (Exception ex) {
            System.out.println("Oups! " + ex.getMessage());
        }
    }
}
