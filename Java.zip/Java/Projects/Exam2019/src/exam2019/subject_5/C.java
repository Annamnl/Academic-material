/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exam2019.subject_5;

public class C {

    static {
        x = 70;
    }

    static {
        x = 50;
    }

    static int x = 30;
    
    public static void main(String[] args) {
        System.out.println(C.x);
    }
}
