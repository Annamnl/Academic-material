/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalspoly;

public class Bird extends Animal {
    public Bird(String aName){
        super(aName);
    }
    
    @Override
    public void makeNoise(){
        System.out.printf("%s tweet tweet\n", name);
    }
}
