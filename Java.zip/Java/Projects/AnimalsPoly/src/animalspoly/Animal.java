/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalspoly;

public class Animal {
    protected final String name;
    
    public Animal(String aName)
    {
        this.name = aName;
    }
    
    public void eat()
    {
        System.out.printf("%s is eating.\n", toString());
    }
    
    public void makeNoise()
    {
        System.out.printf("%s does not know how to do this.\n", toString());
    }
    
    @Override
    public String toString()
    {
        return String.format("%s: %s", this.getClass().getSimpleName(), name);
    }
    
}
