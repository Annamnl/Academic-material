/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalspoly;

public class Dog extends Animal {
    public Dog(String aName){
        super(aName);
    }
    
    /**
     * Tell the user that the dog is eating
     */
    @Override
    public void eat(){
        System.out.printf("%s dog eats\n", name);
    }
    
    @Override
    public void makeNoise(){
        System.out.printf("%s woof woof\n", name);
    }
}
