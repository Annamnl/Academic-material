/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animalspoly;

import java.util.Scanner;

public class Program {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("null")
    public static void main(String[] args) {
        Animal[] animals = new Animal[5];

        for (int i = 0; i < animals.length; i++) {
            animals[i] = getAnAnimal();
        }

        for (var animal : animals) {
            // System.out.println(animal);

            if (animal instanceof Cat) {
                Cat c = (Cat) animal;
                c.eat(5);
            } else {
                animal.eat();
            }

            animal.makeNoise();
        }
    }

    public static Animal getAnAnimal() {
        Animal result = null;
        Scanner s = new Scanner(System.in);
        String inputLine, name = null;

        System.out.print("Enter (A)nimal, (D)og, (C)at, (B)ird (H)ippo:");
        inputLine = s.nextLine().trim().toLowerCase();

        if (inputLine != "h") {
            System.out.print("Enter name:");
            name = s.nextLine();
        }

        switch (inputLine) {
            case "d":
                System.out.printf("Here is %s the dog!\n", name);
                result = new Dog(name);
                break;
            case "c":
                System.out.printf("Here is %s the cat!\n", name);
                result = new Cat(name);
                break;
            case "b":
                System.out.printf("Here is %s the bird!\n", name);
                result = new Bird(name);
                break;
            case "h":
                System.out.printf("Here is %s the hippo\n", name);
                result = new Hippo();
                break;
            default:
                System.out.printf("Here is %s the animal!\n", name);
                result = new Animal(name);
                break;
        }

        s.close();
        return result;
    }
}
