/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalspoly;

public class Cat extends Animal {    
    
    public Cat(String aName){
        super(aName);
    }    
    
    public void eat(int nFish)
    {
        System.out.printf("%s is eating %d fish\n", name, nFish);
    }
    
    @Override
    public void makeNoise(){
        System.out.printf("%s meows\n", name);
    }
    
}
