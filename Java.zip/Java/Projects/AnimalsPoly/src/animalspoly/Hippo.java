/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animalspoly;

public class Hippo extends Animal {
    
    private static int hippoCounter = 0;
    
    public Hippo()
    {
        super(String.format("Pantelis %d", ++hippoCounter));
    }
}
