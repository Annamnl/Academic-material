package library;

public class Book {
    private final String title;
    private final String author;
    private final int year;
    private final String subject;

    public Book(String title, String author, int year, String Subject) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.subject = Subject;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYear() {
        return year;
    }

    public String getSubject() {
        return subject;
    }
    
    @Override
    public String toString()
    {
        return String.format("%s: by %s on %s Published %d", title, author, subject, year);
    }
    
}
