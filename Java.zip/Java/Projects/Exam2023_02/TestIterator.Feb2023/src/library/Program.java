package library;

import java.util.Iterator;

public class Program {

    public static void main(String[] args) {
        Library myLib = new Library();

        myLib.addBook(new Book("Title1", "Author1", 2013, "Πολιτικές και Κοινωνικές Επιστήμες"));
        myLib.addBook(new Book("Title2", "Author2", 1924, "Ιστορία"));
        myLib.addBook(new Book("Title3", "Author3", 1981, "Λογοτεχνία"));
        myLib.addBook(new Book("Title4", "Author4", 1931, "Ιστορία"));
        myLib.addBook(new Book("Title5", "Author5", 1927, "Ψυχολογία"));
        
        Iterator it = myLib.getRareBooksIterator();

        //Iterator for list traversing
        while (it.hasNext()) {
            System.out.println(it.next());
        }

    }

}
