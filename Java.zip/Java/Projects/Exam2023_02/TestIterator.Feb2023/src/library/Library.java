package library;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class Library {
    private final List <Book> books = new ArrayList<>();
    
    public void addBook(Book mybook){
        books.add(mybook);
    }
    
    public Iterator<Book> getRareBooksIterator(){
        return new RareBooksIterator();
    }

    public class RareBooksIterator implements Iterator<Book> {
        private int nextIndex;
        
        public RareBooksIterator()
        {
            nextIndex = -1;
            // locate the first rate book      
            locateNextItem();
        }
        
        @Override
        public boolean hasNext() {
            return nextIndex < books.size();
        }

        @Override
        public Book next() {
            if (nextIndex < books.size()) {
                Book result = books.get(nextIndex);
                locateNextItem();
                return result;
            }
            throw new NoSuchElementException();
        }
        
        private void locateNextItem()
        {
            nextIndex++;
            while (nextIndex < books.size()) {
                Book b = books.get(nextIndex);
                if (b.getYear() < 1933 && b.getSubject().equals("Ιστορία"))
                    break;
                nextIndex++;
            }
        }
    }

}
