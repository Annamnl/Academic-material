package airlinetoamsterdam;

import java.util.Scanner;

public class Program {

    static final int MAX_FLIGHTS = 20;
    static FlightGroup myGroup = new FlightGroup("January Flights to Amsterdam", MAX_FLIGHTS);
    static Scanner scanner;

    public static void main(String[] args)
    {
        scanner = new Scanner( System.in);

        char currentChoice;
        do {
            currentChoice = displayMenu();
            executeCommand( currentChoice);
        } while (currentChoice != 'x');

        scanner.close();
    }

    private static char displayMenu()
    {
        String currentLine;

        while (true) {
            try {
                System.out.println("Add (1) flight, Add (a)ll flights");
                System.out.println("Display a(v)erage capacity of flights");
                System.out.println("Display (G)ood flights, Display (W)orst flights or e(x)it");
                currentLine = scanner.nextLine();
                return currentLine.charAt(0);
            } catch (Exception ex) {
                System.err.println("please eneter a valid choice");
            }
        }
    }

    private static void executeCommand(char selection)
    {
        switch (selection) {
            case '1' -> addOneFlight();
            case 'a' -> addAllFlights();
            case 'g' -> displayGoodFlights();
            case 'w' -> displayWorseDays();
            case 'v' -> displayAverageCapacityOfFlights();
            case 'x' -> {
                System.out.print("Goodbye");
            }
            default -> {
                System.out.println("Invalid command specified!");
            }
        }
    }

    private static void addOneFlight()
    {
        int flightNumber, capacity, dayOfMonth;
        String planeName;

        flightNumber = getInteger("Enter flight No:", 0, 999);
        capacity = getInteger("Enter capacity", 1, 100);
        dayOfMonth = getInteger("Enter day of Month", 1, 31);
        System.out.print("Enter plane name:");
        planeName = scanner.nextLine();

        try {
            Flight f = new Flight(flightNumber, dayOfMonth, planeName, capacity);
            myGroup.addFlight(f);
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }
    }

    private static void addAllFlights()
    {
        for (int i = 0; i< MAX_FLIGHTS; i++) {
            System.out.printf("Entering data for flight %d out of %d.\n", i+1, MAX_FLIGHTS);
            addOneFlight();
        }
    }

    private static void displayGoodFlights()
    {
        try {
            myGroup.saveGoodFlights("good-flights.txt");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void displayWorseDays()
    {
        try {
            myGroup.displayWorseDays();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void displayAverageCapacityOfFlights()
    {
        try {
            double capacity = myGroup.getAverageCapacity();
            System.out.printf("Average capacity of flights is %.2f%%\n", capacity);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static int getInteger(String prompt, int minValue, int maxValue)
    {
        String currentLine;
        int result;

        while (true) {
            System.out.print(prompt);
            currentLine = scanner.nextLine();
            try {
                result = Integer.parseInt(currentLine);
                if (result > maxValue || result < minValue)
                    throw new Exception("Number of of limits");
                return result;
            } catch (Exception ex) {
                System.err.println(ex.getMessage());
            }
        }
    }


}
