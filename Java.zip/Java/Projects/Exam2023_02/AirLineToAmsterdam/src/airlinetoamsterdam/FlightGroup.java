package airlinetoamsterdam;

import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FlightGroup {
    private final int size;
    private final String name ;
    private final Flight[] flights;

    public FlightGroup( String name, int numFlights)
    {
        this.name = name;
        this.size = numFlights;
        flights = new Flight[numFlights];
    }

    public void addFlight(Flight f)
            throws Exception
    {
        int i = 0;
        while (flights[i] != null) {
            i++;
            if (i == size)
                throw new Exception("No more space left in Group");
        }
        flights[i] = f;
    }

    public double getAverageCapacity()
            throws Exception
    {
        int sum = 0;
        int total = 0;
        for (Flight f : flights) {
            if (f == null)
                continue;
            sum += f.getCapacity();
            total++;
        }

        if (total == 0)
            throw new Exception("No flights in Group!");
        return 1.0 * sum / total;
    }

    public void saveGoodFlights(String fileName)
            throws Exception
    {
        System.out.println(name);
        
        double averageCapacity = getAverageCapacity();
        List<String> linesToSave = new ArrayList<>();
        for (Flight f : flights) {
            if (f == null)
                continue;

            if (f.getCapacity() >= averageCapacity) {
                System.out.println(f);
                linesToSave.add(f.toString());
            }
        }

        // write to text file
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(fileName))) {
            for (var line : linesToSave) {
                writer.write(line);
                writer.newLine();
            }
        }
    }

    public int getMinCapacity()
            throws Exception
    {
        int min = 100;
        int total = 0;
        for (Flight f : flights) {
            if (f == null)
                continue;
            if (min > f.getCapacity())
                min = f.getCapacity();
            total++;
        }

        if (total == 0)
            throw new Exception("No flights in Group!");
        return min;
    }

    public void displayWorseDays()
    {
        int minCapacity;

        try {
            minCapacity = getMinCapacity();
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
            return;
        }

        for (Flight f : flights) {
            if (f == null)
                continue;
            if (f.getCapacity() == minCapacity)
                System.out.println(f);
        }
    }
}
