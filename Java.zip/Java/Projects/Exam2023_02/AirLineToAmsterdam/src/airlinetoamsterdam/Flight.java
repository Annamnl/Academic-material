package airlinetoamsterdam;

public class Flight {
    private final int flightNumber;
    private final int dayInMonth;
    private final String planeName;
    private final int capacity;

    public Flight(int flightNumber, int dayinMonth, String planeName, int occupancy)
    {
        this.flightNumber = flightNumber;
        this.dayInMonth = dayinMonth;
        this.planeName = planeName;
        this.capacity = occupancy;
    }

    public int getCapacity()
    {
        return capacity;
    }

    public int getDayInMonth()
    {
        return this.dayInMonth;
    }

    @Override
    public String toString()
    {
        return String.format("Date %02d Number: %03d: Plane :%20s Occupancy %2d%%",
                dayInMonth,
                flightNumber,
                planeName,
                capacity);
    }
}
