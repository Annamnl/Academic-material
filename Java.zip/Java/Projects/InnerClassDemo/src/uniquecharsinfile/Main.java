package uniquecharsinfile;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Main {
    
    public static void main(String args[])
    {
        List<String> allWords = readFile("test.txt");
        printUniqueChars(allWords);
    }

    private static List<String> readFile(String filename) 
    {
        List<String> result = new LinkedList<>();
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(filename))) {
            String currentLine;
            while ((currentLine = reader.readLine()) != null) {                
                for (String word : currentLine.split("\\|"))
                    result.add(word.trim());
            }
        } catch (IOException ex) {
            System.err.println("IO Error: " + ex.getMessage());
        }
        return result;
    }

    private static void printUniqueChars(List<String> allWords) 
    {
        for (String word: allWords) 
            System.out.printf("%s -> %c\n", word, firstUniuqletter(word));
    }
    
    private static char firstUniuqletter(String aWord)
    {        
        Map<Character, Integer> times = new TreeMap<>();
        
        for (int i =0; i < aWord.length(); i++) {
            char currentChar = aWord.charAt(i);
            if (times.containsKey(currentChar)) 
                times.put(currentChar, 1 + times.get(currentChar));
            else
                times.put(currentChar, 1);                    
        }
         
        for (Character c : times.keySet())
            if (times.get(c) == 1)
                return c;
     
        return '|'; // no letter with 1 occurence
    }
}
