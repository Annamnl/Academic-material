
package triads;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Demo for String reverse and shuffle 
 */
public class Triad {
    private final String original, shuffled, reversed;
    
    public Triad( String A)
    {
        original = A;
        StringBuilder sbA = new StringBuilder(A);
        
        // create a list of characters
       List<Character> lettersList = new ArrayList<>();
       // add each character of the string
        for (int i = 0; i < sbA.length(); i++)
            lettersList.add(sbA.charAt(i));
        
        // use the static Collections shuffle to shuffle the array
        Collections.shuffle(lettersList);
        
        // create a new string builder to store the result
        StringBuilder tempShuffled = new StringBuilder();
        for (char s : lettersList)
            tempShuffled.append( s); 
        
        // save the final version of the string
        shuffled = tempShuffled.toString();
        
        // string builders have theit own reverse() method
        reversed = sbA.reverse().toString();
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %s", original, shuffled, reversed);
    }
    
    public static void main(String args[])
    {
        Triad t1 = new Triad("Thanassis");
        Triad t2 = new Triad("Anna");
        
        System.out.println(t1);
        System.out.println(t2);
    }
}
