/*
 * Run:

    After swappObjs: a = 6,000000 b = 7,000000
    After swapp: a = 6,000000 b = 7,000000
 */
package swapps;

public class TestSwapp {
    public static void main(String[] args)
    {
        Double a = 6.0;
        Double b = 7.0;
        
        swappObjs(a, b);
        System.out.printf("After swappObjs: a = %f b = %f\n", a, b);
        
        swapp(a, b);
        System.out.printf("After swapp: a = %f b = %f\n", a, b);
    }
    
    private static void swappObjs( Double x, Double y)
    {
        Double temp = x;
        x = y;
        y = temp;
    }
    
    private static void swapp( double x, double y)
    {
        double temp = x;
        x = y;
        y = temp;
    }
}
