/*
 * Output should be

    run:
    UBoat-Constructor
    MiniUBoat-Constructor
    MiniUBoat-UBoat-Constructor
    MiniUBoat-UBoat-launchTorpedo
    Simulator-Constructor
    MiniUBoat-Simulator-launchTorpedo
    UBoat-launchTorpedo
    MiniUBoat-UBoat-Constructor
    MiniUBoat-UBoat-launchTorpedo    

 */
package test;

class MiniUBoat extends UBoat {

    class UBoat {

        UBoat() {
            System.out.println("MiniUBoat-UBoat-Constructor");
        }

        void launchTorpedo() {
            System.out.println("MiniUBoat-UBoat-launchTorpedo");
        }
    }

    MiniUBoat() {
        System.out.println("MiniUBoat-Constructor");
    }    

    void release() {
        new UBoat().launchTorpedo();

        class Simulator {

            Simulator() {
                System.out.println("Simulator-Constructor");
            }

            void launchTorpedo() {
                System.out.println("MiniUBoat-Simulator-launchTorpedo");
            }
        }
        new Simulator().launchTorpedo();
    }

    public static void main(String[] args) {
        MiniUBoat mub = new MiniUBoat();
        mub.release();
        mub.launchTorpedo();
        mub.new UBoat().launchTorpedo();
    }
}