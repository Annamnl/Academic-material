package test;

class UBoat {

    UBoat() {
        System.out.println("UBoat-Constructor");
    }

    void launchTorpedo() {
        System.out.println("UBoat-launchTorpedo");
    }
}

