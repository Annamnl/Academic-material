
public class Cat extends Animal {

    String xrwma;

    public Cat(String xrwma, int varos) {
        super(varos);
        this.xrwma = xrwma;
    }

    public void speak() {
        System.out.println("niaou");
    }

}
