
import java.util.ArrayList;


public class Main {

    public static void main(String[] args) {
        Dog d = new Dog("Kanis", 4);
        Cat c = new Cat("Kafe", 2);
        Cow co = new Cow(220);
        
        ArrayList<Animal> anims = new ArrayList<>();
        anims.add(d);
        anims.add(c);
        anims.add(co);
        
        
        for (int i=0; i<anims.size(); i++){
            anims.get(i).speak();
        }
        
    }
}
