public class Cow extends Animal{
    
    public Cow(int varos) {
        super(varos);
    }

    @Override
    void speak() {
        System.out.println("mou");
    }
    
    
    
}
