
public class Dog extends Animal {

    String ratsa;

    public Dog(String ratsa, int varos) {
        super(varos);
        this.ratsa = ratsa;
    }

    public void speak() {
        System.out.println("gav gav");
    }
}
