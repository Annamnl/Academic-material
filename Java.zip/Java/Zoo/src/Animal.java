
import java.io.FileNotFoundException;
import java.io.FileReader;


public abstract class Animal {

    private int varos;

    public Animal(int varos) {
        this.varos = varos;
    }

    abstract void speak();
}
