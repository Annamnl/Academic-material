import java.util.*;

public class Book {
    private String title;
    ArrayList <Author> authors = new ArrayList<>();
    
    public Book(String title){
        this.title = title;
        
    }

    public Book(String title, ArrayList<Author> authors){
        this.title = title;
        this.authors = authors;
    }
    
    
    public String getTitle() {
        return title;
    }

    public void addAuthor(Author author){
        authors.add(author);
    }

    public ArrayList<Author> getAuthors() {
        return authors;
    }
    
    @Override
    public String toString(){
        return "Book Title: " + this.title + "\nhas authors: " + this.authors;
    }
    
 
}
