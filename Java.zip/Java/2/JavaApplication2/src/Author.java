import java.util.*;
        
public class Author {
    private String name;
    private String id;
    ArrayList <Book> books = new ArrayList<>();
    
    public Author(String name, String id){
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public ArrayList<Book> getBooks() {
        return books;
    }

    public void addBooks(Book book) {
        books.add(book);
    }

    @Override
    public String toString() {
        return "Author{" + "name=" + name + ", id=" + id + ", books=" + books + '}';
    }

    
}
