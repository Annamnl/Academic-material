import java.util.*;
        
public class Main {

    public static void main(String[] args) {
         
        Author a1 = new Author("giannis","papadopoylos");
	Author a2 = new Author("nikos", "ioannou");
	Author a3 = new Author("xaris","krhtikos");
        ArrayList<Author> list = new ArrayList<>(); 
        list.add(a1);
        list.add(a2);
        list.add(a3);
        
	Book b1 = new Book("to kuma");
	Book b2 = new Book("h gefyra");
	Book b3 = new Book("barka");
        
	a1.addBooks(b1);
	a2.addBooks(b2);
	a3.addBooks(b3);
        
        b1.addAuthor(a3);
        
        System.out.println(a1.toString());
        System.out.println(a1.books);
        System.out.println(b1.getAuthors().toString());
    }
    
}
