import java.util.*;
public class Ship {
    private int length;

    public Ship(int length) {
        this.length = length;
    }
    
   
    
}
