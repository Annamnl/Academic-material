import java.util.*;

public class AircraftCarrier extends Ship{

    public AircraftCarrier(int length) {
        super(4);
    }


    
    
}
