import java.util.*;

public class Battleship extends Ship{

    public Battleship(int length) {
        super(5);
    }


    
    
}
