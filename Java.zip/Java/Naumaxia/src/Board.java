import java.util.*;

public class Board {
    private int board[][];
    Player player = new Player();
    Player computer = new Player();
    //ArrayList <Ship> ships = new ArrayList<>();
    private int ships[][];
    Battleship battleship = new Battleship();
    AircraftCarrier carrier = new AircraftCarrier();
    Submarine submarine = new Submarine();
    Destroyer destroyer = new Destroyer();
    SmallShip small = new SmallShip();

    public Board(int[][] board) {
        this.board = board;
    }

    public Board(int[][] board, int[][] ships) {
        this.board = board;
        this.ships = ships;
    }

    public Board() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     
    
    public void initBoard(int board[][]){
        int row, column;
        for(row=0;row<5;row++)
            for(column=0;column<5;column++)
                board[row][column]=-1;
    }
    
    public void showBoard(int board[][]){
        int row, column;
        System.out.println("\t1 \t2 \t3 \t4 \t5");
        System.out.println();
        
        for(row=0;row<5;row++){
            System.out.print((row+1)+"");
            for(column=0;column<5;column++){
                switch (board[row][column]) {
                    case -1:
                        System.out.print("\t"+"~"); //No shot
                        break;
                    case 0:
                        System.out.print("\t"+"*"); //Shot but no ship there
                        break;
                    case 1:
                        System.out.print("\t"+"X"); //Shot and had a ship there
                        break;
                    default:
                        break;
                }                
            }
            System.out.println();
        }
    }
    
    public void initShip(int ships[][]){
        Random random = new Random();
        
       
    }
    
    public boolean hit(int shot[], int ships[][]){
        return false;
    }
    
    public void refreshBoard (int shot[], int ships[][], int board[][]){
        if(hit(shot,ships))
            board[shot[0]][shot[1]]=1;
        else
            board[shot[0]][shot[1]]=0;
    }
    
    
    
}
