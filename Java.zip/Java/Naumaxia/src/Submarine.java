import java.util.*;

public class Submarine extends Ship{

    public Submarine(int length) {
        super(3);
    }
    
    
}
