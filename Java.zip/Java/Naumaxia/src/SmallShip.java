import java.util.*;

public class SmallShip extends Ship{

    public SmallShip(int length) {
        super(2);
    }
    
    
}
