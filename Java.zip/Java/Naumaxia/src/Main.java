import java.util.*;

public class Main {


    public static void main(String[] args) {
        int board[][] = new int[10][10];
        Board board1 = new Board(board);
        int ships[][] = new int[3][2];
        int shoot[] = new int[2];
        int attempts=0;
        int hit=0;
        
        
        board1.initBoard(ships);
        board1.initShip(ships);
        
        
    }
    
}
