import java.util.*;

public class Player {
    private int turn;
    private int life = 3;
    private int shots[];
    private int fire[];
    private int attempts;

    public Player() {
    }

    public Player(int turn, int[] shots, int[] fire, int attempts) {
        this.turn = turn;
        this.shots = shots;
        this.fire = fire;
        this.attempts = attempts;
    }

    public void setTurn(Player p) {
            if(this.turn==1){
                System.out.print(turn);
            }
            else{
                System.out.print("Opponents's turn");
            }
        }
        
    
    public void shoot(int shots[]){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Row: ");
        shots[0] = input.nextInt();
        shots[0]--;
        
        System.out.print("Column: ");
        shots[1] = input.nextInt();
        shots[1]--;
    }
    
}

