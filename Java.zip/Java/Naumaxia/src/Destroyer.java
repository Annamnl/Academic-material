import java.util.*;

public class Destroyer extends Ship{

    public Destroyer(int length) {
        super(3);
    }
    
    
}
