import java.util.*;

public class Main {


    public static void main(String[] args) {
        Dice d1 = new Dice();
        Dice d2 = new Dice();
        
        d1.rollDice(d1);
        d2.rollDice(d2);
        System.out.println(d1.toString());
        System.out.println(d2.toString());
    }
    
}
