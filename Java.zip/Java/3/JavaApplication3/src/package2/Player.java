package package2;
import java.util.*;

public class Player {
    private int turn;
   // Dice diceP = new Dice();
    
    
    public Player(){}
    
    public Player(int turn){
        this.turn = turn;
    }

    public void setTurn(Dice Dice) {
        if(this.turn==1){
            System.out.print(turn);
        }
        else{
            System.out.print("Computer's turn");
        }
    }
    
    public void Sum(Dice dice){
        int diceSum;
        diceSum = rollDice(Dice dice) +
    }
    
    
    
}
