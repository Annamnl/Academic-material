package package2;
import java.util.*;

public class Main2 {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
