package package2;
import java.util.*;

public class Dice {
    private int randomValue;
    private int HIGHEST_DICE_VALUE;
    private int LOWEST_DICE_VALUE;
    
    public Dice(){
        this.HIGHEST_DICE_VALUE = 6;
        this.LOWEST_DICE_VALUE = 1;
    }
    
    public Dice(int randomValue, int HIGHEST_DICE_VALUE, int LOWEST_DICE_VALUE){
        this.randomValue = randomValue;
        this.HIGHEST_DICE_VALUE = HIGHEST_DICE_VALUE;
        this.LOWEST_DICE_VALUE = LOWEST_DICE_VALUE;
        }
    
    public void rollDice(Dice dice){
        randomValue = (((int)(Math.random()*100))% HIGHEST_DICE_VALUE + LOWEST_DICE_VALUE);
    }

    @Override
    public String toString() {
        return "Dice{" + "Value=" + randomValue + '}';
    }
    
    
}
