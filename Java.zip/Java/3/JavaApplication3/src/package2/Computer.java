package package2;
import java.util.*;

public class Computer {
    private int turn;
    private int diceSum;

        
}
