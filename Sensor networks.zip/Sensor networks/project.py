#Manoltsidou Anna - 321/2016103
import paho.mqtt.client as mqtt
import ssl
import os
import sys
import matplotlib.pyplot as plt 
from matplotlib.widgets import Button
from threading import Timer
from datetime import datetime

class App:
    #Constructor
    def Client(self, client_id="", clean_session = True, userdata = None, protocol = mqtt.MQTTv311, transport="tcp"):
        self.client= mqtt.Client()
        self._establish_mqtt_connection()
        self.client.on_connect = self._on_connect  #Once the connection installation is complete, the method will be called
        self.ax = None
        self._establish_mqtt_connection()
        self._prepare_graph_window() 

    #Method to start the client loop
    def start(self):
        self.client.on_log = self._on_log
        self.client.tls_set_context(ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)) #We will use encryption to transmit / receive messages
        self.client.on_message = self._on_message
        self.client.username_pw_set('iotlesson', 'YGK0tx5pbtkK2WkCBvJlJWCg') #We define the username with the password
        #Method used to send a message to the MQTT broker
        self.client.publish('hscnl/hscnl02/sendcommand/ZWaveNode006_Switch', 'ON')
        self.client.publish('hscnl/hscnl02/sendcommand/ZWaveNode006_Switch', 'OFF')
        
        if self.ax:
            self.client.loop_start()
            plt.show()
        else:
            self.client.loop_forever()
        
        self.client.loop_forever()

    #Method to disconnect from the broker
    def disconnect(self, args=None):
        self.client.disconnect()
        
    #Method to connect to the broker
    def _establish_mqtt_connection(self):
        #We start the connection with the MQTT broker, and we define the DNS name of the server, and the port where the connection will be made
        self.client.connect("phoenix.medialab.ntua.gr", 8883) 
        
    #Callback that will be called after the connection is established
    def _on_connect(self, client, userdata, flags, rc):
        if rc==0:
            self.client.connected_flag=True #set flag
            print("Connected with result code "+str(rc))
        else:
            print("Bad connection Returned code=",rc)

        #Methods to start monitoring the topic that is in the parameter
        #It shows us the condition of the socket    
        client.subscribe('hscnl/hscnl02/state/ZWaveNode006_Switch/state')
        #Shows us the commands that have been sent to the smart plug
        client.subscribe('hscnl/hscnl02/command/ZWaveNode006_Switch/command')
        #It shows us the instantaneous load consumption in Watt
        client.subscribe('hscnl/hscnl02/state/ZWaveNode006_ElectricMeterWatts/state')

    #Callback that will be called whenever a new message is received
    def _on_message(self, client, userdata, msg):
        if msg.topic == 'hscnl/hscnl02/state/ZWaveNode006_ElectricMeterWatts/state':
            self._add_value_to_plot(float(msg.payload))
        print("Received message '" + str(msg.payload) + "' on topic '" + msg.topic + "' with QoS " + str(msg.qos))

    #Callback that will be called whenever a new log event is created
    def _on_log(self, client, userdata, level, buf):
        print('log: ', buf)

    #Initiallization of the graph
    def _prepare_graph_window(self):
        # Plot variables
        plt.rcParams['toolbar'] = 'None'
        self.ax = plt.subplot(111)
        self.dataX = []
        self.dataY = []
        self.first_ts = datetime.now()
        self.lineplot, = self.ax.plot(
        self.dataX, self.dataY, linestyle='--', marker='o', color='b')
        self.ax.figure.canvas.mpl_connect('close_event', self.disconnect)
        self.finishing = False
        self._my_timer()

        #Add 2 buttons and a text field on the graph
        axcut = plt.axes([0.0, 0.0, 0.1, 0.06])
        self.bcut = Button(axcut, 'ON')
        axcut2 = plt.axes([0.1, 0.0, 0.1, 0.06])
        self.bcut2 = Button(axcut2, 'OFF')
        self.state_field = plt.text(1.5, 0.3, 'STATE: -')
        self.bcut.on_clicked(self._button_on_clicked)
        self.bcut2.on_clicked(self._button_off_clicked)

    #To refresh the graph when new results are obtained or the x-axis display changes
    def _refresh_plot(self):
        if len(self.dataX) > 0:
            self.ax.set_xlim(min(self.first_ts, min(self.dataX)),
            max(max(self.dataX), datetime.now()))
            self.ax.set_ylim(min(self.dataY) * 0.8, max(self.dataY) * 1.2)
            self.ax.relim()
        else:
            self.ax.set_xlim(self.first_ts, datetime.now())
            self.ax.relim()
        plt.draw()

    #Add new value to the graph
    def _add_value_to_plot(self, value):
        self.dataX.append(datetime.now())
        self.dataY.append(value)
        self.lineplot.set_data(self.dataX, self.dataY)
        self._refresh_plot()

    #To automatically move the graph to the right every second
    def _my_timer(self):
        self._refresh_plot()
        if not self.finishing:
            Timer(1.0, self._my_timer).start()

    #2 operators for the buttons
    def _button_on_clicked(self, event):
        self.client.publish('hscnl/hscnl02/sendcommand/ZWaveNode006_Switch', 'ON')

    def _button_off_clicked(self, event):
        self.client.publish('hscnl/hscnl02/sendcommand/ZWaveNode006_Switch', 'OFF')



try:
    app = App()
    app.Client()
    app.start()
except KeyboardInterrupt:  #KeyboardInterrupt = when the user presses Ctrl+c, Ctrl+z or Delete
    print('Interrupted')
    try:
        app.disconnect()
        sys.exit(0)
    except SystemExit:
        os._exit(0)
