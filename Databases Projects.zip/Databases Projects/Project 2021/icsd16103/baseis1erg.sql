-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Εξυπηρετητής: 127.0.0.1
-- Χρόνος δημιουργίας: 30 Μάη 2021 στις 18:38:57
-- Έκδοση διακομιστή: 10.4.19-MariaDB
-- Έκδοση PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `baseis1erg`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `actor`
--

CREATE TABLE `actor` (
  `ID` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `age` int(11) NOT NULL,
  `country` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `actor`
--

INSERT INTO `actor` (`ID`, `name`, `age`, `country`) VALUES
(3, 'Grant Gustin', 31, 'USA'),
(4, 'Candice Patton', 32, 'USA'),
(5, 'Carlos Valdes', 32, 'Colombia'),
(6, 'Danielle Panabaker', 33, 'USA'),
(7, 'Jesse L. Martin', 52, 'USA'),
(8, 'James Spader', 61, 'USA'),
(9, 'Megan Boone', 38, 'USA'),
(10, 'Diego Klattenhoff', 41, 'Canada'),
(11, 'Mozhan Marnò', 41, 'Canada'),
(12, 'Courtney Henggeler', 42, 'USA'),
(13, 'Ralph Macchio', 59, 'USA'),
(14, 'Jorge Garcia', 48, 'USA'),
(15, 'Yunjin Kim', 47, 'Seul'),
(16, 'Emilie de Ravin', 38, 'Australia'),
(17, 'Henry Ian Cusick', 54, 'Peru'),
(18, 'Dominic Purcell', 51, 'United Kingdom'),
(19, 'Wentworth Miller', 48, 'United Kingdom'),
(20, 'Sarah Wayne Callies', 43, 'USA'),
(21, 'Amaury Nolasco', 50, 'Puerto Rico'),
(22, 'Robert Knepper', 61, 'USA'),
(23, 'Kiefer Sutherland', 54, 'United Kingdom'),
(24, 'Mary Lynn Rajskub', 49, 'USA'),
(25, 'Carlos Bernard', 58, 'USA'),
(26, 'Bryan Cranston', 65, 'SPAIN'),
(27, 'Aaron Paul', 41, 'SPAIN'),
(28, 'Anna Gunn', 52, 'USA'),
(29, 'RJ Mitte', 28, 'USA'),
(30, 'Bob Odenkirk', 58, 'USA'),
(31, 'Norman Reedus', 52, 'USA'),
(32, 'Melissa McBride', 54, 'USA'),
(33, 'Lauren Cohan', 39, 'USA'),
(34, 'Josh McDermitt', 42, 'USA'),
(35, 'Christian Serratos', 30, 'USA');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `series`
--

CREATE TABLE `series` (
  `ID` int(11) NOT NULL,
  `title` varchar(40) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `start_year` year(4) NOT NULL,
  `end_year` year(4) DEFAULT NULL,
  `channel` varchar(40) DEFAULT NULL,
  `seasons` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `series`
--

INSERT INTO `series` (`ID`, `title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES
(1, 'The Flash', 'Sci-Fi & Fantasy', 2014, 0000, 'CW', 7),
(2, 'The Blacklist', 'Mystery ', 2013, 0000, 'Cinemax', 9),
(3, 'Cobra Kai', ' Action', 2018, 0000, 'Cinemax', 4),
(4, 'Lost', 'Adventure', 2004, 2010, 'Cinemax', 6),
(5, 'Prison Break', 'Action', 2005, 2017, 'Cinemax', 5),
(6, '24', 'Action', 2001, 2010, 'Cinemax', 8),
(7, 'Breaking Bad', 'Crime', 2008, 2013, 'CW', 5),
(8, 'The Walking Dead', 'Horror', 2010, 2022, 'CW', 11);

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `starring`
--

CREATE TABLE `starring` (
  `actorID` int(11) NOT NULL,
  `seriesID` int(11) NOT NULL,
  `episodes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Άδειασμα δεδομένων του πίνακα `starring`
--

INSERT INTO `starring` (`actorID`, `seriesID`, `episodes`) VALUES
(3, 1, 150),
(4, 1, 146),
(5, 1, 146),
(6, 1, 146),
(7, 1, 146),
(8, 2, 171),
(9, 2, 171),
(10, 2, 171),
(11, 2, 103),
(12, 3, 40),
(13, 3, 40),
(14, 4, 118),
(15, 4, 118),
(16, 4, 95),
(17, 4, 74),
(18, 5, 90),
(19, 5, 90),
(20, 5, 75),
(21, 5, 79),
(22, 5, 87),
(23, 6, 195),
(24, 6, 125),
(25, 6, 114),
(26, 7, 62),
(27, 7, 62),
(28, 7, 62),
(29, 7, 62),
(30, 7, 43),
(31, 8, 175),
(32, 8, 174),
(33, 8, 144),
(34, 8, 130),
(35, 8, 130);

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`ID`);

--
-- Ευρετήρια για πίνακα `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`ID`);

--
-- Ευρετήρια για πίνακα `starring`
--
ALTER TABLE `starring`
  ADD PRIMARY KEY (`actorID`,`seriesID`),
  ADD KEY `seriesID` (`seriesID`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `actor`
--
ALTER TABLE `actor`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT για πίνακα `series`
--
ALTER TABLE `series`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Περιορισμοί για άχρηστους πίνακες
--

--
-- Περιορισμοί για πίνακα `starring`
--
ALTER TABLE `starring`
  ADD CONSTRAINT `starring_ibfk_1` FOREIGN KEY (`actorID`) REFERENCES `actor` (`ID`),
  ADD CONSTRAINT `starring_ibfk_2` FOREIGN KEY (`seriesID`) REFERENCES `series` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
