-- ΕΦΑΡΜΟΓΗ ΔΙΑΧΕΙΡΙΣΗΣ ΔΕΔΟΜΕΝΩΝ

-- --------------------------------------

-- Δομή πίνακα για τον πίνακα `ΗΘΟΠΟΙΟΣ`

CREATE TABLE Actor(
	ID INT AUTO_INCREMENT PRIMARY KEY NOT NULL, 
	name VARCHAR(40) NOT NULL,
	age INT NOT NULL,
	country VARCHAR(30) NOT NULL
);

-- --------------------------------------

-- Δομή πίνακα για τον πίνακα `ΣΕΙΡΑ`

CREATE TABLE Series(
	ID INT AUTO_INCREMENT PRIMARY KEY NOT NULL, 
	title VARCHAR(40) NOT NULL,
	genre VARCHAR(20) NOT NULL,
	start_year YEAR NOT NULL,
	end_year YEAR,
	channel VARCHAR(40),
	seasons INT NOT NULL
);

-- --------------------------------------

-- Δομή πίνακα για τον πίνακα `ΠΡΩΤΑΓΩΝΙΣΤΕΙ`

CREATE TABLE Starring(
	actorID INT NOT NULL, 
	seriesID INT NOT NULL,
	episodes INT NOT NULL,
	FOREIGN KEY (actorID) REFERENCES Actor(ID),
	FOREIGN KEY (seriesID) REFERENCES Series(ID),
	CONSTRAINT PK_Starring PRIMARY KEY (actorID,seriesID)
);

