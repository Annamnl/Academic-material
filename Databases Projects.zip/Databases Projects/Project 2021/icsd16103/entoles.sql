SELECT title,genre FROM `series` WHERE channel='Cinemax'; --Ερώτημα 1
SELECT title FROM `series` HAVING MAX(seasons); --Ερώτημα 2
SELECT MIN(age) FROM `actor` WHERE country='USA'; --Ερώτημα 3
SELECT actor.name FROM `actor` INNER JOIN `starring` ON actor.ID=starring.actorID WHERE actor.age<=40 UNION SELECT series.title FROM `series` INNER JOIN `starring` ON series.ID=starring.seriesID; --Ερώτημα 4
SELECT AVG(age) AS AverageAge FROM `actor` WHERE country='SPAIN'; --Ερώτημα 5
SELECT COUNT(series.title) FROM `series` WHERE channel='Cinemax' UNION SELECT COUNT(series.title) FROM `series` WHERE channel='CW' ORDER BY 'channel' DESC; --Ερώτημα 6
SELECT s.Series,a.AverageAge FROM (SELECT series.title AS Series FROM `series` HAVING 'seasons'<=4) AS s, (SELECT AVG(actor.age) AS AverageAge FROM ((`starring` INNER JOIN `actor` ON starring.actorID=actor.ID) INNER JOIN `series` ON starring.seriesID=series.ID)) AS a; --Ερώτημα 7
SELECT s.Series,a.Actors FROM (SELECT series.title AS Series FROM `series` HAVING MAX(seasons)) AS s, (SELECT actor.name AS Actors FROM ((`starring` INNER JOIN `actor` ON starring.actorID=actor.ID) INNER JOIN `series` ON starring.seriesID=series.ID)) AS a; --Ερώτημα 8
SELECT c.Channel,a.NumberOfActors FROM (SELECT DISTINCT series.channel AS Channel FROM (`series` INNER JOIN `starring`) HAVING MAX(starring.actorID)) AS c, (SELECT COUNT(actor.ID) AS NumberOfActors FROM ((`starring` INNER JOIN `series` ON starring.seriesID=series.ID) INNER JOIN `actor` ON starring.actorID=actor.ID)) AS a; --Ερώτημα 9
