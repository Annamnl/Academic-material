INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('The Flash','Sci-Fi & Fantasy','2014','','CW','7');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('The Blacklist','Mystery','2013','','Cinemax','9');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('Cobra Kai',' Action','2018','','Cinemax','4');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('Lost','Adventure','2004','2010','Cinemax','6');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('Prison Break','Action','2005','2017','Cinemax','5');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('24','Action','2001','2010','Cinemax','8');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('Breaking Bad','Crime','2008','2013','CW','5');
INSERT INTO `series`(`title`, `genre`, `start_year`, `end_year`, `channel`, `seasons`) VALUES ('The Walking Dead','Horror','2010','2022','CW','11');