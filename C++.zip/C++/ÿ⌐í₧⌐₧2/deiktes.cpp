#include <iostream>

using namespace std;

void swap(int *a, int *b){
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void swap2(int &a, int &b){
    int temp;
    temp = a;
    a = b;
    b = temp;
}

int main(){

    int a = 5, b =8;

    swap(&a, &b);

    int *p = &a;

    int &r = a;
    &r = b;

    cout<<"A: "<<a<<" B: "<<b<<endl;

    swap2(a, b);

    cout<<"A: "<<a<<" B: "<<b<<endl;

}
