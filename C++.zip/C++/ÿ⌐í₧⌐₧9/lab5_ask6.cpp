#include <iostream>
#include <fstream>

using namespace std;

class Taxpayer
{
private:
    int afm;
    int arPaidiwn;
    float eisodhma;
    float foros;
public:
    Taxpayer() {}

    Taxpayer(int afm,int arPaidiwn,float eisodhma,float foros)
    {
        this->afm=afm;
        this->arPaidiwn=arPaidiwn;
        this->eisodhma=eisodhma;
        this->foros=foros;
    }
    int getAfm()
    {
        return afm;
    }

    int getArithmopaidiwn()
    {
        return arPaidiwn;
    }

    float getEisodhma()
    {
        return eisodhma;
    }

    float getForo()
    {
        return foros;
    }

};


class Taxis
{
private:
    int arForologoumenwn;
    Taxpayer *pin;
public:
    Taxis(int N){
        arForologoumenwn = 0;
        pin = new Taxpayer[N];
    }

    void addTaxpayer(Taxpayer *taxpayer){
        pin[arForologoumenwn] = *taxpayer;
        arForologoumenwn ++;
    }

    float computeTax(Taxpayer &t){
        float tax;
        if (t.getEisodhma()<=12000){
            tax = t.getEisodhma() * 0.10;
        }
        else tax = t.getEisodhma() * 0.15;

        tax = tax - tax*(t.getArithmopaidiwn()*0.10);
        tax = tax - t.getForo();
        return tax;
    }

};

int main(){
    int N;
    int afm, paidia;
    float eisod, foros;
    ifstream read("file1.txt");
    int i;
    float sum =0;
    if (read.is_open()){
        read>>N;
        Taxis tax(N);
        for (int i=0; i<N; i++){
            read>>afm>>paidia>>eisod>>foros;
            Taxpayer *t = new Taxpayer(afm, paidia, eisod, foros);
            tax.addTaxpayer(t);
            float f = tax.computeTax(*t);
            cout<<f<<endl;
            sum = sum + f;
        }
    }
    else cout<<"Error opening file!"<<endl;

    cout<<sum<<endl;

}
