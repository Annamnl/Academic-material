#include <iostream>

using namespace std;

class Animal
{
protected:
    string name;
    float varos;
public:
    Animal(){}

    Animal(string name, float varos)
    {
        this->name = name;
        this->varos = varos;
    }

    virtual void pida()
    {
        cout<<"Hop Hop"<<endl;
    }

    virtual void emfanise(){
        cout<<name<<" " <<varos;
    }

    //pure virtual
    //i alliws abstract
    virtual void mila()=0;



};

class Dog:public Animal
{
private:
    string ratsa;
public:
    Dog(string name, float varos, string ratsa):Animal(name, varos)
    {
        this->ratsa = ratsa;
    }

     void mila(){
        cout<<"Gav"<<endl;
    }

};

class Cat:public Animal
{
private:
public:
    Cat(string name, float varos):Animal(name, varos)
    {
    }
     void mila(){
        cout<<"Niaou"<<endl;
    }
};




class Pig:public Animal
{
private:
    string xrwma;
public:
    Pig(string name, float varos, string xrwma):Animal(name, varos)
    {
        this->xrwma = xrwma;
    }

    void pida()
    {
        cout<<"Oute me sfaires..."<<endl;
    }

     void mila(){
        cout<<"Oink"<<endl;
    }

    void emfanise(){
        Animal::emfanise();
        cout<<xrwma<<endl;
    }

};

int main()
{
    Animal *dog1 = new Dog("Jack", 40, "Bobby");
    Animal *pig1 = new Pig("Porky", 100, "roz");
    Animal *cat1 = new Cat("Porky", 100);

//    dog1.pida();
//    pig1.pida();
//    cat1.pida();

    Animal *zwakia[3];
    zwakia[0] = dog1;
    zwakia[1] = pig1;
    zwakia[2] = cat1;

    //zwakia[1]->emfanise();
    for(int i=0; i<3; i++){
        zwakia[i]->mila();
    }

}
