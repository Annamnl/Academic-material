#include <iostream>

using namespace std;

int add(int x, int y){
    return x+y;
}

void swap(int *x,int *y){
    int temp;
    temp= *x;
    *x= *y;
    *y= temp;
}

void dec(int &x){
    x--;
}

void inc(int &x){
    x++;
}

int main(){
    int x=5;
    int y=10;

    cout<<"xrhsh sunarthsewn:\n\n";

    cout<<"add():\n";
    cout<<x<<"+"<<y<<"="<<add(x,y);

    cout<<"\nswap():";
    cout<<"\n"<<x<<","<<y;
    swap(&x,&y);
    cout<<"\n"<<x<<","<<y;
    swap(&x,&y);

    cout<<"\ndec():";
    dec(y);
    cout<<"\n"<<y;

    cout<<"\ninc():";
    inc(x);
    cout<<"\n"<<x;

return 0;
}
