#include <iostream>

using namespace std;

class Cone
{
private:
    double *rad;
    double *hgt;

public:
    Cone(double radius,double hight)
    {
        rad=new double;
        *rad=radius;
        hgt=new double;
        *hgt=hight;
    }

    ~Cone()
    {
        delete rad;
        delete hgt;
    }

    double getRadius()
    {
        return *rad;
    }

    double getHight()
    {
        return *hgt;
    }

    double embadon()
    {
        return (*rad)*(*rad)*3.14;
    }

};

int main()
{
    double radius;
    double hight;

    cout<<"Dwse tis diadtseis tou kwnou"<<endl;
    cout<<"aktina:\n";
    cin>>radius;
    cout<<"upsos:\n";
    cin>>hight;

    //Cone k1(radius,hight);

    Cone *k1 = new Cone(radius, hight);

    cout<<"O kwnos exei aktina "<<k1->getRadius();
    cout<<"\nO kwnos exei upsos "<<k1->getHight();
    cout<<"\nTo embadon tou kwnou einai:"<<k1->embadon()<<endl;



    return 0;
}
