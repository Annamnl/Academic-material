#include <iostream>

using namespace std;

class Animal
{
private:
    float upsos;
    string name;
    int varos;
    int *p;
public:
    Animal(float u, int v, string n)
    {
        p = new int[v];
        cout<<"To zwaki gennithike"<<endl;
        upsos = u;
        varos = v;
        name = n;
    }

    Animal() {}

    void pida()
    {
        cout<<"Hop Hop"<<endl;
    }

    //epestrepse tp varos tou zwou (getter)
    int getVaros()
    {
        return varos;
    }

    //allazei to varos tou zwou (setter)
    void setVaros(int v)
    {
        varos = v;
    }

    ~Animal(){
        delete p;
        cout<<"TO zwaki pethane! :( "<<endl;
    }

};


int main()
{

    //Animal zwo1;
//    zwo1.upsos = 1.5;
//    zwo1.varos = -10;
//    zwo1.name = "mpampis";

    int p[3];
    cout<<"Poses theseis na exei o pinakas : ";
    int N;
    cin>>N;
    int *p2 = new int[N];

    Animal *zwo3;

    {
        Animal zwo2 (1.5, 30, "mitsos");
        zwo3 = new Animal(2, 40, "mitsos");
        delete zwo3;
        zwo2.setVaros(-10);
        cout<<zwo2.getVaros()<<endl;


        zwo2.pida();
    }

    cout<<"HI"<<endl;

}
