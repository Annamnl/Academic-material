#include <iostream>

using namespace std;

class Product
{
private:
    string onoma;
    float timh;
public:
    Product(string onoma,float timh)
    {
        this->onoma=onoma;
        this->timh=timh;
    }

    string getOnoma()
    {
        return onoma;
    }

    float getTimh()
    {
        return timh;
    }

    virtual void emfanise() = 0;



};

class Rouxo:public Product
{
private:
    string megethos;
public:
    Rouxo(string onoma,float timh,string megethos):Product(onoma,timh)
    {
        this->megethos=megethos;
    }

    void emfanise()
    {
        cout<<Product::getOnoma()<<"("<<megethos<<")"<<Product::getTimh()<<"eur"<<endl;
    }


};

class Eksarthma:public Product
{
private:
    string tSkafous;
public:
    Eksarthma(string onoma,float timh, string tSkafous):Product(onoma,timh)
    {
        this->tSkafous=tSkafous;
    }

    void emfanise()
    {
        cout<<getOnoma()<<"("<<tSkafous<<")"<<getTimh()<<"eur"<<endl;
    }

};

class Timologio
{
private:
   Product *proionta[100];
   int arProiontwn; ///posa proionta exw sto timologio
public:
    Timologio()
    {
        arProiontwn = 0;
    }

    void addProion(Product *p){
        proionta[arProiontwn] = p;
        arProiontwn++;
    }


    void ekdosiTimologiou()
    {
        float sum=0;
        for (int i=0; i<arProiontwn; i++){
            proionta[i]->emfanise();
            sum+=proionta[i]->getTimh();
        }
        cout<<"SUNOLIKO KOSTOS : "<<sum<<endl;
    }
};

int main()
{
    Product *p1 = new Rouxo("Mplouza", 20, "XL");
    Product *p2 = new Rouxo("Sorts", 30, "L");
    Product *p3 = new Rouxo("Vraki", 10, "L");
    Product *p4 = new Eksarthma("Petonia", 5, "ll");

    Timologio t;
    t.addProion(p1);
    t.addProion(p2);
    t.addProion(p3);
    t.addProion(p4);
    t.ekdosiTimologiou();
}
