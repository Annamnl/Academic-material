#include <iostream>

using namespace std;


class Uphresia
{
protected:
    string onoma;
    int mb;
    int pagio;
    float sun_xrewsi;
public:
    Uphresia(string onoma,int mb,int pagio)
    {
        this->onoma=onoma;
        this->mb=mb;
        this->pagio=pagio;
    }

    virtual void upolXrewsis(int mb)=0;

    float getXrewsi(){return sun_xrewsi;}
};

class Paketo1:public Uphresia
{
public:
    Paketo1():Uphresia("paketo1", 1024, 20) {}

    void upolXrewsis(int kmb)
    {
        if (kmb>mb)
            sun_xrewsi = (kmb-mb)*0.20 + pagio;
        else
            sun_xrewsi = pagio;
    }
};
class Paketo2:public Uphresia
{
public:
    Paketo2():Uphresia("paketo2", 2048, 30) {}

    void upolXrewsis(int kmb)
    {
        if (kmb>mb)
            sun_xrewsi = (kmb-mb)*0.15 + pagio;
        else sun_xrewsi = pagio;
    }
};
class Paketo3:public Uphresia
{
public:
    Paketo3():Uphresia("paketo3", 4096, 60) {}

    void upolXrewsis(int kmb)
    {
        if (kmb>mb)
            sun_xrewsi =  (kmb-mb)*0.10 + pagio;
        else sun_xrewsi = pagio;
    }
};

class Logariasmos
{
private:
    string name;
    string lastname;
    int code;
    Uphresia *uphresia;
public:
    Logariasmos(string name,string lastname,int code,Uphresia* uphresia)
    {
        this->name=name;
        this->lastname=lastname;
        this->code=code;
        this->uphresia=uphresia;
    }


    float getXrewsi(int mb)
    {
        uphresia->upolXrewsis(mb);
        return uphresia->getXrewsi();
    }
};


int main()
{
    Logariasmos l1("mitsos", "papadopoulos", 1212, new Paketo1());
    Logariasmos l2("mitsos", "papadopoulos", 1212, new Paketo2());
    Logariasmos l3("mitsos", "papadopoulos", 1212, new Paketo3());

    cout<<l1.getXrewsi(1000)<<endl;
    cout<<l2.getXrewsi(2050)<<endl;
    cout<<l3.getXrewsi(4000)<<endl;
}
