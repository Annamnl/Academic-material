#include <iostream>

using namespace std;

class Dieythynsh
{
private:
    string odo;
    string arithmo;
    string polh;
    string tax_kvdika;

public:
    Dieythynsh(string o, string a, string p, string tk)
    {
        odo = o;
        arithmo = a;
        polh = p;
        tax_kvdika = tk;
    }

    Dieythynsh()
    {

    }

    void emfanise()
    {
        cout<<odo<<" "<<arithmo<<" "<<polh<< " "<<tax_kvdika<<endl;
    }
};

class Anthrvpos
{
private:
    string name;
    string epwnumo;
    int etos_gennhshs;
    Dieythynsh antres;
public:
    Anthrvpos(string n, string e, int eg,Dieythynsh a)
    {
        name = n;
        epwnumo = e;
        etos_gennhshs = eg;
        antres = a;

    }

    void emfanise()
    {
        cout<<name<<" "<<epwnumo<<" "<<etos_gennhshs;
        antres.emfanise();
    }
};

int main()
{
    Dieythynsh a1("Pythagora", "25", "Karlovasi", "83200");
    Dieythynsh a2("Aristarchou", "10", "Karlovasi", "83200");

    Anthrvpos an1("Nikos", "Doukas", 23, a1);
    Anthrvpos an2("Lilly", "Douka", 25, a2);

    an1.emfanise();
    an2.emfanise();



}
