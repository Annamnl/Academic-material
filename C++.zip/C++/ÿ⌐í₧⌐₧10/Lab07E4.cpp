/*
* Εργαστήριο 7, Άσκηση 4
* Polymorphism, Ιεραρχική κληρονομικότητα
*/
#include <iostream>
using namespace std;

class Student
{
protected:
    string name;
    string surname;
    int studentId;
    int numberOfLessons;
public:
    Student(string name, string surname, int studentId, int numberOfLessons)
    {
        this->name=name;
        this->surname=surname;
        this->studentId=studentId;
        this->numberOfLessons=numberOfLessons;
    }
    virtual bool studentGraduate()=0;
    void passCourses(int Lessons)
    {
        numberOfLessons+=Lessons;
    };
    virtual void display()
    {
        cout << "Name :" << name << endl;
        cout << "Surame :" << surname << endl;
        cout << "studentId :" << studentId << endl;
        cout << "Number Of Lessons passed :" << numberOfLessons << endl;
        if (studentGraduate()==true)
            cout << "Congratulations! You have graduated!" << endl;
        else
            cout << "Sorry, not graduated yet!!!" << endl;
    }
};

class Undergraduate : public Student
{
protected:
    int ObligatoryLabs;
public:
    Undergraduate(string name, string surname, int studentId, int numberOfLessons, int ObligatoryLabs):
        Student(name, surname, studentId, numberOfLessons)
    {
        this->ObligatoryLabs=ObligatoryLabs;
    }
    bool studentGraduate()
    {
        if (numberOfLessons>=40 && ObligatoryLabs>=15) // υποχρεωτικά μαθήματα
            return true;
        return false;
    };
    void passLabs(int Labs)
    {
        ObligatoryLabs+=Labs;
    };
    void display()
    {
        Student::display();
        cout << "Number of passed Labs : " << ObligatoryLabs << endl;
    }
};
class Postgraduate : public Student
{
protected:
    string thesisTitle;
public:
    Postgraduate(string name, string surname, int studentId, int
                 numberOfLessons, string thesisTitle):
        Student(name, surname, studentId, numberOfLessons)
    {
        this->thesisTitle=thesisTitle;
    }
    bool studentGraduate()
    {
        if (numberOfLessons>=10)
            return true;
        return false;
    };
// obligatory lessons for postgraduate
    void display()
    {
        Student::display();
        cout << "Thesis title : " << thesisTitle << endl;
    }
};
class PhdCandidate : public Postgraduate
{
protected:
    int yearOfResearch;
public:
    PhdCandidate(string name, string surname, int studentId, int
                 numberOfLessons, string thesisTitle,int yearOfResearch):

        Postgraduate(name, surname, studentId, numberOfLessons,
                     thesisTitle)
    {
        this->yearOfResearch=yearOfResearch;
    }
    bool studentGraduate()
    {
        if (numberOfLessons>=3 && yearOfResearch>=4) // Υποχρεωτικά μαθήματα υποψηφίων διδακτ.
            return true;
        return false;
    };
    void display()
    {
        Postgraduate::display();
        cout << "Year of research : " << yearOfResearch << endl;
    }
};
int main()
{
    Student *students[3];
    students[0]=new Undergraduate("Nikos", "Landros", 3, 15, 6);
    students[1]=new Postgraduate("Iwanna", "Dimou", 23, 6, "Virus Classification with neural networks");
    students[2]=new PhdCandidate("John", "Papoutis", 10, 2, "Security on Social Networks", 3);
    students[0]->passCourses(5);
    students[1]->passCourses(4);
    for (int i=0; i<3; i++)
    {
        cout << endl;
        students[i]->display();
    }
    return 0;
}
