#include <stdio.h>
/*
* Ανάγνωση ακεραίων και εκτύπωση
* αθροίσματος τους
*/
int main(void) {
    int i, num, sum = 0;

    for (i=1; i<=10; i++) {
        printf("Insert integer no %d: ", i);
        scanf("%d", &num);
        sum += num;
    }
    printf("The sum of integers is: %d\n", sum);
    printf("The average is: %f\n", (float)sum/10);
    return 0;
}




