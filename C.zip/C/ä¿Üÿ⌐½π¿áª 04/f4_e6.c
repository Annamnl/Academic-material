#include <stdio.h>
/*
* Εύρεση μέγιστου από 10 ακεραίους
*/
int main(void) {
    // Αρχικοποίηση μεταβλητών
    int i; // μετρητής
    int number; // για είσοδο δεδομένων
    int largest; // για αποθήκευση του μέγιστου

    for (i=1; i<=10; i++) {
        printf("Enter number %d: ", i); // προτροπή χρήστη
        scanf("%d", &number);
        if (i==1)
            largest = number; // Αρχικοποίηση την πρώτη φορά
        else if (number > largest)
            largest = number; // Αν βρεθεί μεγαλύτερος, αποθηκεύεται ο νέος αριθμός ως μέγιστος
        // Οι παραπάνω έλεγχοι θα μπορούσαν να ενσωματωθούν σε μια if
    }

    // Εκτυπώνει στην έξοδο τον μέγιστο αριθμό
    printf("The largest number is: %d\n", largest);

    return 0;
}
