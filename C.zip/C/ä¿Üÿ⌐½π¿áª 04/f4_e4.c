#include <stdio.h>
/*
* Εισαγωγή ακεραίων και υπολογισμό αθροίσματος μέχρι
* η τιμή του αθροίσματος να ξεπεράσει το 100
*/
int main(void) {
    int sum, num, cnt;
    sum = cnt = 0;
    while(sum <= 100) {
        printf("Enter number: ");
        scanf("%d", &num);
        cnt++; // για μέτρηση των ακεραίων που έχει διαβάσει
        sum += num;
    }
    printf("Sum: %d Numbers: %d\n", sum, cnt);
    return 0;
}
