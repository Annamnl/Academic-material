#include <stdio.h>
/*
* Εμφάνιση διαδοχικών ακεραίων με
* επιλογή ακεραίου έναρξης από χρήστη
*/
int main(void) {
    int i, num;
    printf("Insert starting integer: ");
    scanf("%d", &num);

    for (i=num;i<=num+10;i++) {
        printf("%d ", i);
    }
    return 0;
}
