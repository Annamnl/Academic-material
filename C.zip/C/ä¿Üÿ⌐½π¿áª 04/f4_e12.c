#include <stdio.h>

int main(void) {
    int i, i_cnt=0;

    while (1) {
        scanf("%d", &i);
        if (i < 0)
            continue;
        else if (i == 0)
            break;
        else
            i_cnt++;
    }
    printf("%d\n", i_cnt);
    return 0;
}

/** Για είσοδο 7 -5 -22 4 0, Θα εμφανίσει:
2
*/
