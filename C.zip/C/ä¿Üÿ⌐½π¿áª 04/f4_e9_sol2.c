#include <stdio.h>
/*
* Προσομοίωση εισαγωγής PIN σε ATM
*/
#define SEC_PIN 1122 // Το PIN του πελάτη
int main(void) {
    int pin, attempts=3; //Μέγιστο 3 προσπάθειες

    do {
        printf("Please insert your PIN: ");
        scanf("%d", &pin);
        attempts--; // Απομένει μια προσπάθεια λιγότερη.

        if(pin==SEC_PIN) {
            printf("PIN is correct.");
        } else {
            printf("Wrong PIN (%d attempts remaining).\n",attempts);
        }

    } while((pin!=SEC_PIN) && (attempts>0));  //Συνέχισε όσο το PIN του χρήστη (pincode)
    /* Η εκτέλεση του κώδικα θα φτάσει εδώ είτε όταν έχει δώσει το σωστό
       PIN, είτε, όταν έχει ξεπεράσει τον μέγιστο αριθμό προσπαθειών */
    return 0;
}
