#include <stdio.h>
/*
* Μετατροπή mile σε km με διάστημα
* και βήμα ορισμένο από τον χρήστη
*/
int main(void) {
    double i, a, b, step;
    printf("Enter miles interval (from-to): ");
    scanf("%lf-%lf", &a, &b); // Αποδοχή με τη μορφή από-έως
    printf("Enter step: ");
    scanf("%lf", &step);
    printf("MILE\t\t KLM\n");
    printf("------------------------\n");
    for(i = a; i < b; i += step)
        printf("%.2f\t\t %.2f\n", i, 1.6*i);
    return 0;
}
