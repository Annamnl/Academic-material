#include <stdio.h>
/*
* Προσομοίωση εισαγωγής PIN σε ATM
*/
#define SEC_PIN 1122 // Το PIN του πελάτη
int main(void) {
    int pin, tries;
    tries = 0; // Αρχικοποίηση του μετρητή των προσπαθειών

    do {
        printf("Please insert your PIN: ");
        scanf("%d", &pin);
        tries = tries + 1; // Έγινε μια επιπλέον προσπάθεια

        if(pin==SEC_PIN) {
            printf("PIN is correct.");
        } else {
            printf("Wrong PIN.\n");
        }

    } while (pin != SEC_PIN && tries < 3);
    /* Η εκτέλεση του κώδικα θα φτάσει εδώ είτε όταν έχει δώσει το σωστό
       PIN, είτε, όταν έχει ξεπεράσει τον μέγιστο αριθμό προσπαθειών */

    return 0;
}
