#include <stdio.h>
/*
* Επίδειξη εμφωλευμένης while
*/
int main(void) {
    int row, stars;

    row = 0;
    while (row < 10) {
        stars = row;
        while (stars > 0) {
            printf("*");
            stars = stars - 1;
        }
        printf("\n");
        row = row + 1;
    }

    return 0;
}

/* Θα εμφανιστεί

*
**
***
****
*****
******
*******
********
*********
*/
