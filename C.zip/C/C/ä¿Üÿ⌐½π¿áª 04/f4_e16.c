#include <stdio.h>
/*
* Προσομοίωση συναλλαγής ATM
*/
#define SEC_PIN 1122 // Το PIN του πελάτη
#define balance 185 // Υπόλοιπο λογαριασμού σε ευρώ
int main(void) {
    int pin, tries, s;
    float new_balance, amount;

    tries = 0; // Αρχικοποίηση του μετρητή των προσπαθειών
    do {
        printf("Please insert your PIN: ");
        scanf("%d", &pin);
        tries = tries + 1;
    } while (pin != SEC_PIN && tries < 3);
    /* Εδώ θα φτάσει είτε όταν έχει δώσει το σωστό PIN
       είτε έχει ξεπεράσει τον μέγιστο αριθμό προσπαθειών */

    if (pin == SEC_PIN && tries <= 3) {

        printf("Select transaction:\n");
        puts("deposition: 1");
        puts("withdrawal: 2");
        puts("balance info: 3");

        scanf("%d", &s);

        switch (s) {
        case 1:
            printf("Enter amount in euro: ");
            scanf("%f", &amount);
            printf("New balance is: %.2f", balance + amount);
            break;
        case 2:
            printf("Enter amount in euro: ");
            scanf("%f", &amount);
            printf("New balance is: %.2f", balance - amount);
            break;
        case 3:
            printf("Existing balance is: %.2f", (float)balance);
            break;
        default:
            printf("Wrong choice...");
        }

    } else
        printf("Wrong pin 3 times. Card withheld");


    return 0;
}
