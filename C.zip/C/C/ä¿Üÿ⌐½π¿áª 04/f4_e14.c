#include <stdio.h>
/*
* Επίδειξη δομής επανάληψης for
*/
int main(void) {
    int row, stars;

    for (row=0; row<10; row++) {
        for (stars=row; stars>0; stars--) {
            printf("*");
        }
        printf("\n");

    }

    return 0;
}
