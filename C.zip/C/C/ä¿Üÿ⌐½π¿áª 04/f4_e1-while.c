#include <stdio.h>
/*
* Εμφάνιση ακεραίων με χρήση for
*/
int main(void) {
    int i = 0;
    while (i<=10) {
        printf("%d ", i);
        i++;
    }
    return 0;
}
