#include <stdio.h>

int main(void) {
    short i=10, i_cnt=0;

    for (;;) {
        printf("%d\n", i);
        i++, i_cnt++;
        if (i_cnt == 3)
            break;
    }
    return 0;
}

/** Θα εμφανίσει:
10
11
12
*/
