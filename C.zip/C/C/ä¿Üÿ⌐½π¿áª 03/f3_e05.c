#include <stdio.h>
/*
* Υπολογισμός μικρότερου ακεραίου
*/
int main(void)
{
    int x1, x2, x3, x4;
    printf("Please insert 4 integers:\n");
    scanf("%d%d%d%d", &x1, &x2, &x3, &x4);

    int min;

    min = x1; // Έστω ότι ο μικρότερος είναι ο x1
    if (x2 < min) // Έλεγξε για τον x2 κ.ο.κ
        min = x2;
    if (x3 < min)
        min = x3;
    if (x4 < min)
        min = x4;

    printf("Minimum is: %d\n", min);

    return 0;
}




