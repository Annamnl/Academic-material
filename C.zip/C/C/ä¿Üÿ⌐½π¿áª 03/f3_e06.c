#include <stdio.h>
/*
* Υπολογισμός απόλυτης τιμής
Να γράψετε ένα πρόγραμμα το οποίο να διαβάζει έναν αριθμό από τον χρήστη και να εμφανίζει την απόλυτη τιμή του. Στην περίπτωση που ο χρήστης εισάγει ακέραιο αριθμό, θα πρέπει το αποτέλεσμα να εμφανίζεται χωρίς δεκαδικά ψηφία.
*/
int main(void) {
    float number;
    printf("Please insert a number:\n");
    scanf("%f", &number);

    float absolute;
    if (number < 0)
        absolute = -number;
    else
        absolute = number;

    // Εμφάνισε τον ακέραιο χωρίς δεκαδικά ψηφία
    if ((int)absolute == absolute) // Σύγκριση με τον εαυτό του μετά από προσωρινή μετατροπή σε ακέραιο
        printf("Absolute is: %.0f\n", absolute);
    else
        printf("Absolute is: %f\n", absolute);
    return 0;
}
