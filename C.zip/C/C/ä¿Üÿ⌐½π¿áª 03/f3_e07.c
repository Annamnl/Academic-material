#include <stdio.h>
//#include <math.h> // για χρήση της pow()
/*
* Υπολογισμός δείκτη σωματικού βάρους (BMI)
*/
int main(void) {
    float weight, height, bmi;
    // Είσοδος δεδομένων (κιλά, ύψος)
    printf("Please enter weight in kg: ");
    scanf("%f", &weight);

    printf("Please enter height in meters: ");
    scanf("%f", &height);

    // Υπολογισμός BMI
    bmi = weight/(height*height); // υπάρχει και η συνάρτηση pow() στο math.h
    // Εναλλακτικά με τη χρήση της pow()
    //bmi = weight/pow(height, 2);

    if(bmi<19)
        printf("\nUnderweight (%.3f)\n", bmi);
    else if (bmi < 25)
        printf("\nNormal weight (%.3f)\n", bmi);
    else if (bmi < 30)
        printf("\nOverweight (%.3f)\n", bmi);
    else if (bmi < 35)
        printf("\nObesity (%.3f)\n", bmi);
    else
        printf("\nSerious Obesity (%.3f)\n", bmi);


    return 0;
}
