#include <stdio.h>
/*
* Υπολογισμός κέρδους ή ζημίας ΚΤΕΛ
Να γράψετε ένα πρόγραμμα το οποίο να υπολογίζει και να εμφανίζει το κέρδος (η ζημία) σε ευρώ (2 δεκαδικά ψηφία) μιας ημέρας ενός λεωφορείου ΚΤΕΛ. Θα δέχεται τις παρακάτω πληροφορίες από τον χρήστη:
    • Τα συνολικά χιλιόμετρα που διένυσε
    • Ο αριθμός πελατών που εξυπηρέτησε
    • Το κόστος ανά χιλιόμετρο καυσίμου
Το κόστος εισιτηρίου είναι σταθερό στα 4€ ανά πελάτη που εξυπηρέτησε. Στα έξοδα του λεωφορείου, θα πρέπει να προστεθούν τα πάγια έξοδα για την απόσβεση της αγοράς του λεωφορείου που είναι 15 λεπτά ανά χιλιόμετρο που διανύει.
*/
#define TICKET_PRICE 4 // κόστος εισιτηρίου
int main(void) {
    float km, kmCost; // Συνολικά χιλιόμετρα και κόστος/χμ
    int passNum; // Αριθμός πελατών που εξυπηρέτησε
    float earnings, expenses, result; // Μετ. για έσοδα, έξοδα και αποτέλεσμα αντίστοιχα

    // Δεδομένα από χρήστη - Αρχή
    printf("Please insert total km: ");
    scanf("%f", &km);

    printf("Please insert total number of passengers: ");
    scanf("%d", &passNum);

    printf("Please insert cost per km: ");
    scanf("%f", &kmCost);
    // Δεδομένα από χρήστη - Τέλος

    earnings = passNum * TICKET_PRICE;
    expenses = km * kmCost + 0.15 * km;

    result = earnings - expenses; // Υπολογισμός κέρδους ή ζημίας

    if (result > 0) {
        printf("Profit: %.2f", result);
    } else if (result < 0) {
        printf("Loss: %.2f", -result); // Υπάρχει ειδική συνάρτηση abs() για τον υπολογισμό απόλυτης τιμής
    } else {
        printf ("Zero profit but no loss either...");
    }

    return 0;
}
