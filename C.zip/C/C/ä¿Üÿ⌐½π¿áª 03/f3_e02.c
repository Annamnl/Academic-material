#include <stdio.h>
/*
* Έλεγχος για προβιβάσιμες βαθμολογίες συνολικά
Να γραφεί ένα πρόγραμμα το οποίο να δέχεται 3 βαθμολογίες φοιτητών και στην περίπτωση που όλοι οι βαθμοί είναι προβιβάσιμοι (άνω του 5) να εμφανίζει «Everyone passed!»
*/
int main(void) {
    float g1, g2, g3;

    printf("Insert 3 grades: ");
    scanf("%f%f%f", &g1, &g2, &g3);

    if(g1 >= 5 && g2 >= 5 && g3 >= 5) {
        printf("Everybody passed!\n");
    }

    printf("Program exiting...\n");
    return 0;
}
