#include <stdio.h>
/*
* Επίδειξη μοναδιαίων τελεστών
*/
int main(void) {
    int i = 7;
    printf("%d, ", ++i);
    printf("%d\n", i);

    i = 7;
    printf("%d, ", i++);
    printf("%d\n", i);

    return 0;
}



/* Θα εμφανίσει:
8, 8
7, 8

*/
