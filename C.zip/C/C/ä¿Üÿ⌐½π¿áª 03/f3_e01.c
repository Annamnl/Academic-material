#include <stdio.h>
/*
* Υπολογισμός μέσου όρου
Να γραφεί ένα πρόγραμμα το οποίο να δέχεται 3 βαθμολογίες φοιτητών και να υπολογίζει το μέσο όρο τους. Αν το μέσο όρο είναι πάνω από 5, να εμφανίζει το μήνυμα «Average grade more than 5».
*/
int main(void) {
    float g1, g2, g3, avg;
    printf("Insert 3 grades: ");
    scanf("%f%f%f", &g1, &g2, &g3);
    avg = (g1 + g2 + g3) / 3;
    printf("Average is: %f\n", avg);
    if (avg >= 5) {
        printf("Average grade more than 5\n");
    }
    printf("Program exiting...\n");
    return 0;
}
