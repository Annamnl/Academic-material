#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Πλήθος βιβλίων σε βιβλιοθήκη, συγχώνευση, αναζήτηση, ταξινόμηση
*/
#define N 100
#define M 6

int main() {

    // Δηλώσεις πινάκων και μεταβλητών
    int B1[N][M], B2[N][M], B[N][M*2], CODE[N], i, j;
    srand(time(NULL));

    // Δημιουργία πινάκων με το πλήθος των δανεισμών ανά βιβλίο
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++) {
            B1[i][j] = rand()%21; // 0-20
            B2[i][j] = rand()%21; // 0-20
        }
        // Δημιουργία του πίνακα CODE
        CODE[i] = 1000 + rand() % 9000; // 1000-9999 (τετραψήφιοσ)
    }

    // Συγχώνευση των πινάκων για να εμφανιστεί για όλο το έτος
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++) {
            B[i][j] = B1[i][j];
            B[i][j+6] = B2[i][j];
        }
    }

    // Εμφάνιση πινάκων
    printf("Borrowing matrix B1:\n");
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++)
            printf("%3d ", B1[i][j]);
        puts("");
    }

    printf("\nBorrowing matrix B2:\n");
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++)
            printf("%3d ", B2[i][j]);
        puts("");
    }

    printf("\nBorrowing matrix B (All year):\n");
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M*2-1; j++)
            printf("%3d ", B[i][j]);
        puts("");
    }

    // Εμφάνιση πίνακα CODE
    printf("\n Books code list:\n");
    for(i=0; i<N; i++) {
        printf("%5d ", CODE[i]);
        puts("");
    }

    // Τέλος εμφάνισης πινάκων

    /* β) ερώτημα Αναζήτηση τίτλου με βάση τον
       κωδικο και εύρεση του μεγαλύτερου πλήθους*/
    int code_book;
    printf("\nPlease insert code for a book: ");
    scanf("%d", &code_book);
    // Αναζήτηση για τον τίτλο στον πίνακα CODE

    i = 0;
    unsigned short found = 0;
    while (!found && i<N) {
        if (code_book == CODE[i]) {
            found = 1; // Το βιβλίο βρέθηκε
            // Εύρεση του max στην γραμμή i του πίνακα Β
            int max = B[i][0];
            int maxp = 0;
            for(j=1; j<=2*M-1; ++j) {
                if(B[i][j] > max) {
                    max = B[i][j];
                    maxp = j;
                }
            }
            // Εμφάνιση μήνα
            printf("The month which the book %d had the most borrowers is: %d\n", CODE[i], ++maxp);
        } else
            ++i;
    }
    // Έλεγχος αν δε βρέθηκε
    if (found == 0)
        puts("Το βιβλίο δεν βρέθηκε");


    /* Ταξινόμηση ως προς τον Μάιο και εμφάνιση λίστας */
    int pass, swap;
    for (pass = N ; pass > 1; pass--)
        for (i = 0 ; i < pass-1; i++)
            if (B[i][4] > B[i+1][4]) {
                swap = B[i][4];
                B[i][4] = B[i+1][4];
                B[i+1][4] = swap;
                // Αντιμεταθέτουμε κα ιτους κω δικούς των βιβλίων
                // για να παραμείνει η συσχέτιση
                swap = CODE[i];
                CODE[i] = CODE[i+1];
                CODE[i+1] = swap;
            }
    //Εμφάνιση ταξινομημένης λίστας
    puts("The list for May is:");
    for(i=N-1; i>=0; --i) {
        printf("%d\t%d\n", CODE[i], B[i][4]);
    }

    return 0;
}
