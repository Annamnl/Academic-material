#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Διαχωρισμός στοιχείων σε νέο πίνακα
*/
#define N 10 // ορισμός μεγέθους πίνακα
int main(void) {

    int i, j, arr[N], n_arr[N];

    /* Αρχικοποίηση πίνακα με τυχαίους
    ακεραίους από το -10 0 μέχρι το 20*/
    srand(time(NULL));
    for(i=0; i<N; i++) {
        arr[i] = rand()%21 - 10;
    }

    // Εμφάνιση αρχικού πίνακα
    for(i=0; i<N; i++) {
        printf("%d ", arr[i]);
    }
    puts("\n");

    /* Δημιουργία νέου πίνακα διαχωρισμένου αρνητικών */
    // 1o σκέλος: Καταχώρηση αρνητικών στον νέο πίνακα
    j=0;
    for(i=0; i<N; i++) {
        if(arr[i] < 0) {
            n_arr[j] = arr[i];
            j++;
        }
    }

    // 2ο σκέλος: καταχώρηση των υπολοίπων τιμών στο εναπομείναν τμήμα του νέου πίνακα
    for(i=0; i<N; i++) {
        if(arr[i] >= 0) {
            n_arr[j] = arr[i];
            j++;
        }
    }

    // Εμφάνιση νέου πίνακα
    for(i=0; i<N; i++) {
        printf("%d ", n_arr[i]);
    }

    return 0;
}
