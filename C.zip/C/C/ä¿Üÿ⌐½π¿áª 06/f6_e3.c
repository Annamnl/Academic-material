#include <stdio.h>
#include <stdlib.h> /* srand, rand */
#include <time.h>   /* time */
/*
* Ανάθεση τυχαίων τιμών σε πίνακα
* Εύρεση μέγιστου και μέσου όρου πίνακα
Να γράψετε ένα πρόγραμμα το οποίο να γεμίζει έναν πίνακα με 20 τυχαίους ακέραιους
αριθμούς από το 20 έως το 100. Στη συνέχεια να υπολογίζει και να εμφανίζει το μέγιστο
στοιχείο καθώς και το μέσο όρο των στοιχείων του πίνακα.
*/
#define N 20

int main(void) {
    int i, random_numbers[N], sum, max;
    float average;

    srand(time(NULL)); // Αρχικοποίηση γεννήτριας παραγωγής τυχαίων αριθμών
    printf("Array initialization with random numbers\n");
    for (i=0; i<N; i++) {
        random_numbers[i]=20 + (rand() % 81); // Παραγωγή τυχαίου αριθμού από 20 έως 100
        printf("%d \n", random_numbers[i]);
    }

    sum=0;
    max=random_numbers[0];
    for (i=0; i<N; i++) {
        if (random_numbers[i]>max)
            max=random_numbers[i];

        sum=sum+random_numbers[i];
    }

    average = (float)sum/N;
    printf("\nThe maximum number is: %d", max);
    printf("\nThe average is: %f", average);

    return 0;
}

/*

*/
