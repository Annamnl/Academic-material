#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Υπολογισμοί σε δισδιάστατο πίνακα
*/
#define N 3
int main(void) {

    // Δηλώσεις πίνακα και μεταβλητών
    int M[N][N], i, j;
    int sum1 = 0; // Για το άθροισμα κύριας διαγωνίου
    int sum2 = 0; // Για το άθροισμα της δευτερεύουσας διαγωνίου
    srand(time(NULL));

    // Δημιουργία πίνακα ακεραίων
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
            M[i][j] = rand()%10;
        }
    }

    /* Εμφάνιση πίνακα */
    printf("\nMatrix is:\n");
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++)
            printf("%3d", M[i][j]);
        puts("");
    }

    // Εύρεση των 2 αθροισμάτων για τα ερωτήματα α και β
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
            if (i == j) // κύρια διαγώνιος
                sum1 += M[i][j];
            if ((i+j) == (N-1)) { // Δευτερεύουσα διαγώνιος
                sum2 += M[i][j];
            }
        }
    }

    // Υπολογισμός και εμφάνιση μέσου όρου δευτερεύουσας διαγωνίου
    printf("Sum of main diagonal: %d\n", sum1);
    printf("Average of secondary diagonal:%d %.2f\n", sum2, (float)sum2/N);


    // Εύρεση των max και min για τα ερωτήματα γ και δ
    int max=M[0][1];
    int min=M[1][0];
    for(i=0; i<N; i++)
        for(j=0; j<N; j++)
            if (j > i) { // στοιχεία πάνω από την διαγώνιο
                if (M[i][j] > max)
                    max = M[i][j];
            } else if (j < i) { // στοιχεία κάτω από την διαγώνιο
                if (M[i][j] < min)
                    min = M[i][j];
            }

    // Εμφάνιση max και min
    printf("Max is: %d\n", max);
    printf("Min is: %d\n", min);

    return 0;
}
