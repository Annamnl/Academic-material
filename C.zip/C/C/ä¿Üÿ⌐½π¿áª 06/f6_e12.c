#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Πρόσθεση στοιχείων δισδιάστατου πίνακα
*/
int main(void) {

    // Δηλώσεις πινάκων και μεταβλητών
    int a[3][3], b[3][3], c[3][3], i, j;
    srand(time(NULL));

    // Δημιουργία πινάκων
    for(i=0; i<3; i++) {
        for(j=0; j<3; j++) {
            a[i][j] = rand()%9;
            b[i][j] = rand()%9;
        }
    }

    /* Εμφάνιση πινάκων */
    printf("\nThe First matrix is:\n");
    for(i=0; i<3; i++) {
        for(j=0; j<3; j++)
            printf("%d\t", a[i][j]);
        puts("");
    }

    printf("\nThe Second matrix is:\n");
    for(i=0; i<3; i++) {
        for(j=0; j<3; j++)
            printf("%d\t", b[i][j]);
        puts("");
    }
    /* Τέλος εμφάνισης πινάκων */

    /* Υπολογισμός του αθροίσματος */
    for(i=0; i<3; i++)
        for(j=0; j<3; j++)
            c[i][j] = a[i][j] + b[i][j];

    // Εμφάνιση τελικού πίνακα
    printf("\nThe result matrix is:\n");
    for(i=0; i<3; i++) {
        for(j=0; j<3; j++)
            printf("%d\t", c[i][j]);
        puts("");
    }

    return 0;
}
