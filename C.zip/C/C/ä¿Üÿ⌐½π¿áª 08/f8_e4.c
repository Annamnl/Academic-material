#include <stdio.h>
/*
* Φυλλάδιο 8, Άσκηση 4
*/
#define SIZE 100
int main(void) {

    char str[SIZE];
    int i = 0;
    printf("Insert string: ");
    // Διαβάζει χαρακτήρες από την τυπική είσοδο μέχρι να να βρεθεί χαρακτήρας νέας γραμμής ή τέλος αρχείου
    fgets(str, sizeof(str), stdin);

    printf("The spaced result string is:\n");
    // Σάρωση της str και προσθήκη χαρακτήρα κενού δεξιά από κάθε χαρακτήρα της str
    while (str[i] != '\0') {
        printf("%c ", str[i]);
        i++;
    }

    return 0;
}
