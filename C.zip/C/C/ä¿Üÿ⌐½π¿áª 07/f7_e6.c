int main(void) {
    int a[10];
    int *iptr;
    for (iptr = a; iptr < &a[10]; iptr++)
        *iptr = 0;

    return 0;
}

/**
Θα μηδενίσει όλα τα στοιχεία του πίνακα a.
Χρησιμοποιεί τον δείκτη iptr για τη διάσχιση των στοιχείων του πίνακα
*/
