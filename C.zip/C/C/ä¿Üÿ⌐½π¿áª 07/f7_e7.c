/*
* Φυλλάδιο 7, Άσκηση 7
*/
#include <stdio.h>

float addNums(float *n1, float *n2);

int main(void) {
    float x, y; // Ορισμός μεταβλητών
    printf("Please insert two floating point numbers: ");
    scanf("%f%f", &x, &y); // Ανάγνωση 2 αριθμών από το stdin

    // Κλήση της συνάρτησης addNums και εμφάνιση του αποτελέσματος
    printf("The result is: %f", addNums(&x, &y));
    return 0;

}
/*
* Συνάρτηση addNums. Επιστρέφει το αποτέλεσμα της
* πρόσθεσης 2 πραγματικών αριθμών
*/
float addNums(float *n1, float *n2) {
    return *n1 + *n2;
}






