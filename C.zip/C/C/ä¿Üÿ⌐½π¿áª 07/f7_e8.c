/*
* Φυλλάδιο 7, Άσκηση 8
*/
#include <stdio.h>
#include <stdlib.h>

int main(void) {

    int numTemp;
    float *temps, sum = 0;

    printf("Please insert number of temperatures: ");
    scanf("%d", &numTemp);

    // Dynamic memory allocation
    temps = (float *) malloc(numTemp*sizeof(float));

    if (temps == NULL)
        return 1; // Exit main with error

    int i;
    for (i=0; i< numTemp; ++i) {
        printf("Insert temp no %d: ", i);
        scanf("%f", &temps[i]);
        sum += temps[i];
    }

    float avg = sum/numTemp;
    printf("Average is: %f\n", avg);

    int tempCounter = 0;
    for (i=0; i< numTemp; ++i) {
        if (temps[i] > avg)
            tempCounter++;
    }

    printf("The number of temperatures more than %f is %d.\n", avg, tempCounter);

    free(temps);

    return 0;
}
