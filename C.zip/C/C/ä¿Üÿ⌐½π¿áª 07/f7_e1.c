#include <stdio.h>

int main(void) {
    int x, y;
    int *iPtr1, *iPtr2, *iPtr3;

    x = 5;
    y = 7;

    iPtr1 = &x;
    *iPtr1 = 10; // x = 10
    iPtr2 = &y;
    iPtr3 = iPtr2;
    y = *iPtr1; // y = x = 10
    *iPtr3 = *iPtr1;

    return 0;
}
