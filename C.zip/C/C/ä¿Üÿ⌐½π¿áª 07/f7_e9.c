/*
* Φυλλάδιο 7, Άσκηση 9
*/
#include <stdio.h>
#include <stdlib.h>

float average(int *marks, int n) {
    int i,sum=0;
    for (i=0; i<n; i++) {
        sum += *(marks+i);
        //sum += marks[i]); // // Εναλλακτικά της παραπάνω γραμμής
    }
    return ((float) sum/n);
}

int main(void) {
    int *marks;
    int i,n;
    puts("How many numbers are you gonna insert?:");
    scanf("%d",&n);
    marks=(int *) malloc(n*sizeof(int)); // Δέσμευση μνήμης
    if (marks==NULL) {
        printf("Could not allocate memory");
        exit(1);
    }
    for (i=0; i<n; i++) {
        printf("Please insert number %d: ",i+1);
        scanf("%d",(marks+i));
        //scanf("%d", &marks[i]); // Εναλλακτικά της παραπάνω γραμμής
    }
    printf("\nAverage of the inserted numbers is: %f\n", average(marks,n));
    free(marks);
    return 0;
}
