/*
* Φυλλάδιο 7, Άσκηση 3
*/
#include <stdio.h>

int main(void) {
    int x[5], i;

    for (i=0; i<5; i++) {
        x[i] = i*i;
        printf("%d ", x[i]);
    }

    /* Εκφράσεις i-viii */
    x;          // 4500
    &x[0];      // 4500
    *x;         // 0
    x[1];       // 1
    &x[1];      // 4504
    x+2;        // 4508
    *(x+2);     // 4
    *(&x[2] +1);// 9

    return 0;
}
