#include <stdio.h>
/*
* Φυλλάδιο 5, Άσκηση 3
* Πρώτοι αριθμοί
*/
int is_prime(int);

int main(void) {
    int i = 100, prime_cnt = 0; // prime_cnt για μέτρηση πλήθους πρώτων αριθμών που βρέθηκαν

    // Επαναληπτικά, εμφάνισε τους 20 Πρώτους αριθμούς από το 2 και μετά
    while (prime_cnt < 20) {
        if (is_prime(i)) {
            printf("%d ", i);
            prime_cnt++;
        }
        i++;
    }

    return 0;
}

// Ορισμός συνάρτησης is_prime
// Ελέγχει αν ένας ακέραιος αριθμός είναι πρώτος η όχι
int is_prime(int n) {
    int i;

    for (i=2; i<n; i++)
        if (n % i == 0)
            return 0;
    return 1;
}
