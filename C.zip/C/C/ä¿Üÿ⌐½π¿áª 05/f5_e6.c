/*
Να υλοποιήσετε ένα πρόγραμμα το οποίο να δημιουργεί 100 τυχαίους αριθμούς από 5-50 και στο τέλος να εμφανίζει πόσοι από αυτούς είναι άρτιοι και πόσοι περιττοί.
*/
#include <stdio.h>
#include <stdlib.h> /* Συναρτήσεις srand(), rand() */
#include <time.h> /* Συνάρτηση time()*/

int main(void) {
    int i, even = 0, odd = 0, num;
    srand(time(NULL));

    for(i=0; i<100; i++) {
        num = rand()%46 + 5; // Random number in [5, 50]
        if (num%2 == 0)
            even++;
        else
            odd++;
    }
    printf("Even numbers: %d\nOdd numbers: %d\n", even, odd);

    return 0;
}
