#include <stdio.h>
/*
* Φυλλάδιο 5, Άσκηση 1
*/
int calc(int, int);

int main(void) {
    int x = 2, y = 4;
    y = calc(y, x);
    x = calc(y, x);
    printf("%d %d\n", x, y); // Θα εμφανίσει 22 10
    return 0;
}

int calc(int a, int b) {
    a = 2*a + b;
    return a;
}


/**
Θα εμφανίσει 22 10

*/
