#include <stdio.h>

int main(void) {
    int a, b;
    float c;
    a = 10;
    b = a/2;
    c = 4.5 + a;
    printf("%d %d %f\n", a, b, c);
    return 0;
}
