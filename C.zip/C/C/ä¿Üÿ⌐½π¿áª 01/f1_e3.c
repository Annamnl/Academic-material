#include <stdio.h>
/*
* Δήλωση μεταβλητών, εμφάνιση των
* τιμών τους στην οθόνη
*/
int main(void) {
    int x;
    char c;
    float y;

    x = 4;
    c  = 't';
    y = 5.78;

    printf("x = %d, c = %c, y = %f\n", x, c, y);
    return 0;
}
