#include <stdio.h>
// Γινόμενο 3 ακεραίων αριθμών
int main(void) {
    int x = 7, y = 5, z = 2;

    printf("Product is: %d", x*y*z);
    return 0;
}


