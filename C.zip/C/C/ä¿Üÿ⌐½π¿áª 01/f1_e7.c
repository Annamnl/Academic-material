#include <stdio.h>
/*
* Υπολογισμός περιμέτρου κύκλου
*/
#define PI 3.14
int main(void) {
    float r = 4.79, perimetros;
    perimetros = 2 * PI * r; // Υπολογισμός περιμέτρου κύκλου
    printf("Circumference is: %f\n", perimetros);
    return 0;
}
