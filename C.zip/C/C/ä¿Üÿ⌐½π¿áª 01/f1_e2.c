#include <stdio.h>
/*
* Δημιουργία σχήματος στην οθόνη
* με χρήση μίας printf()
*/
int main(void) {
    printf("*     *\n   *\n*     *\n");
    return 0;
}
