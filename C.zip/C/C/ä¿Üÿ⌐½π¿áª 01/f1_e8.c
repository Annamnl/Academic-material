#include <stdio.h>
/*
* Μετατροπή Fahrenheit σε celcius
*/
#define PI 3.14
int main(void) {
    float tempc, tempf = 85;
    tempc = (tempf - 32) / 1.8;
    printf("Temperature in celcius is: %.1f\n", tempc); // Στρογγυλοποίηση σε 1 δεκαδικό ψηφίο
    return 0;
}
