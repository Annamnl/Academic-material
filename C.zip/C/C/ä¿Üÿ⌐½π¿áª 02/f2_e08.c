#include <stdio.h>
/*
* Εμφάνιση πρώτου ψηφίου τετραψήφιου αριθμού
*/
int main(void) {
    int number;
    printf("Insert 4 digit number: ");
    scanf("%d", &number);
    printf("%d\n", number / 1000);
    return 0;
}
