/*
Τι θα εμφανίσει το παρακάτω πρόγραμμα;
*/
#include <stdio.h>
int main(void) {
    int a = 5, b;

    b = a--;
    printf("a: %d, b: %d\n", a, b);

    b = --a;
    printf("a: %d, b: %d\n", a, b);
    return 0;
}




/**
a: 4, b: 5
a: 3, b: 3
*/
