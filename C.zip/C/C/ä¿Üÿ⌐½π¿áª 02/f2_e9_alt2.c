#include <stdio.h>
/*
* Εξαγωγή ψηφίων 5ψήφιου αριθμού
* Παραλλαγή 2η
*/
int main(void) {
    int x, d1, d2, d3, d4, d5;

    printf( "Enter 5 digits integer: " );
    scanf( "%d", &x);
    // Διάσπαση ψηφίων με χρήση ακέραιας διαίρεσης
    // και υπόλοιπο ακέραιας διαίρεσης
    d1 =  x/10000;
    d2 = (x%10000)/1000;
    d3 = (x%1000)/100;
    d4 = (x%100)/10;
    d5 = x%10;

    printf("%d\n%d\n%d\n%d\n%d\n", d1, d2, d3, d4, d5);
    return 0;
}


