/*
Τι θα εμφανίσει το παρακάτω πρόγραμμα;
*/
#include <stdio.h>
int main(void) {
    int a = 5, b = 6, c = 7;

    printf("%d\n", (++a)-(b--)+(--c));
    return 0;
}




/**
6
*/
