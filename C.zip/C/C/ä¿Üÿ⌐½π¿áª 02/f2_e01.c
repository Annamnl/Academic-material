/* Ποια είναι η έξοδος του παρακάτω προγράμματος; */
#include <stdio.h>

int main(void) {
    int x = 10;

    x = x + x;
    printf("R1: %d\nR2: %d\n", x+x, x);

    return 0;
}



/**
R1: 40
R2: 20

*/
