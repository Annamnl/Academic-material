/*
Τι θα εμφανίσει το παρακάτω πρόγραμμα;
*/
#include <stdio.h>
int main(void) {
    int i = 5, j = 10, k = 15;
    printf("%d\n", (i <= j) == !(j <= k) ); // Τελεστής !

    /* Συνδυαστικοί τελεστές */
    i += 2;
    j -= ++i;
    k %= j;
    printf("%d %d %d\n", i, j, k);
    return 0;
}




/**
1ο printf: 0
2ο printf: 8 2 1
*/
