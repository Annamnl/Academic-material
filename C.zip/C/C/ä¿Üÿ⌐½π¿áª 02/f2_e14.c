/*
Να υπολογίσετε πόσα bytes καταναλώνει ο τύπος ακεραίων, χαρακτήρων, πραγματικών (float) και πραγματικών διπλής ακρίβειας (double) στον υπολογιστή που χρησιμοποιείτε για μεταγλώττιση προγραμμάτων C. Να χρησιμοποιήσετε τον τελεστή sizeof για τον υπολογισμό.
*/
#include <stdio.h>
int main(void) {
    printf("Integer: %u\n", sizeof(int));
    printf("Character: %u\n", sizeof(char));
    printf("Float: %u\n", sizeof(float));
    printf("Double: %u\n", sizeof(double));

    return 0;
}
