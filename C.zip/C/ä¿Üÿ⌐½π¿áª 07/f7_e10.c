/*
* Δυναμική δέσμευση μνήμης με malloc και realloc
*/
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int numOfGrades, i, totalNumGrades = 0;
    float grade;
    float *grades;
    short answer;

    // Η πρώτη φορά που ζητά το πρόγραμμα βαθμολογίες
    printf("Insert number of grades: ");
    scanf("%d", &numOfGrades);
    // Δυναμική διάθεση μνήμης την πρώτη φορά με malloc
    totalNumGrades += numOfGrades;
    grades = (float *) malloc(totalNumGrades*sizeof(float));
    // Ανάγνωση των βαθμολογιών
    for (i=0; i<totalNumGrades; ++i) {
        printf("Enter grade no %d: ", i+1);
        scanf("%f", &grades[i]);
    }

    // Ερώτηση για περαιτέρω ανάγνωση βαθμολογιών
    printf("\nDo you want to add more grades (1: Yes, 0: No)?");
    scanf("%d", &answer);

    while (answer != 0) {
        // Επαναληπτική διαδικασία για επιπλέον βαθμολογίες
        printf("Insert number of grades: ");
        scanf("%d", &numOfGrades);
        totalNumGrades += numOfGrades;
        // Αύξηση χωρητικότητας πίνακα μέσω realloc
        grades = (float *) realloc(grades, totalNumGrades*sizeof(float));

        // Ανάγνωση επόμενων βαθμολογιών
        for (; i<totalNumGrades; ++i) {
            printf("Enter grade no %d: ", i+1);
            scanf("%f", &grades[i]);
        }

        printf("\nDo you want to add more grades (1: Yes, 0: No)? ");
        scanf("%d", &answer);

    }

    float sum = 0;
    for (i=0; i<totalNumGrades; ++i) {
        sum += grades[i];
        printf("%.1f ", grades[i]);
    }

    printf("\nAverage is: %.1f", sum/totalNumGrades);

    // Αποδέσμευση της μνήμης
    free(grades);

    return 0;
}
