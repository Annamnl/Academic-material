#include <stdio.h>
/*
* Υπολογισμός φόρου κλιμακωτά
*/
int main(void) {
    float income, tax;

    // Λήψη εισοδήματος από τον χρήστη
    printf("Please type income and press enter: ");
    scanf("%f", &income);

    // Υπολογισμός φόρου κλιμακωτά
    if (income <= 12000)
        printf("Tax is: 0 euro");
    else if (income <= 20000) {
        tax = 0 + (income - 12000) * 0.1;
        printf("Tax is %.2f euro", tax);
    }
    else if (income <= 30000) {
        tax = (8000 * 0.1) + (income - 20000) * 0.2;
        printf("Tax is %.2f  euro", tax);
    }
    else {
        tax = (8000 * 0.1) + (10000 * 0.2) + (income - 30000) * 0.35;
        printf("Tax is %.2f  euro", tax);
    }

    return 0;
}
