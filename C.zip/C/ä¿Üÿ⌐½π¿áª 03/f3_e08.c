#include <stdio.h>
/*
* Εξάσκηση με εμφωλευμένες if
*/
int main(void) {
    int i, j, k;

    printf("Enter numbers: ");
    scanf("%d%d%d", &i, &j, &k);

    if((i+j == k) || (j+k == i) || (i+k == j)) {
        if(i >= 0 && i <= 10)
            printf("%d\n", i);
        if(j >= 0 && j <= 10)
            printf("%d\n", j);
        if(k >= 0 && k <= 10)
            printf("%d\n", k);
    } else {
        printf("Enter numbers: ");
        scanf("%d%d%d", &i, &j, &k);
        if((i%6 == 0) || (i != 20))
            printf("%d\n", i);
        if((j%6 == 0) || (j != 20))
            printf("%d\n", j);
        if((k%6 == 0) || (k != 20))
            printf("%d\n", k);
    }
    return 0;
}
