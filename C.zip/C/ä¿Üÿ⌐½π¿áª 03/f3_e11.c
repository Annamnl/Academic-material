#include <stdio.h>
/*
* Επίδειξη τριαδικού τελεστή ?:
*/
int main(void) {
    int a = 5, k;
    k = (a > 0) ? 100 : -1;
    printf("%d", k);

    return 0;
}



/* Εμφανίζει:
100

*/

