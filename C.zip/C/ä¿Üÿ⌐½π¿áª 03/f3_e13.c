#include <stdio.h>
/*
* Αναγνώριση λατινικών χαρακτήρων
*/
int main(void) {
    char ch;

    printf("Insert a character: \n");
    scanf("%c", &ch);

    if(ch >= 'A' && ch <= 'Z') // Έλεγχος για κεφαλαίο λατινικό χαρακτήρα
        printf("It's a capital letter!\n");
    // Έλεγχος για πεζό χαρακτήρα
    else if (ch >= 97 && ch <= 122) // ισοδύναμο με: (ch >= 'a' && ch <= 'z')
        printf("It's a lower case letter\n");
    else
        printf("Not a latin character...\n"); // Οποιοσδήποτε άλλος χαρακτήρας

    return 0;
}
