#include <stdio.h>
/*
* Υπολογισμός αθροίσματος ψηφίων
Να γραφεί ένα πρόγραμμα το οποίο να ζητάει από τον χρήστη έναν ακέραιο αριθμό. Αν ο αριθμός είναι τριψήφιος, να εμφανίζει το άθροισμα των τριών ψηφίων του, αλλιώς να εμφανίζει «Wrong number...»
*/
int main(void) {
    int num, sum;
    printf("Please insert an integer: ");
    scanf("%d", &num);

    // Έλεγξε αν είναι τριψήφιος
    if (num >= 100 && num <= 999) {
        sum = num/100 + (num/10)%10 + num%10; // digit1 + digit2 + digit3
        printf("The sum of number's digits is: %d.\n", sum);
    } else
        printf("Wrong number...\n");

    return 0;
}

