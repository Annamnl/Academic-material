#include <stdio.h>
/*
* Χρήση τριαδικού τελεστή ?:
*/
int main(void) {
    float p1, p2, p3;
    printf("Enter prices: ");
    scanf("%f%f%f", &p1, &p2, &p3);
    // Άν έστω και ένα από τα παραπάνω είναι > 100, εμφάνισε "Yes"
    printf("%s\n", (p1 > 100 || p2 > 100 || p3 > 100) ? "Yes" : "No");

    // Εναλλακτικά του παραπάνω
    // (p1>100 || p2>100 || p3>100)? printf("Yes") : printf("No");

    return 0;
}
