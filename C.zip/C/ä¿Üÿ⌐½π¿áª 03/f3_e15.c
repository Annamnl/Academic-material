#include <stdio.h>
/*
* Υπολογισμός φόρου
*/
int main(void) {
    float income;

    // Λήψη εισοδήματος από τον χρήστη
    printf("Please type income and press enter: ");
    scanf("%f", &income);

    // Υπολογισμός φόρου ανάλογα με το εισόδημα
    if (income <= 12000)
        printf("Tax is: 0 euro");
    else if (income <= 20000)
        printf("Tax is %.2f euro", income * 0.1);
    else if (income <= 30000)
        printf("Tax is %.2f  euro", income * 0.2);
    else
        printf("Tax is %.2f  euro", income * 0.35);

    return 0;
}
