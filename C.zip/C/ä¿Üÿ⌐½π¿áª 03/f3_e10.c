#include <stdio.h>
/*
* Μοναδιαίοι τελεστές σε λογικές εκφράσεις
*/
int main(void) {
    int a = 4, b = 5, c = 3;

    if(a && a/b)
        printf("One\n");
    else
        printf("Two\n");
    if(++a == b++)
        printf("One\n");
    else
        printf("Two\n");
    if(a < b < c)
        printf("One\n");
    else
        printf("Two\n");

    return 0;
}



/* Εμφανίζει:
Two
One
One

*/
