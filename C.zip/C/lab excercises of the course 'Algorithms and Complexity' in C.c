//ΕΡΓΑΣΤΗΡΙΟ 1
//Διαίρει και Βασίλευε - Ακολουθία Fibonacci με αναδρομή

{

#include <stdio.h>
#include <stdlib.h>

int main(){
    int n,x;
    printf("Pliktrologise ton deikti tou orou pou tha ypologiseis: ");
    scanf("%d",&n);

    x=Fibo(n);

    printf("Apotelesma: %d",x);

return 0;
}

int Fibo(int n){

    if(n==0) return 0;
    if(n==1) return 1;

    return Fibo(n-1)+Fibo(n-2);

}
}

//Ακολουθία Fibonacci με πίνακα τριών θέσεων

{
#include <stdio.h>
#include <stdlib.h>

int main(){
    int P[3];
    int i,x;
    printf("Pliktrologise ton oro pou tha ypologiseis: ");
    scanf("%d",&x);
    P[0]=0;
    P[1]=1;

    for(i=2; i<=x; i++){
        P[i%3]=P[(i-1)%3]+P[(i-2)%3];
    }

    for(i=0; i<3; i++){
        printf("thesi %d : %d\n",i,P[i]);
    }
    return 0;
}
}

//ΕΡΓΑΣΤΗΡΙΟ 2
//Διαίρει και Βασίλευε - Εύρεση Αθροίσματος με αναδρομή

{

#include <stdio.h>
#include <stdlib.h>

int par(int a, int b)
{
    int x=0;
    if (a==b) return 1;
    if (b==0) return 1;
    return par(a-1, b) + par(a-1, b-1) ;
}


int main()
{
 int n,k, sum=0;
 printf("Dose n kai k me n>k        ");
 scanf ("%d", &n) ;
 scanf ("%d", &k) ;

 sum = par(n,k);

 printf("Apotelesma: %d",sum);

 return 0;
 }

}

//Δυαδική Αναζήτηση με αναδρομή

{
	#include <stdio.h>
#include <stdlib.h>

int a[11]={1,5,8,12,17,30,45,52,64,72,83};

int binary(int start, int end, int x){
    int mid=(start+end)/2;

    if (end<start) return -1;

    if (a[mid]==x) return mid;

    if (a[mid]<x){
        return binary(mid+1,end,x);
    }
    if (a[mid]>x){
        return binary(start,mid-1,x);
    }



}


int main(){
    int x,pos;
    printf("Poion arithmo psaxneis?   ");
    scanf("%d",&x);
    pos=binary(0,10,x)+1;

    if (pos>0) printf("\nEinai sti thesi: %d",pos);
    if (pos==0) printf("\nDen to vrika");
    return 0;
}
}

//Άπλειστος Αλγόριθμος - Πρόβλημα υπολογισμού κερμάτων

{
	#include <stdio.h>
#include <stdlib.h>

int main(){
    int n=8;
    int coins[8]={1,2,5,10,20,50,100,200};
    int num_of_coins[8]={0,0,0,0,0,0,0,0};
    int cash = 578,i;

    while (cash>0){
        n--;
        num_of_coins[n]=cash/coins[n];
        cash=cash%coins[n];

    }
    printf("\nApotelesma:");
    for (i=8-1; i>=0; i--){
        printf("\n %d: %d",coins[i],num_of_coins[i]);
    }



return 0;}

}

//ΕΡΓΑΣΤΗΡΙΟ 3 - Σάκος του ληστή

{
#include <stdio.h>
#include <stdlib.h>

int main(){


    int n=3,w1=5,i,j,v[3]={5,3,4},w[3]={3,2,1};
    int keep[4][6], val[4][6];

    for (i=0;i<=n;i++){
        for(j=0; j<=w1; j++){
            if(i==0 || j==0){
                val[i][j]=0;
            } else {
                if (j<w[i-1]){
                    val[i][j]=val[i-1][j];
                } else {
                    val[i][j]= max(val[i-1][j],v[i-1]+val[i-1][j-w[i-1]]);
                    if (val[i][j]==v[i-1]+val[i-1][j-w[i-1]])   keep[i][j]=1;
                }
            }

        }
    }


    printf("Megisti aksia: %d",val[3][5]);

    j=5;
    for(i=3;i>=0;i--){
        if (keep[i][j]==1){
            printf("\nPira to %d",i);
            j=j-w[i-1];
        }
    }

    return 0;
}

int max(int a, int b){
    return a>b?a:b;
}
}

//ΕΡΓΑΣΤΗΡΙΟ 4 - Εύρεση μέγιστου αθροίσματος πίνακα με αναδρομή

{
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(){

int a[8]={-2,-6,7,-2,-3,1,5,-8};

printf ("Max: %d", divide (a, 0, 7) );

    return 0;
}


int divide (int a[], int l, int r){
    if (l==r) return a[l];
    int m = (l+r)/2;
    return max3(divide(a,l,m), divide(a,m+1,r), midSum (a, l, m, r));
}

int midSum(int a[], int l, int m, int r){

    int i, lsum=INT_MIN, rsum=INT_MIN, sum1=0, sum2=0;

    for (i=m+1; i<=r; i++){
        sum1+=a[i];
        if (sum1>rsum){
            rsum=sum1;
        }
    }

    for (i=m; i>=l; i--){
        sum2+=a[i];
        if (sum2 > lsum){
            lsum=sum2;
        }
    }

    return (lsum+rsum);
}

int max2 (int a, int b){
    return (a>b)?a:b;
}

int max3 (int a, int b, int c){
    return max2(max2(a,b),c);
}

}

//ΕΡΓΑΣΤΗΡΙΟ 5 - Δυναμικός Προγραμματισμός

{
	#include <stdio.h>
#include <stdlib.h>

int main(){
    int i,j,tmp;
    int s[9]={0,0,4,5,0,4,3,7,3};
    int f[9]={0,5,8,7,2,9,5,9,10};

    for (i=0; i<8; i++){
        for (j=0; j<8-i; j++){
            if (s[j]>s[j+1]){
               tmp = s[j];
               s[j] = s[j+1];
               s[j+1] = tmp;

               tmp = f[j];
               f[j] = f[j+1];
               f[j+1] = tmp;
            }
        }
    }

    for (i=0; i<9; i++ ){
        printf("\n %d , %d", s[i], f[i]);
    }

    int l[9]={0};
    for(i=1; i<9; i++){
        for (j=i-1; j>=1; j--){
            if (s[i]>=f[j]){
                l[i]=j;
                break;
            }
        }
    }
    printf("\n");
    for (i=0; i<9; i++ ){
        printf("\n %d ", l[i]);
    }

    int opt[9]={0};
    opt[0]=0;

    for (i=1; i<9; i++){
        opt[i] = max (opt[i-1], 1+opt[l[i]]);
    }
    printf("\n");
    for (i=0; i<9; i++ ){
        printf("\n %d ", opt[i]);
    }

    return 0;
}

int max(int a, int b){
    return a>b ? a : b;
}
}

//ΕΡΓΑΣΤΗΡΙΟ 6
//Συγχώνευση ταξινομημένων πινάκων σε ένα ταξινομημένο πίνακα

{
	#include <stdio.h>
#include <stdlib.h>

int main(){

    int i=0, j=0, k=0;
    int a[5]={5,12,20,32,33},b[5]={3,10,22,35,37},c[10];

    while ( i<5 && j<5 ){  //σύγκριση πινάκων
        if (a[i] <= b[j]){
            c[k] = a[i];
            i++;
            k++;
        } else {
            c[k] = b[j];
            j++;
            k++;
        }
    }

    if(i == 5){
        while (j < 5){
            c[k]=b[j];
            k++;
            j++;
        }
    }
    if(j == 5){
        while (i < 5){
            c[k]=a[i];
            k++;
            i++;
        }
    }

    for (k = 0; k<10; k++){
        printf ("%d, ",c[k]);
    }

    return 0;
}

}

//Merge Sort με αναδρομή

{
	#include <stdio.h>
#include <stdlib.h>

int a[10]={50,40,10,5,12,17,35,21,8,25}, t[10];

int main(){
    int i=0;
    merge_sort(0,9);
    for (i=0; i<10; i++){
        printf("%d, ",a[i]);
    }
    return 0;
}

void merge_sort(int left, int right){
    if(left<right){
        int middle = (left+right)/2;
        merge_sort(left,middle);
        merge_sort(middle+1,right);
        merge1(left,middle,right);
    }
}

void merge1(int left, int middle, int right){
    int i=left, j=middle+1, k=left;

    while (i<=middle && j<=right){
        if(a[i] <= a[j]){
            t[k]=a[i];
            k++;
            i++;
        } else {
            t[k]=a[j];
            k++;
            j++;
        }
    }

    while (i<=middle){
        t[k]=a[i];
        k++;
        i++;
    }
    while (j<=right){
        t[k]=a[j];
        k++;
        j++;
    }

    for (i=left; i<=right; i++){
        a[i]=t[i];
    }

}
}

//ΕΡΓΑΣΤΗΡΙΟ 7
//Εύρεση πλήθους συγκρίσεων για στοιχεια του πίνακα όπου το αριστερό είναι μεγαλύτερο από το δεξιά

{
#include <stdio.h>
#include <stdlib.h>

int main(){

    int a[]={2,4,1,3,5,6};
    int i,j,c=0;

    for (i=0; i<6; i++){
        for (j=0; j<6; j++){
            if (i<j && a[i]>a[j]){
               c++;
            }
        }
    }

    printf("%d",c);

    return 0;
}
}

//Όμοια άσκηση με τη χρήση Merge Sort με αναδρομή

{

#include <stdio.h>
#include <stdlib.h>

int a[]={2,4,1,3,5,6}, t[6];

int main(){
    int i=0;
    printf("\n%d\n",merge_sort(0,5));
    for (i=0; i<6; i++){
        printf("%d, ",a[i]);
    }
    return 0;
}

int merge_sort(int left, int right){
    if(left>=right) return 0;

    int middle = (left+right)/2;
    int count=0;
    count=merge_sort(left,middle);
    count=count+merge_sort(middle+1,right);
    count=count+merge1(left,middle,right);

    return count;
}

int merge1(int left, int middle, int right){
    int i=left, j=middle+1, k=left, count;
count=0;
    while (i<=middle && j<=right){

        if(a[i] < a[j]){
            t[k]=a[i];
            k++;
            i++;
        } else {
            t[k]=a[j];
            k++;
            j++;
            count+=(middle+1)-i;
        }
    }

    while (i<=middle){
        t[k]=a[i];
        k++;
        i++;
    }
    while (j<=right){
        t[k]=a[j];
        k++;
        j++;
    }

    for (i=left; i<=right; i++){
        a[i]=t[i];
    }
    return count;
}

}

//ΕΡΓΑΣΤΗΡΙΟ 8
//Απλή άσκηση με Δυναμικό Προγραμματισμό (opt)

{
#include <stdio.h>
#include <stdlib.h>

int main(){

    int s[9]={0,2,7,5,9,12,3,8,11};

    int opt[9], i;

    opt[0]=s[0];
    opt[1]=s[1];

    for (i=2; i<9; i++){
        if (opt[i-1] > s[i]+opt[i-2]) {
            opt[i] = opt[i-1];
        } else {
            opt[i] = s[i]+opt[i-2];
        }
    }
    for (i=0; i<9; i++){
     printf("%d    ",opt[i]);
    }
    return 0;
}
}

//Άσκηση με ΔΠ (opt)

{
	#include <stdio.h>
#include <stdlib.h>

int main(){

    int s[9]={0,2,7,5,9,12,3,8,11};
    int r[9]={0,0,0,1,2,2,5,5,6};
    int opt[9], i;

    opt[0]=s[0];
    opt[1]=s[1];

    for (i=2; i<9; i++){
    if (opt[i-1] > s[i]+opt[r[i]]) {
            opt[i] = opt[i-1];
        } else {
            opt[i] = s[i]+opt[r[i]];
        }
    }

    for (i=0; i<9; i++){
     printf("%d    ",opt[i]);
    }
    return 0;
}
}


//ΕΡΓΑΣΤΗΡΙΟ 9 - Εύρεση ελάχιστου κόστους 1)με απλή σύγκριση και 2) με ΔΠ και αναδρομή

{
#include <stdio.h>
#include <stdlib.h>

int main(){

    int s[10]={11,9,9,12,12,12,12,9,9,11};
    int pos=-1, max=0, i, j, c=10, r=1, n=10, sum=0;

    for (i=0; i<n-3; i++){
        sum=0;
        for (j=i; j<i+4; j++){
            sum+=s[j];
            if (max < sum && sum > 4*c){
                max = sum;
                pos = i;
            }
        }
    }

    sum = 0;
    if (pos == -1){
        for (i=0; i<n; i++){
            sum+=s[i]*r;
        }
    } else {
        for (i=0; i<pos; i++){
            sum += s[i]*r;
        }
    }

    sum += 4*c;
    for (i = pos+4; i<n; i++){
        sum += s[i]*r;
    }
    printf ("\n%d",sum);

    printf ("\n%d",opt(10));

    int opt1[11];
    opt1[0]=0;
    opt1[1]=r*s[0];
    opt1[2]=opt1[1]+r*s[1];
    opt1[3]=opt1[2]+r*s[2];
    for (i=4; i<=n; i++){
        opt1[i]=min (opt1[i-1]+r*s[i-1], 4*c+opt1[i-4]);
    }

    printf ("\n%d",opt1[10]);


    return 0;

}

int opt (int i){
    int s[10]={11,9,9,12,12,12,12,9,9,11};
    int c=10, r=1;
    if (i==0) return 0;
    if (i==1) return r*s[0];
    if (i==2) return r*s[0]+r*s[1];
    if (i==3) return r*s[0]+r*s[1]+r*s[2];
    return min (s[i-1]*r+opt(i-1), 4*c+opt(i-4));
}

int min (int a, int b){
    return a<b?a:b;
}

}
//--------------------------------------
#include <stdio.h>
#include <stdlib.h>
int main()
{
    //thema A)

    srand(time(NULL));
    int n,i,j;
    double simeia_x,simeia_y;
    printf("dwse mou posa tixaia simeia thes");
    scanf("%d",&n);

    double varoi[n][n];//dimiourgw ena pinaka me ta varoi

    //dimiourgw tis tixees sintetagmenes
    for(i=0;i<n;i++) //trexw tin epanalipsi gia n fores pou exei dwsei o xristis
    {
        //dimiourgw ta tixea simeia
        simeia_x=(rand()%10%10;
        simeia_y=(rand()%10)%10;

        //apothikeuei sta tixea simeia ta tixea varoi
        varoi[simeia_x][simeia_y]=rand()%10;
    }
//thema B)

    //o exantlitikos algorithos kathe fora psaxnei apo tin arxi ta panta

    int max=0;//vazw mia timi tin xamiloteri gia na vrw to max

    //2 epanalipsis gia na mpw mesa ston pinaka
    for(i=0;i<simeia_x;simeia_x++)
    {
        for(j=0;j<simeia_y;j++)
        {
            if (max<varoi[simeia_x][simeia_y])//elegxw an iparxei megalitero varos
            {
                max=varoi[simeia_x][simeia_y];//allazw tin timi tou max me tin kathe megisti
            }
        }
    }

    //emfanizw tin megisti timi max
    printf("ii megisti timi einai %d",max);

    //thema Ã)
    // se auto to erwtima efarmozw tin merge sort
    //kalw tin sinartisi merge pou tin exw ilopoiisi exw apo tin main kai psaxni mono stis sintetagmenes
    //x ara san enan monodiastato pinaka
    merge_sort(0,simeia_x);

    //thema Å)

    merge_sort(0,simeia_x))


)

//dimiourgw tis sinartiseis exw apo tin main gia to erwtima Ã (merge_sort kai merge1)

void merge_sort(int left, int right){
    if(left<right){
        int middle = (left+right)/2;
        merge_sort(left,middle);
        merge_sort(middle+1,right);
        merge1(left,middle,right);
    }
}

void merge1(int left, int middle, int right){
    int i=left, j=middle+1, k=left;

    while (i<=middle && j<=right){
        if(a[i] <= a[j]){
            t[k]=a[i];
            k++;
            i++;
        } else {
            t[k]=a[j];
            k++;
            j++;
        }
    }

    while (i<=middle){
        t[k]=a[i];
        k++;
        i++;
    }
    while (j<=right){
        t[k]=a[j];
        k++;
        j++;
    }

    for (i=left; i<=right; i++){
        a[i]=t[i];
    }
}
}

//dimiourgw tin sinartisi merge me anadromi tou erwtimatos Å

int merge_sort(int left, int right){
    if(left>=right) return 0;

    int middle = (left+right)/2;
    int count=0;
    count=merge_sort(left,middle);
    count=count+merge_sort(middle+1,right);
    count=count+merge1(left,middle,right);

    return count;
}

int merge1(int left, int middle, int right){
    int i=left, j=middle+1, k=left, count;
count=0;
    while (i<=middle && j<=right){

        if(a[i] < a[j]){
            t[k]=a[i];
            k++;
            i++;
        } else {
            t[k]=a[j];
            k++;
            j++;
            count+=(middle+1)-i;
        }
    }

    while (i<=middle){
        t[k]=a[i];
        k++;
        i++;
    }
    while (j<=right){
        t[k]=a[j];
        k++;
        j++;
    }

    for (i=left; i<=right; i++){
        a[i]=t[i];
    }
    return count;
}


//ΤΕΛΟΣ
