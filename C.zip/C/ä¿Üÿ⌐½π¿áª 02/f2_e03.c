#include <stdio.h>

int main(void) {
    float i = 2.53, j = 7.25, tmp;
    int k;

    tmp = i - (int)i; /* Εύρεση δεκαδικού μέρους του i */
    k = (int)i; // Αποθήκευση του ακέραιου μέρους του i γιατί το i θα αλλάξει παρακάτω
    i = (int)j + tmp; // Αλλαγή του i
    tmp = j - (int)j; /* Εύρεση δεκαδικού μέρους του j */
    j = tmp + k; // Αλλαγή του j

    printf("i: %f, j: %f\n", i, j);
    return 0;
}
