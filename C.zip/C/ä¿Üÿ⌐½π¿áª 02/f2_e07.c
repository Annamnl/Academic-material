#include <stdio.h>
/*
* Υπολογισμός ρέστων για
* αγορά πιάτων και ποτηρίων
*/
int main(void) {
    int plates, cups; // πλήθος πιάτων και ποτηριών
    float plate_price, cup_price, amnt; // τιμές τεμαχίου

    printf("Enter plates: ");
    scanf("%d", &plates);
    printf("Enter plate price: ");
    scanf("%f", &plate_price);
    printf("Enter cups: ");
    scanf("%d", &cups);
    printf("Enter cup price: ");
    scanf("%f", &cup_price);
    printf("Enter paid amount: ");
    scanf("%f", &amnt);

    // Υπολογισμός ρέστων
    printf("Change: %.2f\n", amnt - (plates*plate_price) - (cups*cup_price));
    return 0;
}
