#include <stdio.h>
/*
* Εξαγωγή ψηφίων 5ψήφιου αριθμού
* Παραλλαγή 1η
*/
int main(void) {
    int x, d1, d2, d3, d4, d5, d1r, d2r, d3r, d4r, d5r;

    printf( "Enter 5 digits integer: " ); // user prompt
    scanf( "%d", &x);
    // Διάσπαση ψηφίων με χρήση ακέραιας διαίρεσης
    // και υπόλοιπο ακέραιας διαίρεσης
    d1 =  x/10000;
    d1r = x%10000;

    d2 =  d1r/1000;
    d2r = d1r%1000;

    d3 =  d2r/100;
    d3r = d2r%100;

    d4 =  d3r/10;
    d4r = d3r%10;

    d5 =  d4r/1;
    d5r = d4r%1;

    printf("%d\n%d\n%d\n%d\n%d\n", d1, d2, d3, d4, d5);
    return 0;
}


