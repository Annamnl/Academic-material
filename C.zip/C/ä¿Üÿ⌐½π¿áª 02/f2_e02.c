/* Ποια είναι η έξοδος του παρακάτω προγράμματος; */
#include <stdio.h>

int main(void) {
    float i = 2.3, j = 10.5;
    int x = (int)i + j;

    printf("R1: %d\nR2: %d\n", x, (int)(i + (int)j));
    return 0;
}



/**
R1: 12
R2: 12

*/
