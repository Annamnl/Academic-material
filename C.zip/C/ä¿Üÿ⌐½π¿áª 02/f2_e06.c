#include <stdio.h>
/*
* Διάβασμα πλήθους επιτυχόντων και αποτυχόντων.
* Εμφάνιση ποσοστών επιτυχίας και αποτυχίας.
*/
int main(void) {
    int suc, fail;
    printf("Enter successful students: ");
    scanf("%d", &suc);
    printf("Enter failed students: ");
    scanf("%d", &fail);
    printf("Success: %.2f%% Failed: %.2f%%\n", 100.0*suc/(suc+fail), 100.0*fail/(suc+fail));
    return 0;
}
