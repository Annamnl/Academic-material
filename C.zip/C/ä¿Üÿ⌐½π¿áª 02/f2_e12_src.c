/*
Τι θα εμφανίσει το παρακάτω πρόγραμμα;
*/
#include <stdio.h>
int main(void) {
    int i = 5, j = 10, k;

    i = (i > 5) + (j <= 10);
    j = (i == 5) + ((j+2) >= 10);
    k = (i != 1);
    printf("%d %d %d\n", i, j, k);
    return 0;
}




/**
1 1 0
*/
