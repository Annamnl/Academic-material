#include <stdio.h>

int main(void) {
    int i;
    double j;
    printf("Enter numbers: ");
    scanf("%d%lf", &i, &j);
    printf("%f\n", 3*(i+j));
    return 0;
}
