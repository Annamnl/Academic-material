#include <stdio.h>
/*
* Υπολογισμός περιμέτρου
* και εμβαδόν κύκλου
*/
#define PI 3.14
int main(void)
{
    //const float PI = 3.14; // Εναλλακτικός τρόπος δήλωσης σταθεράς
    float r;
    printf("Please insert circle radius: ");// προτροπή στον χρήστη
    scanf("%f", &r); // Ανάγνωση ακτίνας από χρήστη

    // Υπολογισμός περιμέτρου
    float perimetros;
    perimetros = 2 * PI * r;
    printf("Perimetros: %f\n", perimetros);

    // Υπολογισμός εμβαδού
    float emvadon;
    emvadon = PI*r*r;
    printf("Emvadon: %f\n", emvadon);

    return 0;
}
