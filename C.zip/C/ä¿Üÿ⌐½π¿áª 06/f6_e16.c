#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Αναζήτηση σε δισδιάστατο με βαθμολογίες
*/
#define N 10
#define M 3

int main(void) {

    // Δηλώσεις πινάκων και μεταβλητών
    int GRADES[N][M], CODE[N], i, j;
    srand(time(NULL));

    // Δημιουργία πινάκων
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++) {
            GRADES[i][j] = rand()%11; // 0-10
        }
        // Δημιουργία του πίνακα CODE
        CODE[i] = 1000 + rand() % 9000; // 1000-9999 (τετραψήφιος)
    }

    // Εμφάνιση πινάκων
    printf("Grades:\n");
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++)
            printf("%3d ", GRADES[i][j]);
        puts("");
    }

    printf("CODES:\n");
    for(i=0; i<=N-1; i++)
        printf("%4d\n", CODE[i]);
    puts("");

    // Αναζήτηση σε όλο τον πίνακα
    unsigned short found = 0;
    for(i=0; i<=N-1; i++) {
        for(j=0; j<=M-1; j++) {
            if (GRADES[i][j] == 10) {
                printf("Code: %d, Assignment: %d\n", CODE[i], j+1);
                found = 1;
            }
        }
    }

    // Περίπτωση που δε βρέθηκε καμία εργασία με 10
    if (found == 0)
        puts("No assignment was graded 10.");

    return 0;
}
