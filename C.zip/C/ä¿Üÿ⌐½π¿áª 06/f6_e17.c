#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Ταξινόμηση σε βαθμολογίες
*/
#define N 10

int main() {

    // Δηλώσεις πινάκων και μεταβλητών
    int GRADES[N], CODE[N], i, j;
    srand(time(NULL));

    // Δημιουργία πινάκων
    for(i=0; i<=N-1; i++) {
        GRADES[i] = rand()%11; // 0-10
        // Δημιουργία του πίνακα CODE
        CODE[i] = 1000 + rand() % 9000; // 1000-9999 (τετραψήφιος)
    }

    // Εμφάνιση πινάκων
    printf("GRADES:\n");
    for(i=0; i<=N-1; i++)
        printf("%3d\n", GRADES[i]);
    puts("");

    printf("CODES:\n");
    for(i=0; i<=N-1; i++)
        printf("%4d\n", CODE[i]);
    puts("");

    // Ταξινόμηση πίνακα
    int temp;
    for (i=0; i<=N-2; ++i)
        for (j=0; j<=N-i-2; j++)
            if(GRADES[j]<GRADES[j+1]) {
                temp = GRADES[j];
                GRADES[j] = GRADES[j+1];
                GRADES[j+1] = temp;
                // Διατήρηση συσχέτισης με πίνακα CODE
                // αντιμεταθέτωντας επίσης τα αντίστοιχα στοιχεία
                temp = CODE[j];
                CODE[j] = CODE[j+1];
                CODE[j+1] = temp;
            }

    // Εμφάνιση πινάκων
    printf("Sorted GRADES:\n");
    for(i=0; i<=N-1; i++)
        printf("%3d\n", GRADES[i]);
    puts("");

    printf("Sorted CODES:\n");
    for(i=0; i<=N-1; i++)
        printf("%4d\n", CODE[i]);
    puts("");

    // Εμφάνιση των 3 πρώτων στοιχείων
    for (i=0; i<=2; ++i)
        printf("Winner %d: Code %d\n", i+1, CODE[i]);

    return 0;
}
