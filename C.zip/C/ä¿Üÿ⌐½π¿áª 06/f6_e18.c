#include <stdio.h>
/*
* Πίνακας ως παράμετρος συνάρτησης
*/
#define N 10
int array_max(int[]);

int main(void) {
    int i, arr1[N], arr2[N];

    for(i=0;i<N;i++) {
        printf("Enter element %d of arr1:", i);
        scanf("%d", &arr1[i]);
        printf("Enter element %d of arr2:", i);
        scanf("%d", &arr2[i]);
    }

    int max1, max2;
    max1 = array_max(arr1);
    max2 = array_max(arr2);

    if (max1 > max2)
        printf("\n\narr1 has the greatest element: %d\n", max1);
    else
        printf("\n\narr2 has the greatest element: %d\n", max2);

}

/*
* Επιστρέφει το μέγιστο στοιχείο του πίνακα m
*/
int array_max(int m[]) {
    int i, max = m[0]; // Έστω max το πρώτο στοιχείο

    for (i=1; i<N; i++)
        if(m[i]>max)
            max=m[i];
    return max;
}
