#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Καταγραφή μέγιστων θερμοκρασιών σε πίνακα
* και υπολογισμός avg, max & min
*/
#define N 31 // ορισμός μεγέθους πίνακα
int main(void) {

    // Αρχικοποίηση μετρητών
    int temp[N];
    size_t i; // Μετρητής για την επανάληψη for
    int max, min, maxp, minp; // Μεταβλητές για μέγιση θερμοκρασία και θέση της. Αντίστοιχα για ελάχιστη θερμοκρασία
    int sum=0; // Μεταβλητή sum για την εύρεση του αθροίσματος όλων τον θερμοκρασιών


    srand(time(NULL));
    for(i=0; i<N; i++) {
        /* Αρχικοποίηση πίνακα με τυχαίους
        ακεραίους από το 0 μέχρι το 40 για λόγους δοκιμής */
        // temp[i] = rand()%41;
        // Με βάση την εκφώνηση "Θα δέχεται τις θερμοκρασίες"
        printf("Insert temperature %d: ", i+1);
        scanf("%d", &temp[i]);
        /* Παράλληλα, προσθήκη κάθε στοιχείου στο sum */
        sum += temp[i];
    }

    // Εμφάνιση θερμοκρασιών για debugging
    printf("[ ");
    for(i=0; i<N; i++) {
        printf("%d ", temp[i]);
    }
    printf("]");

    /* Υπολογισμός μέγιστης και ελάχιστης θερμοκρασίας */
    max = temp[0]; // Έστω ότι το πρώτο στοιχείο περιέχει το μέγιστο
    maxp = 0; // Η θέση του πρώτου στοιχείου (θέση 0 δηλ. η πρώτη θέση)
    // Ομοίως για το ελάχιστο
    min = temp[0];
    minp = 0;
    // Έλεγχος των υπολοίπων στοιχείων για max & min αντίστοιχα
    for(i=1; i<N; i++) { // Το i ξεκινάει από 1 (δηλαδή το δεύτερο στοιχείο)
        if (temp[i] > max) {
            max = temp[i]; // Το νέο max
            maxp = i; // Η θέση του νέου max
        }

        if (temp[i] < min) {
            min = temp[i]; // Το νέο min
            minp = i; // Η θέση του νέου min
        }
    } // Τέλος υπολογισμού μέγιστης και ελάχιστης θερμοκρασίας

    // Εμφάνιση αποτελεσμάτων
    puts("\n");
    printf("Average month temperature: %.2f\n", (float)sum/N);
    /* Ο Οκτώβριος ξεκινάει από 1 έως 31, όχι 0 μέχρι 30 που είναι οι δείκτες του πίνακα.
       Γι' αυτό αυξάνουμε τη θέση ώστε να αντιστοιχηθεί σε ημέρα του μήνα */
    printf("Max month temperature is %d and happened on day %d. \n", max, ++maxp);
    printf("Min month temperature is %d and happened on day %d. \n", min, ++minp);

    return 0;
}
