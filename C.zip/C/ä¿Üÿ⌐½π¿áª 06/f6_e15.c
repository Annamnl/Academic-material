#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Υπολογισμός νικητή σε αγώνα Ιστιοπλοΐας
*/
#define N 7
#define M 6

int main(void) {

    // Δηλώσεις πινάκων και μεταβλητών
    int R[N][M], SUM[N], WORST[N], i, j;
    srand(time(NULL));

    // Δημιουργία πίνακα με τα αποτελέσματα για κάθε ιστιοδρομία
    for(i=0; i<N; i++) {
        for(j=0; j<M; j++) {
            R[i][j] = 1 + rand()%7; // Θέσεις 1-7
        }
    }

    /* Εμφάνιση πίνακα με τα αποτελέσματα */
    printf("\nSailing Results:\n");
    for(i=0; i<N; i++) {
        for(j=0; j<M; j++)
            printf("%3d", R[i][j]);
        puts("");
    }

    // Υπολογισμός χειρότερης επίδοσης για κάθε σκάφος
    // Εύρεση max για κάθε γραμμή
    int max;
    for(i=0; i<N; i++) {
        max = 0;
        for(j=0; j<M; j++) {
            if(R[i][j]>max)
                max = R[i][j];
        }
        WORST[i] = max;
    }

    // Εμφάνιση των χειρότερων επιδόσεων ανά σκαφος
    puts("Worst:");
    for(i=0; i<N; i++)
        printf("%3d\n", WORST[i]);


    // Μηδενισμός πίνακα αθροισμάτων
    for(i=0; i<N; i++)
        SUM[i] = 0;

    // Υπολογισμός αθροισμάτων με αφαίρεση της χειρότερης θέσης
    for(i=0; i<N; i++) {
        for(j=0; j<M; j++)
            SUM[i] += R[i][j];
        SUM[i] -= WORST[i]; // Αφαίρεση από τον πίνακα με τις χειρότερες θέσης
    }

    // Εμφάνιση του αθροίσματος από τις 5 καλύτερες ιστιοδρομίες
    puts("Sum of 5 best races:");
    for(i=0; i<N; i++)
        printf("%3d\n", SUM[i]);

    /* Τελικός νικητής
       Εύρεση min στον πίνακα SUM */
    int min=SUM[0];
    int minp=0;
    for(i=1; i<N; i++)
        if(SUM[i]<min) {
            min = SUM[i];
            minp = i;
        }

    // Εμφάνιση τελικού νικητή
    printf("Final winner is %d having a sum of %d.\n", ++minp, min);

    return 0;
}
