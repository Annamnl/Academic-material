#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Αντιμετάθεση στοιχείων δισδιάστατου πίνακα
*/
#define N 4
int main(void) {

    // Δηλώσεις πινάκων και μεταβλητών
    int a[N][N], b[N][N], i, j;
    srand(time(NULL));

    // Δημιουργία πινάκων
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++) {
            a[i][j] = rand()%9;
        }
    }

    /* Εμφάνιση πίνακα */
    printf("\nMatrix is:\n");
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++)
            printf("%3d", a[i][j]);
        puts("");
    }

    /* Αντιμετάθεση στοιχείων και αποθήκευση στον πίνακα b */
    for(i=0; i<N; i++)
        for(j=0; j<N; j++)
            b[i][j] = a[j][i];

    // Εμφάνιση τελικού πίνακα
    printf("\nThe result matrix is:\n");
    for(i=0; i<N; i++) {
        for(j=0; j<N; j++)
            printf("%3d", b[i][j]);
        puts("");
    }

    return 0;
}
