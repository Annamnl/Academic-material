#include <stdio.h> // printf(), NULL
#include <stdlib.h> // srand(), rand()
#include <time.h> // time()
/*
* Βαθμολογίες φοιτητών
*/
#define N 15 // ορισμός μεγέθους πίνακα
int main(void) {

    // Αρχικοποίηση μετρητών
    unsigned int passed = 0;
    unsigned int failed = 0;
    int grades[N], i;

    /* Αρχικοποίηση πίνακα με τυχαίους
    ακεραίους από το 0 μέχρι το 10*/
    srand(time(NULL));
    for(i=0; i<N; i++) {
        grades[i] = rand()%11;
    }

    // Εμφάνιση βαθμολογιών
    for(i=0; i<N; i++) {
        printf("%d ", grades[i]);
    }

    /* Υπολογισμός για όσες/οι πέρασαν
    και απέτυχαν αντίστοιχα */
    for(i=0; i<N; i++) {
        if (grades[i] >= 5)
            passed++;
        else
            failed++;
    }

    // Εμφάνιση αποτελεσμάτων
    puts("");
    printf("No of students passed: %d\n", passed);
    printf("No of students failed: %d\n", failed);

    return 0;
}
