#include <stdio.h>
#include <string.h>
/*
* Φυλλάδιο 8, Άσκηση 7
*/
#define SIZE 100
int main(void) {

    // Τμήμα δηλώσεων
    char str[SIZE];
    int i = 0, length;
    int punct_num=0;
    int digits_num=0;
    int char_num=0;

    printf("Insert string: ");
    // Διαβάζει χαρακτήρες από την τυπική είσοδο μέχρι να να βρεθεί χαρακτήρας νέας γραμμής ή τέλος αρχείου
    fgets(str, SIZE, stdin);

    // Η fgets καταχωρεί και την αλλαγής γραμμής '\n' στο str.
    // Εφόσον δεν θέλουμε να λογίζεται ως μέρος της συμβολοσειράς:
    length = strlen(str);
    if (str[length-1] == '\n')
        str[length-1] = '\0';

    // Για κάθε χαρακτήρα στο αλφαριθμητικό str
    // έλεγξε αν είναι σημείο στίξης,
    while (str[i] != '\0') {
        if(ispunct(str[i])) {
            punct_num++;
        } else if (isalpha(str[i])) {
            char_num++;
        } else if (str[i] >= '0' && str[i] <= '9') {
            digits_num++;
        }
        i++;
    }

    printf("Number of punctuation symbols: %d\n", punct_num); // Ερώτημα α)
    printf("Number of digits: %d\n", digits_num); // Ερώτημα β)
    printf("Number of characters: %d\n", char_num); // Ερώτημα γ)

    return 0;
}
