#include <stdio.h>
/*
* Μέτρηση μήκους συμβολοσειράς χωρίς χρήση έτοιμης συνάρτησης
*/
#define SIZE 100

int main(void) {
    char str[SIZE];
    int length = 0;
    printf("Insert string: ");
    // Διαβάζει χαρακτήρες από την τυπική είσοδο μέχρι
    // να βρεθεί χαρακτήρας νέας γραμμής ή τέλος αρχείου
    fgets(str, SIZE, stdin);

    while (str[length] != '\0')
        length++;

    // Η fgets καταχωρεί και την αλλαγής γραμμής '\n' στο str.
    // Εφόσον δεν θέλουμε να λογίζεται στο μήκος της συμβολοσειράς:
    if (str[length-1] == '\n')
        printf("The string length is: %d", length-1);
    else
        printf("The string length is: %d", length);

    return 0;
}
