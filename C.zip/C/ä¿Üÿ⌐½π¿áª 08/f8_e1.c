#include <stdio.h>
/*
* Σαρώνει τον πίνακα a και αντιγράφει στον πίνακα b
* τους χαρακτήρες που έχουν περιττή αναπαράσταση στον πίνακα ASCII
* δηλαδή τους a (97), c (99), e (101), g (103), i (105)
*/
int main(void) {

    char a[]="abcdefghij", b[11];
    int i,j;
    i=j=0;
    while(a[i]) {
        if (a[i]%2)
            b[j++]=a[i];
        i++;
    }
    b[j]='\0';
    printf("%s", b);

    return 0;
}
