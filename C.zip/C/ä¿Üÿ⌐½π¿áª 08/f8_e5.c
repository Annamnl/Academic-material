#include <stdio.h>
/*
* Εμφάνιση αλφαριθμητικού ανάστροφα, για παράδειγμα:
*   Είσοδος: icsd
*   Εξοδος: dsci
*/
#define SIZE 100
int main(void) {

    // Τμήμα δηλώσεων
    char str[SIZE];
    int length = 0;
    int i;

    printf("Insert string: ");
    // Διαβάζει χαρακτήρες από την τυπική είσοδο μέχρι να να βρεθεί χαρακτήρας νέας γραμμής ή τέλος αρχείου
    fgets(str, SIZE, stdin);

    /* Εύρεση μήκους (Θεωρούμε ότι η λέξη/πρόταση τελειώνει
       στο '\n' εφόσον ο χρήστης πατά Enter) */
    while (str[length] != '\0')
        length++;

    // Η fgets καταχωρεί και την αλλαγής γραμμής '\n' στο str.
    // Εφόσον δεν θέλουμε να λογίζεται ωε μέρος της συμβολοσειράς:
    if (str[length-1] == '\n')
        --length;

    // Εμφάνιση των χαρακτήρων της συμβολοσειράς από το τέλος προς την αρχή του πίνακα str
    printf("The reversed string is:\n");
    for(i=length-1; i>=0; i--)
        printf("%c", str[i]);

    return 0;
}
