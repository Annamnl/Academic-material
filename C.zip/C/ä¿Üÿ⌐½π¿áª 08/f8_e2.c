#include <stdio.h>
#include <string.h>
//#include <stdlib.h>
/*
* Ποιο θα είναι το αποτέλεσμα του παρακάτω προγράμματος;
*/
int main(void) {

    int x=20, e;
    char s[15]="ABC", t[15], u[15];
    e=s[1]+s[2];
    sprintf(t, "%d", e);
    strcpy(u,t);
    strcat(s,u);
    puts(s); // Θα εκτυπώσει ABC133

    return 0;
}



/**
ABC133
*/
