#include <stdio.h>
/*
* Φυλλάδιο 5, Άσκηση 2
*/
int is_odd(int);

int main(void) {
    int x;
    puts("Please insert an integer number:");
    scanf("%d", &x); // Είσοδος αριθμού

    if (is_odd(x) == 1) // Έλεγχος της τιμής επιστροφής της συνάρτησης
        printf("Number is odd!");
    else
        printf("Number is even!");

    return 0;
}

/* Ορισμός συνάρτησης is_odd που δέχεται
*  έναν ακέραιο αριθμό και επιστρέφει 1 αν
*  είναι περιττός, 2 αν είναι άρτιος
*/
int is_odd(int n) {

    if (n % 2 == 1) // Χρήση modulo, 1 για περιττό, 0 για άρτιο
        return 1;
    else
        return 2;
}


