#include <stdio.h>
int step;
int main(void) {
    step=2;
    disp(4); // Χρειάζεται να έχει δηλωθεί το πρωτότυπό της συνάρτησης  disp() πριν την main()
    return 0;
}
void disp(st) { // Δεν δηλώνεται ο τύπος της παραμέτρου st
    int a,b,c;
    printf("Αυτή είναι μια συνάρτηση\n");
    a=get();
    c=x; // Η μεταβλητή x δεν έχει δηλωθεί εντός της συνάρτησης x
    b=get();
    if (a==0 && b==0)
        exit(0);
    else {
        int i;
        for (i=a; i<=b; i=i+step)
            printf("%d\n",i);
    }
    printf("i=%d\n",i); // Η μεταβλητή i είναι εκτός εμβέλειας γιατί μεταβλητή i έχει δηλωθεί μόνo στο τμήμα else παραπάνω
    printf("step=%d\n",step);
}

get() { // Δεν έχει δηλωθεί ο τύπος τιμής επιστροφής της συνάρτησης
    float x;
    scanf("%f",&x);
    return x;
}
