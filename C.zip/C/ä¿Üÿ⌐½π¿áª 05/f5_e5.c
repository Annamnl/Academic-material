#include <stdio.h>
/*
Να κατασκευάσετε 2 συναρτήσεις με πρωτότυπα:
int my_fmin(int, int); // Επιστρέφει την τιμή του μικρότερου ακεραίου
int my_fmax(int, int); // Επιστρέφει την τιμή του μεγαλύτερου ακεραίου
Έπειτα να γράψετε ένα πρόγραμμα το οποίο να διαβάζει από την είσοδο 3 ακέραιους αριθμούς και, χρησιμοποιώντας τις παραπάνω συναρτήσεις, να υπολογίζει και εμφανίζει τον μεγαλύτερο και μικρότερο από αυτούς.
*/
int my_fmin(int, int);
int my_fmax(int, int);

int main(void) {
    int x, y, z;

    puts("Please insert 3 integer numbers:");
    // Είσοδος 3 ακεραίων
    scanf("%d %d %d", &x, &y, &z);

    // Εύρεση του μεγαλύτερου και μικρότερου με χρήση των συναρτήσεων
    printf("Min is: %d\n", my_fmin(my_fmin(x, y), z));
    printf("Max is: %d\n", my_fmax(my_fmax(x, y), z));
}

/*
* Επιστρέφει τη μικρότερη τιμή από τους 2
* αριθμούς που δέχεται στην είσοδο
*/
int my_fmin(int a, int b) {
    if (a < b)
        return a;
    else
        return b;
}

/*
* Επιστρέφει τη μεγαλύτερη τιμή από τους 2
* αριθμούς που δέχεται στην είσοδο
*/
int my_fmax(int a, int b) {
    if (a > b)
        return a;
    else
        return b;
}








