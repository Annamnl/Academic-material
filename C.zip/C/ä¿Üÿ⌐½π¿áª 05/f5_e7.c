#include <stdio.h>
/*
* Κατασκευή συνάρτησης με 2 παραμέτρους ακεραίους
* η οποία διαβάζει 10 ακεραίους και εμφανίζει
* τον ελάχιστο που διάβασε στο διάστημα που
* ορίζεται από τις 2 παραμέτρους
*/

void min(int a, int b); // Το πρωτότυπο

int main(void) {
    int i, j;

    printf("Enter first number: ");
    scanf("%d", &i);
    do {
        printf("Enter second number: ");
        scanf("%d", &j);
    } while(i >= j);

    min(i, j);
    return 0;
}

/*
* Δέχεται 2 παραμέτρους ακεραίους a, b
* Εμφανίζει τον μικρότερο στο διάστημα [a, b]
* ή μήνυμα μη ύπαρξης στο διάστημα [a, b]
*/
void min(int a, int b) {
    int i, min, num, first;

    first = 0; // flag ύπαρξης ή μη, αρχικά false (0)
    for(i = 0; i < 10; i++) {
        printf("Enter number: ");
        scanf("%d", &num);

        // Έλεγχος αν ο αριθμός είναι εντός τους διαστήματος [a, b]
        if(num >= a && num <= b) {
            // Την πρώτη φορά που θα βρεθει αριθμός στο
            // διάστημα [a, b], το flag θα γίνει true (1)
            if(first == 0) {
                min = num;
                first = 1;
            }
            // Έλεγχος αν ο αριθμός που διάβασε παραπάνω είναι μικρότερος
            if(num < min)
                min = num;
        }
    }
    // Αν το flag είναι 0, δεν ήταν κανένας αριθμός στο διάστημα [a, b]
    if(first == 0)
        printf("No number in [%d, %d]\n", a, b);
    else
        printf("Min = %d\n", min);
}
