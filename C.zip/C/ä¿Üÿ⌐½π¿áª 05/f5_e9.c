#include <stdio.h>
/*
* Παραγοντικό αριθμών
*/
int factorial(int);

int main(void) {
    int i, sum = 0;

    for (i=1;i<=10;i++)
        sum += factorial(i)/i;

    printf("Result is: %d\n", sum);

    return 0;
}

/*
* Επιστρέφει το παραγοντικό ενός αριθμού a
*/
int factorial(int a) {
    if (a == 0)
        return 1;
    int i, f=1; // f το τελικό αποτέλεσμα του παραγοντικού. Αρχικοποίηση με 1 καθώς έχουμε πολλαπλασιασμό και 0! = 1, 1! = 1
    for(i=1; i<=a; i++) {
        f *= i; // f = f*i, διαδοχικός πολλαπλασιασμός
    }
    return f;
}
